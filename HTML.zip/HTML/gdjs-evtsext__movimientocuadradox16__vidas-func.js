
if (typeof gdjs.evtsExt__MovimientoCuadradoX16__Vidas !== "undefined") {
  gdjs.evtsExt__MovimientoCuadradoX16__Vidas.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__MovimientoCuadradoX16__Vidas = {};
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects4= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects4= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects4= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects4= [];

gdjs.evtsExt__MovimientoCuadradoX16__Vidas.conditionTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition1IsTrue_0 = {val:false};


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList0 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = !(gdjs.adMob.isInterstitialShowing());
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList1 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.adMob.isInterstitialReady();
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
{gdjs.adMob.showInterstitial();
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList0(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.adMob.isInterstitialErrored();
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList2 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList1(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__Vidas.asyncCallback11152108 = function (runtimeScene, eventsFunctionContext, asyncObjectsList) {

{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList2(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.asyncCallback11152108(runtimeScene, eventsFunctionContext, asyncObjectsList)));
}
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) <= 0;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter4"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(0);
}
}{runtimeScene.getGame().getVariables().get("Nivel").setNumber(0);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), false);
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1[i].setString("GAME OVER");
}
}{gdjs.adMob.loadInterstitial("ca-app-pub-4671042942864334/6831724704", "", false);
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) == 1;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) == 2;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) == 3;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) == 4;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(0);
}
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) == 5;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(2);
}
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) == 6;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter2"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Parameter3"), gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1[i].setAnimation(1);
}
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Salud")) > 6;
}if (gdjs.evtsExt__MovimientoCuadradoX16__Vidas.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().get("Salud").setNumber(6);
}}

}


};

gdjs.evtsExt__MovimientoCuadradoX16__Vidas.func = function(runtimeScene, Parameter, Parameter2, Parameter3, Parameter4, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Parameter": Parameter
, "Parameter2": Parameter2
, "Parameter3": Parameter3
, "Parameter4": Parameter4
},
  _objectArraysMap: {
"Parameter": gdjs.objectsListsToArray(Parameter)
, "Parameter2": gdjs.objectsListsToArray(Parameter2)
, "Parameter3": gdjs.objectsListsToArray(Parameter3)
, "Parameter4": gdjs.objectsListsToArray(Parameter4)
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameterObjects4.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter2Objects4.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter3Objects4.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__Vidas.GDParameter4Objects4.length = 0;

gdjs.evtsExt__MovimientoCuadradoX16__Vidas.eventsList4(runtimeScene, eventsFunctionContext);
return;
}

gdjs.evtsExt__MovimientoCuadradoX16__Vidas.registeredGdjsCallbacks = [];