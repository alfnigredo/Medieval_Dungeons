gdjs.AutoLevelCode = {};
gdjs.AutoLevelCode.GDDPadBottomObjects4_1final = [];

gdjs.AutoLevelCode.GDDPadLeftObjects3_1final = [];

gdjs.AutoLevelCode.GDDPadRightObjects4_1final = [];

gdjs.AutoLevelCode.GDDPadUpObjects4_1final = [];

gdjs.AutoLevelCode.GDFireRoundButtonObjects3_1final = [];

gdjs.AutoLevelCode.forEachCount0_7 = 0;

gdjs.AutoLevelCode.forEachCount1_7 = 0;

gdjs.AutoLevelCode.forEachCount2_7 = 0;

gdjs.AutoLevelCode.forEachCount3_7 = 0;

gdjs.AutoLevelCode.forEachIndex3 = 0;

gdjs.AutoLevelCode.forEachIndex7 = 0;

gdjs.AutoLevelCode.forEachObjects3 = [];

gdjs.AutoLevelCode.forEachObjects7 = [];

gdjs.AutoLevelCode.forEachTemporary3 = null;

gdjs.AutoLevelCode.forEachTotalCount3 = 0;

gdjs.AutoLevelCode.forEachTotalCount7 = 0;

gdjs.AutoLevelCode.stopDoWhile10 = false;

gdjs.AutoLevelCode.stopDoWhile11 = false;

gdjs.AutoLevelCode.stopDoWhile13 = false;

gdjs.AutoLevelCode.stopDoWhile3 = false;

gdjs.AutoLevelCode.stopDoWhile4 = false;

gdjs.AutoLevelCode.stopDoWhile6 = false;

gdjs.AutoLevelCode.stopDoWhile7 = false;

gdjs.AutoLevelCode.stopDoWhile8 = false;

gdjs.AutoLevelCode.stopDoWhile9 = false;

gdjs.AutoLevelCode.GDFloorObjects1= [];
gdjs.AutoLevelCode.GDFloorObjects2= [];
gdjs.AutoLevelCode.GDFloorObjects3= [];
gdjs.AutoLevelCode.GDFloorObjects4= [];
gdjs.AutoLevelCode.GDFloorObjects5= [];
gdjs.AutoLevelCode.GDFloorObjects6= [];
gdjs.AutoLevelCode.GDFloorObjects7= [];
gdjs.AutoLevelCode.GDFloorObjects8= [];
gdjs.AutoLevelCode.GDFloorObjects9= [];
gdjs.AutoLevelCode.GDFloorObjects10= [];
gdjs.AutoLevelCode.GDFloorObjects11= [];
gdjs.AutoLevelCode.GDFloorObjects12= [];
gdjs.AutoLevelCode.GDFloorObjects13= [];
gdjs.AutoLevelCode.GDDoorObjects1= [];
gdjs.AutoLevelCode.GDDoorObjects2= [];
gdjs.AutoLevelCode.GDDoorObjects3= [];
gdjs.AutoLevelCode.GDDoorObjects4= [];
gdjs.AutoLevelCode.GDDoorObjects5= [];
gdjs.AutoLevelCode.GDDoorObjects6= [];
gdjs.AutoLevelCode.GDDoorObjects7= [];
gdjs.AutoLevelCode.GDDoorObjects8= [];
gdjs.AutoLevelCode.GDDoorObjects9= [];
gdjs.AutoLevelCode.GDDoorObjects10= [];
gdjs.AutoLevelCode.GDDoorObjects11= [];
gdjs.AutoLevelCode.GDDoorObjects12= [];
gdjs.AutoLevelCode.GDDoorObjects13= [];
gdjs.AutoLevelCode.GDUiHeart1Objects1= [];
gdjs.AutoLevelCode.GDUiHeart1Objects2= [];
gdjs.AutoLevelCode.GDUiHeart1Objects3= [];
gdjs.AutoLevelCode.GDUiHeart1Objects4= [];
gdjs.AutoLevelCode.GDUiHeart1Objects5= [];
gdjs.AutoLevelCode.GDUiHeart1Objects6= [];
gdjs.AutoLevelCode.GDUiHeart1Objects7= [];
gdjs.AutoLevelCode.GDUiHeart1Objects8= [];
gdjs.AutoLevelCode.GDUiHeart1Objects9= [];
gdjs.AutoLevelCode.GDUiHeart1Objects10= [];
gdjs.AutoLevelCode.GDUiHeart1Objects11= [];
gdjs.AutoLevelCode.GDUiHeart1Objects12= [];
gdjs.AutoLevelCode.GDUiHeart1Objects13= [];
gdjs.AutoLevelCode.GDUiHeart2Objects1= [];
gdjs.AutoLevelCode.GDUiHeart2Objects2= [];
gdjs.AutoLevelCode.GDUiHeart2Objects3= [];
gdjs.AutoLevelCode.GDUiHeart2Objects4= [];
gdjs.AutoLevelCode.GDUiHeart2Objects5= [];
gdjs.AutoLevelCode.GDUiHeart2Objects6= [];
gdjs.AutoLevelCode.GDUiHeart2Objects7= [];
gdjs.AutoLevelCode.GDUiHeart2Objects8= [];
gdjs.AutoLevelCode.GDUiHeart2Objects9= [];
gdjs.AutoLevelCode.GDUiHeart2Objects10= [];
gdjs.AutoLevelCode.GDUiHeart2Objects11= [];
gdjs.AutoLevelCode.GDUiHeart2Objects12= [];
gdjs.AutoLevelCode.GDUiHeart2Objects13= [];
gdjs.AutoLevelCode.GDUiHeart3Objects1= [];
gdjs.AutoLevelCode.GDUiHeart3Objects2= [];
gdjs.AutoLevelCode.GDUiHeart3Objects3= [];
gdjs.AutoLevelCode.GDUiHeart3Objects4= [];
gdjs.AutoLevelCode.GDUiHeart3Objects5= [];
gdjs.AutoLevelCode.GDUiHeart3Objects6= [];
gdjs.AutoLevelCode.GDUiHeart3Objects7= [];
gdjs.AutoLevelCode.GDUiHeart3Objects8= [];
gdjs.AutoLevelCode.GDUiHeart3Objects9= [];
gdjs.AutoLevelCode.GDUiHeart3Objects10= [];
gdjs.AutoLevelCode.GDUiHeart3Objects11= [];
gdjs.AutoLevelCode.GDUiHeart3Objects12= [];
gdjs.AutoLevelCode.GDUiHeart3Objects13= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects1= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects2= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects3= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects4= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects5= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects6= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects7= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects8= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects9= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects10= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects11= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects12= [];
gdjs.AutoLevelCode.GDGenericCharacter2Objects13= [];
gdjs.AutoLevelCode.GDLoadingTextObjects1= [];
gdjs.AutoLevelCode.GDLoadingTextObjects2= [];
gdjs.AutoLevelCode.GDLoadingTextObjects3= [];
gdjs.AutoLevelCode.GDLoadingTextObjects4= [];
gdjs.AutoLevelCode.GDLoadingTextObjects5= [];
gdjs.AutoLevelCode.GDLoadingTextObjects6= [];
gdjs.AutoLevelCode.GDLoadingTextObjects7= [];
gdjs.AutoLevelCode.GDLoadingTextObjects8= [];
gdjs.AutoLevelCode.GDLoadingTextObjects9= [];
gdjs.AutoLevelCode.GDLoadingTextObjects10= [];
gdjs.AutoLevelCode.GDLoadingTextObjects11= [];
gdjs.AutoLevelCode.GDLoadingTextObjects12= [];
gdjs.AutoLevelCode.GDLoadingTextObjects13= [];
gdjs.AutoLevelCode.GDScoreTextObjects1= [];
gdjs.AutoLevelCode.GDScoreTextObjects2= [];
gdjs.AutoLevelCode.GDScoreTextObjects3= [];
gdjs.AutoLevelCode.GDScoreTextObjects4= [];
gdjs.AutoLevelCode.GDScoreTextObjects5= [];
gdjs.AutoLevelCode.GDScoreTextObjects6= [];
gdjs.AutoLevelCode.GDScoreTextObjects7= [];
gdjs.AutoLevelCode.GDScoreTextObjects8= [];
gdjs.AutoLevelCode.GDScoreTextObjects9= [];
gdjs.AutoLevelCode.GDScoreTextObjects10= [];
gdjs.AutoLevelCode.GDScoreTextObjects11= [];
gdjs.AutoLevelCode.GDScoreTextObjects12= [];
gdjs.AutoLevelCode.GDScoreTextObjects13= [];
gdjs.AutoLevelCode.GDDPadBottomObjects1= [];
gdjs.AutoLevelCode.GDDPadBottomObjects2= [];
gdjs.AutoLevelCode.GDDPadBottomObjects3= [];
gdjs.AutoLevelCode.GDDPadBottomObjects4= [];
gdjs.AutoLevelCode.GDDPadBottomObjects5= [];
gdjs.AutoLevelCode.GDDPadBottomObjects6= [];
gdjs.AutoLevelCode.GDDPadBottomObjects7= [];
gdjs.AutoLevelCode.GDDPadBottomObjects8= [];
gdjs.AutoLevelCode.GDDPadBottomObjects9= [];
gdjs.AutoLevelCode.GDDPadBottomObjects10= [];
gdjs.AutoLevelCode.GDDPadBottomObjects11= [];
gdjs.AutoLevelCode.GDDPadBottomObjects12= [];
gdjs.AutoLevelCode.GDDPadBottomObjects13= [];
gdjs.AutoLevelCode.GDDPadLeftObjects1= [];
gdjs.AutoLevelCode.GDDPadLeftObjects2= [];
gdjs.AutoLevelCode.GDDPadLeftObjects3= [];
gdjs.AutoLevelCode.GDDPadLeftObjects4= [];
gdjs.AutoLevelCode.GDDPadLeftObjects5= [];
gdjs.AutoLevelCode.GDDPadLeftObjects6= [];
gdjs.AutoLevelCode.GDDPadLeftObjects7= [];
gdjs.AutoLevelCode.GDDPadLeftObjects8= [];
gdjs.AutoLevelCode.GDDPadLeftObjects9= [];
gdjs.AutoLevelCode.GDDPadLeftObjects10= [];
gdjs.AutoLevelCode.GDDPadLeftObjects11= [];
gdjs.AutoLevelCode.GDDPadLeftObjects12= [];
gdjs.AutoLevelCode.GDDPadLeftObjects13= [];
gdjs.AutoLevelCode.GDDPadRightObjects1= [];
gdjs.AutoLevelCode.GDDPadRightObjects2= [];
gdjs.AutoLevelCode.GDDPadRightObjects3= [];
gdjs.AutoLevelCode.GDDPadRightObjects4= [];
gdjs.AutoLevelCode.GDDPadRightObjects5= [];
gdjs.AutoLevelCode.GDDPadRightObjects6= [];
gdjs.AutoLevelCode.GDDPadRightObjects7= [];
gdjs.AutoLevelCode.GDDPadRightObjects8= [];
gdjs.AutoLevelCode.GDDPadRightObjects9= [];
gdjs.AutoLevelCode.GDDPadRightObjects10= [];
gdjs.AutoLevelCode.GDDPadRightObjects11= [];
gdjs.AutoLevelCode.GDDPadRightObjects12= [];
gdjs.AutoLevelCode.GDDPadRightObjects13= [];
gdjs.AutoLevelCode.GDDPadUpObjects1= [];
gdjs.AutoLevelCode.GDDPadUpObjects2= [];
gdjs.AutoLevelCode.GDDPadUpObjects3= [];
gdjs.AutoLevelCode.GDDPadUpObjects4= [];
gdjs.AutoLevelCode.GDDPadUpObjects5= [];
gdjs.AutoLevelCode.GDDPadUpObjects6= [];
gdjs.AutoLevelCode.GDDPadUpObjects7= [];
gdjs.AutoLevelCode.GDDPadUpObjects8= [];
gdjs.AutoLevelCode.GDDPadUpObjects9= [];
gdjs.AutoLevelCode.GDDPadUpObjects10= [];
gdjs.AutoLevelCode.GDDPadUpObjects11= [];
gdjs.AutoLevelCode.GDDPadUpObjects12= [];
gdjs.AutoLevelCode.GDDPadUpObjects13= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects1= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects2= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects3= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects4= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects5= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects6= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects7= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects8= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects9= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects10= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects11= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects12= [];
gdjs.AutoLevelCode.GDFireRoundButtonObjects13= [];
gdjs.AutoLevelCode.GDPauseButtonObjects1= [];
gdjs.AutoLevelCode.GDPauseButtonObjects2= [];
gdjs.AutoLevelCode.GDPauseButtonObjects3= [];
gdjs.AutoLevelCode.GDPauseButtonObjects4= [];
gdjs.AutoLevelCode.GDPauseButtonObjects5= [];
gdjs.AutoLevelCode.GDPauseButtonObjects6= [];
gdjs.AutoLevelCode.GDPauseButtonObjects7= [];
gdjs.AutoLevelCode.GDPauseButtonObjects8= [];
gdjs.AutoLevelCode.GDPauseButtonObjects9= [];
gdjs.AutoLevelCode.GDPauseButtonObjects10= [];
gdjs.AutoLevelCode.GDPauseButtonObjects11= [];
gdjs.AutoLevelCode.GDPauseButtonObjects12= [];
gdjs.AutoLevelCode.GDPauseButtonObjects13= [];
gdjs.AutoLevelCode.GDBlankButtonObjects1= [];
gdjs.AutoLevelCode.GDBlankButtonObjects2= [];
gdjs.AutoLevelCode.GDBlankButtonObjects3= [];
gdjs.AutoLevelCode.GDBlankButtonObjects4= [];
gdjs.AutoLevelCode.GDBlankButtonObjects5= [];
gdjs.AutoLevelCode.GDBlankButtonObjects6= [];
gdjs.AutoLevelCode.GDBlankButtonObjects7= [];
gdjs.AutoLevelCode.GDBlankButtonObjects8= [];
gdjs.AutoLevelCode.GDBlankButtonObjects9= [];
gdjs.AutoLevelCode.GDBlankButtonObjects10= [];
gdjs.AutoLevelCode.GDBlankButtonObjects11= [];
gdjs.AutoLevelCode.GDBlankButtonObjects12= [];
gdjs.AutoLevelCode.GDBlankButtonObjects13= [];
gdjs.AutoLevelCode.GDTextoArmaObjects1= [];
gdjs.AutoLevelCode.GDTextoArmaObjects2= [];
gdjs.AutoLevelCode.GDTextoArmaObjects3= [];
gdjs.AutoLevelCode.GDTextoArmaObjects4= [];
gdjs.AutoLevelCode.GDTextoArmaObjects5= [];
gdjs.AutoLevelCode.GDTextoArmaObjects6= [];
gdjs.AutoLevelCode.GDTextoArmaObjects7= [];
gdjs.AutoLevelCode.GDTextoArmaObjects8= [];
gdjs.AutoLevelCode.GDTextoArmaObjects9= [];
gdjs.AutoLevelCode.GDTextoArmaObjects10= [];
gdjs.AutoLevelCode.GDTextoArmaObjects11= [];
gdjs.AutoLevelCode.GDTextoArmaObjects12= [];
gdjs.AutoLevelCode.GDTextoArmaObjects13= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects1= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects2= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects3= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects4= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects5= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects6= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects7= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects8= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects9= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects10= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects11= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects12= [];
gdjs.AutoLevelCode.GDReiniciarJuegoObjects13= [];
gdjs.AutoLevelCode.GDCoinObjects1= [];
gdjs.AutoLevelCode.GDCoinObjects2= [];
gdjs.AutoLevelCode.GDCoinObjects3= [];
gdjs.AutoLevelCode.GDCoinObjects4= [];
gdjs.AutoLevelCode.GDCoinObjects5= [];
gdjs.AutoLevelCode.GDCoinObjects6= [];
gdjs.AutoLevelCode.GDCoinObjects7= [];
gdjs.AutoLevelCode.GDCoinObjects8= [];
gdjs.AutoLevelCode.GDCoinObjects9= [];
gdjs.AutoLevelCode.GDCoinObjects10= [];
gdjs.AutoLevelCode.GDCoinObjects11= [];
gdjs.AutoLevelCode.GDCoinObjects12= [];
gdjs.AutoLevelCode.GDCoinObjects13= [];
gdjs.AutoLevelCode.GDChestObjects1= [];
gdjs.AutoLevelCode.GDChestObjects2= [];
gdjs.AutoLevelCode.GDChestObjects3= [];
gdjs.AutoLevelCode.GDChestObjects4= [];
gdjs.AutoLevelCode.GDChestObjects5= [];
gdjs.AutoLevelCode.GDChestObjects6= [];
gdjs.AutoLevelCode.GDChestObjects7= [];
gdjs.AutoLevelCode.GDChestObjects8= [];
gdjs.AutoLevelCode.GDChestObjects9= [];
gdjs.AutoLevelCode.GDChestObjects10= [];
gdjs.AutoLevelCode.GDChestObjects11= [];
gdjs.AutoLevelCode.GDChestObjects12= [];
gdjs.AutoLevelCode.GDChestObjects13= [];
gdjs.AutoLevelCode.GDKnifeObjects1= [];
gdjs.AutoLevelCode.GDKnifeObjects2= [];
gdjs.AutoLevelCode.GDKnifeObjects3= [];
gdjs.AutoLevelCode.GDKnifeObjects4= [];
gdjs.AutoLevelCode.GDKnifeObjects5= [];
gdjs.AutoLevelCode.GDKnifeObjects6= [];
gdjs.AutoLevelCode.GDKnifeObjects7= [];
gdjs.AutoLevelCode.GDKnifeObjects8= [];
gdjs.AutoLevelCode.GDKnifeObjects9= [];
gdjs.AutoLevelCode.GDKnifeObjects10= [];
gdjs.AutoLevelCode.GDKnifeObjects11= [];
gdjs.AutoLevelCode.GDKnifeObjects12= [];
gdjs.AutoLevelCode.GDKnifeObjects13= [];
gdjs.AutoLevelCode.GDRustySwordObjects1= [];
gdjs.AutoLevelCode.GDRustySwordObjects2= [];
gdjs.AutoLevelCode.GDRustySwordObjects3= [];
gdjs.AutoLevelCode.GDRustySwordObjects4= [];
gdjs.AutoLevelCode.GDRustySwordObjects5= [];
gdjs.AutoLevelCode.GDRustySwordObjects6= [];
gdjs.AutoLevelCode.GDRustySwordObjects7= [];
gdjs.AutoLevelCode.GDRustySwordObjects8= [];
gdjs.AutoLevelCode.GDRustySwordObjects9= [];
gdjs.AutoLevelCode.GDRustySwordObjects10= [];
gdjs.AutoLevelCode.GDRustySwordObjects11= [];
gdjs.AutoLevelCode.GDRustySwordObjects12= [];
gdjs.AutoLevelCode.GDRustySwordObjects13= [];
gdjs.AutoLevelCode.GDRegularSwordObjects1= [];
gdjs.AutoLevelCode.GDRegularSwordObjects2= [];
gdjs.AutoLevelCode.GDRegularSwordObjects3= [];
gdjs.AutoLevelCode.GDRegularSwordObjects4= [];
gdjs.AutoLevelCode.GDRegularSwordObjects5= [];
gdjs.AutoLevelCode.GDRegularSwordObjects6= [];
gdjs.AutoLevelCode.GDRegularSwordObjects7= [];
gdjs.AutoLevelCode.GDRegularSwordObjects8= [];
gdjs.AutoLevelCode.GDRegularSwordObjects9= [];
gdjs.AutoLevelCode.GDRegularSwordObjects10= [];
gdjs.AutoLevelCode.GDRegularSwordObjects11= [];
gdjs.AutoLevelCode.GDRegularSwordObjects12= [];
gdjs.AutoLevelCode.GDRegularSwordObjects13= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects1= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects2= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects3= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects4= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects5= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects6= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects7= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects8= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects9= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects10= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects11= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects12= [];
gdjs.AutoLevelCode.GDAnimeSwordObjects13= [];
gdjs.AutoLevelCode.GDEnemy1Objects1= [];
gdjs.AutoLevelCode.GDEnemy1Objects2= [];
gdjs.AutoLevelCode.GDEnemy1Objects3= [];
gdjs.AutoLevelCode.GDEnemy1Objects4= [];
gdjs.AutoLevelCode.GDEnemy1Objects5= [];
gdjs.AutoLevelCode.GDEnemy1Objects6= [];
gdjs.AutoLevelCode.GDEnemy1Objects7= [];
gdjs.AutoLevelCode.GDEnemy1Objects8= [];
gdjs.AutoLevelCode.GDEnemy1Objects9= [];
gdjs.AutoLevelCode.GDEnemy1Objects10= [];
gdjs.AutoLevelCode.GDEnemy1Objects11= [];
gdjs.AutoLevelCode.GDEnemy1Objects12= [];
gdjs.AutoLevelCode.GDEnemy1Objects13= [];
gdjs.AutoLevelCode.GDEnemy2Objects1= [];
gdjs.AutoLevelCode.GDEnemy2Objects2= [];
gdjs.AutoLevelCode.GDEnemy2Objects3= [];
gdjs.AutoLevelCode.GDEnemy2Objects4= [];
gdjs.AutoLevelCode.GDEnemy2Objects5= [];
gdjs.AutoLevelCode.GDEnemy2Objects6= [];
gdjs.AutoLevelCode.GDEnemy2Objects7= [];
gdjs.AutoLevelCode.GDEnemy2Objects8= [];
gdjs.AutoLevelCode.GDEnemy2Objects9= [];
gdjs.AutoLevelCode.GDEnemy2Objects10= [];
gdjs.AutoLevelCode.GDEnemy2Objects11= [];
gdjs.AutoLevelCode.GDEnemy2Objects12= [];
gdjs.AutoLevelCode.GDEnemy2Objects13= [];
gdjs.AutoLevelCode.GDEnemy3Objects1= [];
gdjs.AutoLevelCode.GDEnemy3Objects2= [];
gdjs.AutoLevelCode.GDEnemy3Objects3= [];
gdjs.AutoLevelCode.GDEnemy3Objects4= [];
gdjs.AutoLevelCode.GDEnemy3Objects5= [];
gdjs.AutoLevelCode.GDEnemy3Objects6= [];
gdjs.AutoLevelCode.GDEnemy3Objects7= [];
gdjs.AutoLevelCode.GDEnemy3Objects8= [];
gdjs.AutoLevelCode.GDEnemy3Objects9= [];
gdjs.AutoLevelCode.GDEnemy3Objects10= [];
gdjs.AutoLevelCode.GDEnemy3Objects11= [];
gdjs.AutoLevelCode.GDEnemy3Objects12= [];
gdjs.AutoLevelCode.GDEnemy3Objects13= [];
gdjs.AutoLevelCode.GDEnemy4Objects1= [];
gdjs.AutoLevelCode.GDEnemy4Objects2= [];
gdjs.AutoLevelCode.GDEnemy4Objects3= [];
gdjs.AutoLevelCode.GDEnemy4Objects4= [];
gdjs.AutoLevelCode.GDEnemy4Objects5= [];
gdjs.AutoLevelCode.GDEnemy4Objects6= [];
gdjs.AutoLevelCode.GDEnemy4Objects7= [];
gdjs.AutoLevelCode.GDEnemy4Objects8= [];
gdjs.AutoLevelCode.GDEnemy4Objects9= [];
gdjs.AutoLevelCode.GDEnemy4Objects10= [];
gdjs.AutoLevelCode.GDEnemy4Objects11= [];
gdjs.AutoLevelCode.GDEnemy4Objects12= [];
gdjs.AutoLevelCode.GDEnemy4Objects13= [];
gdjs.AutoLevelCode.GDEnemy5Objects1= [];
gdjs.AutoLevelCode.GDEnemy5Objects2= [];
gdjs.AutoLevelCode.GDEnemy5Objects3= [];
gdjs.AutoLevelCode.GDEnemy5Objects4= [];
gdjs.AutoLevelCode.GDEnemy5Objects5= [];
gdjs.AutoLevelCode.GDEnemy5Objects6= [];
gdjs.AutoLevelCode.GDEnemy5Objects7= [];
gdjs.AutoLevelCode.GDEnemy5Objects8= [];
gdjs.AutoLevelCode.GDEnemy5Objects9= [];
gdjs.AutoLevelCode.GDEnemy5Objects10= [];
gdjs.AutoLevelCode.GDEnemy5Objects11= [];
gdjs.AutoLevelCode.GDEnemy5Objects12= [];
gdjs.AutoLevelCode.GDEnemy5Objects13= [];
gdjs.AutoLevelCode.GDEnemy6Objects1= [];
gdjs.AutoLevelCode.GDEnemy6Objects2= [];
gdjs.AutoLevelCode.GDEnemy6Objects3= [];
gdjs.AutoLevelCode.GDEnemy6Objects4= [];
gdjs.AutoLevelCode.GDEnemy6Objects5= [];
gdjs.AutoLevelCode.GDEnemy6Objects6= [];
gdjs.AutoLevelCode.GDEnemy6Objects7= [];
gdjs.AutoLevelCode.GDEnemy6Objects8= [];
gdjs.AutoLevelCode.GDEnemy6Objects9= [];
gdjs.AutoLevelCode.GDEnemy6Objects10= [];
gdjs.AutoLevelCode.GDEnemy6Objects11= [];
gdjs.AutoLevelCode.GDEnemy6Objects12= [];
gdjs.AutoLevelCode.GDEnemy6Objects13= [];
gdjs.AutoLevelCode.GDEnemy7Objects1= [];
gdjs.AutoLevelCode.GDEnemy7Objects2= [];
gdjs.AutoLevelCode.GDEnemy7Objects3= [];
gdjs.AutoLevelCode.GDEnemy7Objects4= [];
gdjs.AutoLevelCode.GDEnemy7Objects5= [];
gdjs.AutoLevelCode.GDEnemy7Objects6= [];
gdjs.AutoLevelCode.GDEnemy7Objects7= [];
gdjs.AutoLevelCode.GDEnemy7Objects8= [];
gdjs.AutoLevelCode.GDEnemy7Objects9= [];
gdjs.AutoLevelCode.GDEnemy7Objects10= [];
gdjs.AutoLevelCode.GDEnemy7Objects11= [];
gdjs.AutoLevelCode.GDEnemy7Objects12= [];
gdjs.AutoLevelCode.GDEnemy7Objects13= [];
gdjs.AutoLevelCode.GDEnemy8Objects1= [];
gdjs.AutoLevelCode.GDEnemy8Objects2= [];
gdjs.AutoLevelCode.GDEnemy8Objects3= [];
gdjs.AutoLevelCode.GDEnemy8Objects4= [];
gdjs.AutoLevelCode.GDEnemy8Objects5= [];
gdjs.AutoLevelCode.GDEnemy8Objects6= [];
gdjs.AutoLevelCode.GDEnemy8Objects7= [];
gdjs.AutoLevelCode.GDEnemy8Objects8= [];
gdjs.AutoLevelCode.GDEnemy8Objects9= [];
gdjs.AutoLevelCode.GDEnemy8Objects10= [];
gdjs.AutoLevelCode.GDEnemy8Objects11= [];
gdjs.AutoLevelCode.GDEnemy8Objects12= [];
gdjs.AutoLevelCode.GDEnemy8Objects13= [];
gdjs.AutoLevelCode.GDEnemy9Objects1= [];
gdjs.AutoLevelCode.GDEnemy9Objects2= [];
gdjs.AutoLevelCode.GDEnemy9Objects3= [];
gdjs.AutoLevelCode.GDEnemy9Objects4= [];
gdjs.AutoLevelCode.GDEnemy9Objects5= [];
gdjs.AutoLevelCode.GDEnemy9Objects6= [];
gdjs.AutoLevelCode.GDEnemy9Objects7= [];
gdjs.AutoLevelCode.GDEnemy9Objects8= [];
gdjs.AutoLevelCode.GDEnemy9Objects9= [];
gdjs.AutoLevelCode.GDEnemy9Objects10= [];
gdjs.AutoLevelCode.GDEnemy9Objects11= [];
gdjs.AutoLevelCode.GDEnemy9Objects12= [];
gdjs.AutoLevelCode.GDEnemy9Objects13= [];
gdjs.AutoLevelCode.GDEnemy10Objects1= [];
gdjs.AutoLevelCode.GDEnemy10Objects2= [];
gdjs.AutoLevelCode.GDEnemy10Objects3= [];
gdjs.AutoLevelCode.GDEnemy10Objects4= [];
gdjs.AutoLevelCode.GDEnemy10Objects5= [];
gdjs.AutoLevelCode.GDEnemy10Objects6= [];
gdjs.AutoLevelCode.GDEnemy10Objects7= [];
gdjs.AutoLevelCode.GDEnemy10Objects8= [];
gdjs.AutoLevelCode.GDEnemy10Objects9= [];
gdjs.AutoLevelCode.GDEnemy10Objects10= [];
gdjs.AutoLevelCode.GDEnemy10Objects11= [];
gdjs.AutoLevelCode.GDEnemy10Objects12= [];
gdjs.AutoLevelCode.GDEnemy10Objects13= [];
gdjs.AutoLevelCode.GDEnemy11Objects1= [];
gdjs.AutoLevelCode.GDEnemy11Objects2= [];
gdjs.AutoLevelCode.GDEnemy11Objects3= [];
gdjs.AutoLevelCode.GDEnemy11Objects4= [];
gdjs.AutoLevelCode.GDEnemy11Objects5= [];
gdjs.AutoLevelCode.GDEnemy11Objects6= [];
gdjs.AutoLevelCode.GDEnemy11Objects7= [];
gdjs.AutoLevelCode.GDEnemy11Objects8= [];
gdjs.AutoLevelCode.GDEnemy11Objects9= [];
gdjs.AutoLevelCode.GDEnemy11Objects10= [];
gdjs.AutoLevelCode.GDEnemy11Objects11= [];
gdjs.AutoLevelCode.GDEnemy11Objects12= [];
gdjs.AutoLevelCode.GDEnemy11Objects13= [];
gdjs.AutoLevelCode.GDEnemy12Objects1= [];
gdjs.AutoLevelCode.GDEnemy12Objects2= [];
gdjs.AutoLevelCode.GDEnemy12Objects3= [];
gdjs.AutoLevelCode.GDEnemy12Objects4= [];
gdjs.AutoLevelCode.GDEnemy12Objects5= [];
gdjs.AutoLevelCode.GDEnemy12Objects6= [];
gdjs.AutoLevelCode.GDEnemy12Objects7= [];
gdjs.AutoLevelCode.GDEnemy12Objects8= [];
gdjs.AutoLevelCode.GDEnemy12Objects9= [];
gdjs.AutoLevelCode.GDEnemy12Objects10= [];
gdjs.AutoLevelCode.GDEnemy12Objects11= [];
gdjs.AutoLevelCode.GDEnemy12Objects12= [];
gdjs.AutoLevelCode.GDEnemy12Objects13= [];
gdjs.AutoLevelCode.GDEnemy13Objects1= [];
gdjs.AutoLevelCode.GDEnemy13Objects2= [];
gdjs.AutoLevelCode.GDEnemy13Objects3= [];
gdjs.AutoLevelCode.GDEnemy13Objects4= [];
gdjs.AutoLevelCode.GDEnemy13Objects5= [];
gdjs.AutoLevelCode.GDEnemy13Objects6= [];
gdjs.AutoLevelCode.GDEnemy13Objects7= [];
gdjs.AutoLevelCode.GDEnemy13Objects8= [];
gdjs.AutoLevelCode.GDEnemy13Objects9= [];
gdjs.AutoLevelCode.GDEnemy13Objects10= [];
gdjs.AutoLevelCode.GDEnemy13Objects11= [];
gdjs.AutoLevelCode.GDEnemy13Objects12= [];
gdjs.AutoLevelCode.GDEnemy13Objects13= [];
gdjs.AutoLevelCode.GDEnemy14Objects1= [];
gdjs.AutoLevelCode.GDEnemy14Objects2= [];
gdjs.AutoLevelCode.GDEnemy14Objects3= [];
gdjs.AutoLevelCode.GDEnemy14Objects4= [];
gdjs.AutoLevelCode.GDEnemy14Objects5= [];
gdjs.AutoLevelCode.GDEnemy14Objects6= [];
gdjs.AutoLevelCode.GDEnemy14Objects7= [];
gdjs.AutoLevelCode.GDEnemy14Objects8= [];
gdjs.AutoLevelCode.GDEnemy14Objects9= [];
gdjs.AutoLevelCode.GDEnemy14Objects10= [];
gdjs.AutoLevelCode.GDEnemy14Objects11= [];
gdjs.AutoLevelCode.GDEnemy14Objects12= [];
gdjs.AutoLevelCode.GDEnemy14Objects13= [];
gdjs.AutoLevelCode.GDEnemy15Objects1= [];
gdjs.AutoLevelCode.GDEnemy15Objects2= [];
gdjs.AutoLevelCode.GDEnemy15Objects3= [];
gdjs.AutoLevelCode.GDEnemy15Objects4= [];
gdjs.AutoLevelCode.GDEnemy15Objects5= [];
gdjs.AutoLevelCode.GDEnemy15Objects6= [];
gdjs.AutoLevelCode.GDEnemy15Objects7= [];
gdjs.AutoLevelCode.GDEnemy15Objects8= [];
gdjs.AutoLevelCode.GDEnemy15Objects9= [];
gdjs.AutoLevelCode.GDEnemy15Objects10= [];
gdjs.AutoLevelCode.GDEnemy15Objects11= [];
gdjs.AutoLevelCode.GDEnemy15Objects12= [];
gdjs.AutoLevelCode.GDEnemy15Objects13= [];
gdjs.AutoLevelCode.GDEnemy16Objects1= [];
gdjs.AutoLevelCode.GDEnemy16Objects2= [];
gdjs.AutoLevelCode.GDEnemy16Objects3= [];
gdjs.AutoLevelCode.GDEnemy16Objects4= [];
gdjs.AutoLevelCode.GDEnemy16Objects5= [];
gdjs.AutoLevelCode.GDEnemy16Objects6= [];
gdjs.AutoLevelCode.GDEnemy16Objects7= [];
gdjs.AutoLevelCode.GDEnemy16Objects8= [];
gdjs.AutoLevelCode.GDEnemy16Objects9= [];
gdjs.AutoLevelCode.GDEnemy16Objects10= [];
gdjs.AutoLevelCode.GDEnemy16Objects11= [];
gdjs.AutoLevelCode.GDEnemy16Objects12= [];
gdjs.AutoLevelCode.GDEnemy16Objects13= [];
gdjs.AutoLevelCode.GDEnemy17Objects1= [];
gdjs.AutoLevelCode.GDEnemy17Objects2= [];
gdjs.AutoLevelCode.GDEnemy17Objects3= [];
gdjs.AutoLevelCode.GDEnemy17Objects4= [];
gdjs.AutoLevelCode.GDEnemy17Objects5= [];
gdjs.AutoLevelCode.GDEnemy17Objects6= [];
gdjs.AutoLevelCode.GDEnemy17Objects7= [];
gdjs.AutoLevelCode.GDEnemy17Objects8= [];
gdjs.AutoLevelCode.GDEnemy17Objects9= [];
gdjs.AutoLevelCode.GDEnemy17Objects10= [];
gdjs.AutoLevelCode.GDEnemy17Objects11= [];
gdjs.AutoLevelCode.GDEnemy17Objects12= [];
gdjs.AutoLevelCode.GDEnemy17Objects13= [];
gdjs.AutoLevelCode.GDEnemy18Objects1= [];
gdjs.AutoLevelCode.GDEnemy18Objects2= [];
gdjs.AutoLevelCode.GDEnemy18Objects3= [];
gdjs.AutoLevelCode.GDEnemy18Objects4= [];
gdjs.AutoLevelCode.GDEnemy18Objects5= [];
gdjs.AutoLevelCode.GDEnemy18Objects6= [];
gdjs.AutoLevelCode.GDEnemy18Objects7= [];
gdjs.AutoLevelCode.GDEnemy18Objects8= [];
gdjs.AutoLevelCode.GDEnemy18Objects9= [];
gdjs.AutoLevelCode.GDEnemy18Objects10= [];
gdjs.AutoLevelCode.GDEnemy18Objects11= [];
gdjs.AutoLevelCode.GDEnemy18Objects12= [];
gdjs.AutoLevelCode.GDEnemy18Objects13= [];
gdjs.AutoLevelCode.GDEnemy19Objects1= [];
gdjs.AutoLevelCode.GDEnemy19Objects2= [];
gdjs.AutoLevelCode.GDEnemy19Objects3= [];
gdjs.AutoLevelCode.GDEnemy19Objects4= [];
gdjs.AutoLevelCode.GDEnemy19Objects5= [];
gdjs.AutoLevelCode.GDEnemy19Objects6= [];
gdjs.AutoLevelCode.GDEnemy19Objects7= [];
gdjs.AutoLevelCode.GDEnemy19Objects8= [];
gdjs.AutoLevelCode.GDEnemy19Objects9= [];
gdjs.AutoLevelCode.GDEnemy19Objects10= [];
gdjs.AutoLevelCode.GDEnemy19Objects11= [];
gdjs.AutoLevelCode.GDEnemy19Objects12= [];
gdjs.AutoLevelCode.GDEnemy19Objects13= [];
gdjs.AutoLevelCode.GDEnemy20Objects1= [];
gdjs.AutoLevelCode.GDEnemy20Objects2= [];
gdjs.AutoLevelCode.GDEnemy20Objects3= [];
gdjs.AutoLevelCode.GDEnemy20Objects4= [];
gdjs.AutoLevelCode.GDEnemy20Objects5= [];
gdjs.AutoLevelCode.GDEnemy20Objects6= [];
gdjs.AutoLevelCode.GDEnemy20Objects7= [];
gdjs.AutoLevelCode.GDEnemy20Objects8= [];
gdjs.AutoLevelCode.GDEnemy20Objects9= [];
gdjs.AutoLevelCode.GDEnemy20Objects10= [];
gdjs.AutoLevelCode.GDEnemy20Objects11= [];
gdjs.AutoLevelCode.GDEnemy20Objects12= [];
gdjs.AutoLevelCode.GDEnemy20Objects13= [];
gdjs.AutoLevelCode.GDEnemy21Objects1= [];
gdjs.AutoLevelCode.GDEnemy21Objects2= [];
gdjs.AutoLevelCode.GDEnemy21Objects3= [];
gdjs.AutoLevelCode.GDEnemy21Objects4= [];
gdjs.AutoLevelCode.GDEnemy21Objects5= [];
gdjs.AutoLevelCode.GDEnemy21Objects6= [];
gdjs.AutoLevelCode.GDEnemy21Objects7= [];
gdjs.AutoLevelCode.GDEnemy21Objects8= [];
gdjs.AutoLevelCode.GDEnemy21Objects9= [];
gdjs.AutoLevelCode.GDEnemy21Objects10= [];
gdjs.AutoLevelCode.GDEnemy21Objects11= [];
gdjs.AutoLevelCode.GDEnemy21Objects12= [];
gdjs.AutoLevelCode.GDEnemy21Objects13= [];
gdjs.AutoLevelCode.GDEnemy22Objects1= [];
gdjs.AutoLevelCode.GDEnemy22Objects2= [];
gdjs.AutoLevelCode.GDEnemy22Objects3= [];
gdjs.AutoLevelCode.GDEnemy22Objects4= [];
gdjs.AutoLevelCode.GDEnemy22Objects5= [];
gdjs.AutoLevelCode.GDEnemy22Objects6= [];
gdjs.AutoLevelCode.GDEnemy22Objects7= [];
gdjs.AutoLevelCode.GDEnemy22Objects8= [];
gdjs.AutoLevelCode.GDEnemy22Objects9= [];
gdjs.AutoLevelCode.GDEnemy22Objects10= [];
gdjs.AutoLevelCode.GDEnemy22Objects11= [];
gdjs.AutoLevelCode.GDEnemy22Objects12= [];
gdjs.AutoLevelCode.GDEnemy22Objects13= [];
gdjs.AutoLevelCode.GDEnemy23Objects1= [];
gdjs.AutoLevelCode.GDEnemy23Objects2= [];
gdjs.AutoLevelCode.GDEnemy23Objects3= [];
gdjs.AutoLevelCode.GDEnemy23Objects4= [];
gdjs.AutoLevelCode.GDEnemy23Objects5= [];
gdjs.AutoLevelCode.GDEnemy23Objects6= [];
gdjs.AutoLevelCode.GDEnemy23Objects7= [];
gdjs.AutoLevelCode.GDEnemy23Objects8= [];
gdjs.AutoLevelCode.GDEnemy23Objects9= [];
gdjs.AutoLevelCode.GDEnemy23Objects10= [];
gdjs.AutoLevelCode.GDEnemy23Objects11= [];
gdjs.AutoLevelCode.GDEnemy23Objects12= [];
gdjs.AutoLevelCode.GDEnemy23Objects13= [];
gdjs.AutoLevelCode.GDEnemy24Objects1= [];
gdjs.AutoLevelCode.GDEnemy24Objects2= [];
gdjs.AutoLevelCode.GDEnemy24Objects3= [];
gdjs.AutoLevelCode.GDEnemy24Objects4= [];
gdjs.AutoLevelCode.GDEnemy24Objects5= [];
gdjs.AutoLevelCode.GDEnemy24Objects6= [];
gdjs.AutoLevelCode.GDEnemy24Objects7= [];
gdjs.AutoLevelCode.GDEnemy24Objects8= [];
gdjs.AutoLevelCode.GDEnemy24Objects9= [];
gdjs.AutoLevelCode.GDEnemy24Objects10= [];
gdjs.AutoLevelCode.GDEnemy24Objects11= [];
gdjs.AutoLevelCode.GDEnemy24Objects12= [];
gdjs.AutoLevelCode.GDEnemy24Objects13= [];
gdjs.AutoLevelCode.GDEnemy25Objects1= [];
gdjs.AutoLevelCode.GDEnemy25Objects2= [];
gdjs.AutoLevelCode.GDEnemy25Objects3= [];
gdjs.AutoLevelCode.GDEnemy25Objects4= [];
gdjs.AutoLevelCode.GDEnemy25Objects5= [];
gdjs.AutoLevelCode.GDEnemy25Objects6= [];
gdjs.AutoLevelCode.GDEnemy25Objects7= [];
gdjs.AutoLevelCode.GDEnemy25Objects8= [];
gdjs.AutoLevelCode.GDEnemy25Objects9= [];
gdjs.AutoLevelCode.GDEnemy25Objects10= [];
gdjs.AutoLevelCode.GDEnemy25Objects11= [];
gdjs.AutoLevelCode.GDEnemy25Objects12= [];
gdjs.AutoLevelCode.GDEnemy25Objects13= [];
gdjs.AutoLevelCode.GDEnemy26Objects1= [];
gdjs.AutoLevelCode.GDEnemy26Objects2= [];
gdjs.AutoLevelCode.GDEnemy26Objects3= [];
gdjs.AutoLevelCode.GDEnemy26Objects4= [];
gdjs.AutoLevelCode.GDEnemy26Objects5= [];
gdjs.AutoLevelCode.GDEnemy26Objects6= [];
gdjs.AutoLevelCode.GDEnemy26Objects7= [];
gdjs.AutoLevelCode.GDEnemy26Objects8= [];
gdjs.AutoLevelCode.GDEnemy26Objects9= [];
gdjs.AutoLevelCode.GDEnemy26Objects10= [];
gdjs.AutoLevelCode.GDEnemy26Objects11= [];
gdjs.AutoLevelCode.GDEnemy26Objects12= [];
gdjs.AutoLevelCode.GDEnemy26Objects13= [];
gdjs.AutoLevelCode.GDEnemy27Objects1= [];
gdjs.AutoLevelCode.GDEnemy27Objects2= [];
gdjs.AutoLevelCode.GDEnemy27Objects3= [];
gdjs.AutoLevelCode.GDEnemy27Objects4= [];
gdjs.AutoLevelCode.GDEnemy27Objects5= [];
gdjs.AutoLevelCode.GDEnemy27Objects6= [];
gdjs.AutoLevelCode.GDEnemy27Objects7= [];
gdjs.AutoLevelCode.GDEnemy27Objects8= [];
gdjs.AutoLevelCode.GDEnemy27Objects9= [];
gdjs.AutoLevelCode.GDEnemy27Objects10= [];
gdjs.AutoLevelCode.GDEnemy27Objects11= [];
gdjs.AutoLevelCode.GDEnemy27Objects12= [];
gdjs.AutoLevelCode.GDEnemy27Objects13= [];
gdjs.AutoLevelCode.GDEnemy28Objects1= [];
gdjs.AutoLevelCode.GDEnemy28Objects2= [];
gdjs.AutoLevelCode.GDEnemy28Objects3= [];
gdjs.AutoLevelCode.GDEnemy28Objects4= [];
gdjs.AutoLevelCode.GDEnemy28Objects5= [];
gdjs.AutoLevelCode.GDEnemy28Objects6= [];
gdjs.AutoLevelCode.GDEnemy28Objects7= [];
gdjs.AutoLevelCode.GDEnemy28Objects8= [];
gdjs.AutoLevelCode.GDEnemy28Objects9= [];
gdjs.AutoLevelCode.GDEnemy28Objects10= [];
gdjs.AutoLevelCode.GDEnemy28Objects11= [];
gdjs.AutoLevelCode.GDEnemy28Objects12= [];
gdjs.AutoLevelCode.GDEnemy28Objects13= [];
gdjs.AutoLevelCode.GDEnemy29Objects1= [];
gdjs.AutoLevelCode.GDEnemy29Objects2= [];
gdjs.AutoLevelCode.GDEnemy29Objects3= [];
gdjs.AutoLevelCode.GDEnemy29Objects4= [];
gdjs.AutoLevelCode.GDEnemy29Objects5= [];
gdjs.AutoLevelCode.GDEnemy29Objects6= [];
gdjs.AutoLevelCode.GDEnemy29Objects7= [];
gdjs.AutoLevelCode.GDEnemy29Objects8= [];
gdjs.AutoLevelCode.GDEnemy29Objects9= [];
gdjs.AutoLevelCode.GDEnemy29Objects10= [];
gdjs.AutoLevelCode.GDEnemy29Objects11= [];
gdjs.AutoLevelCode.GDEnemy29Objects12= [];
gdjs.AutoLevelCode.GDEnemy29Objects13= [];
gdjs.AutoLevelCode.GDEnemy30Objects1= [];
gdjs.AutoLevelCode.GDEnemy30Objects2= [];
gdjs.AutoLevelCode.GDEnemy30Objects3= [];
gdjs.AutoLevelCode.GDEnemy30Objects4= [];
gdjs.AutoLevelCode.GDEnemy30Objects5= [];
gdjs.AutoLevelCode.GDEnemy30Objects6= [];
gdjs.AutoLevelCode.GDEnemy30Objects7= [];
gdjs.AutoLevelCode.GDEnemy30Objects8= [];
gdjs.AutoLevelCode.GDEnemy30Objects9= [];
gdjs.AutoLevelCode.GDEnemy30Objects10= [];
gdjs.AutoLevelCode.GDEnemy30Objects11= [];
gdjs.AutoLevelCode.GDEnemy30Objects12= [];
gdjs.AutoLevelCode.GDEnemy30Objects13= [];
gdjs.AutoLevelCode.GDTitleObjects1= [];
gdjs.AutoLevelCode.GDTitleObjects2= [];
gdjs.AutoLevelCode.GDTitleObjects3= [];
gdjs.AutoLevelCode.GDTitleObjects4= [];
gdjs.AutoLevelCode.GDTitleObjects5= [];
gdjs.AutoLevelCode.GDTitleObjects6= [];
gdjs.AutoLevelCode.GDTitleObjects7= [];
gdjs.AutoLevelCode.GDTitleObjects8= [];
gdjs.AutoLevelCode.GDTitleObjects9= [];
gdjs.AutoLevelCode.GDTitleObjects10= [];
gdjs.AutoLevelCode.GDTitleObjects11= [];
gdjs.AutoLevelCode.GDTitleObjects12= [];
gdjs.AutoLevelCode.GDTitleObjects13= [];
gdjs.AutoLevelCode.GDTileObjects1= [];
gdjs.AutoLevelCode.GDTileObjects2= [];
gdjs.AutoLevelCode.GDTileObjects3= [];
gdjs.AutoLevelCode.GDTileObjects4= [];
gdjs.AutoLevelCode.GDTileObjects5= [];
gdjs.AutoLevelCode.GDTileObjects6= [];
gdjs.AutoLevelCode.GDTileObjects7= [];
gdjs.AutoLevelCode.GDTileObjects8= [];
gdjs.AutoLevelCode.GDTileObjects9= [];
gdjs.AutoLevelCode.GDTileObjects10= [];
gdjs.AutoLevelCode.GDTileObjects11= [];
gdjs.AutoLevelCode.GDTileObjects12= [];
gdjs.AutoLevelCode.GDTileObjects13= [];
gdjs.AutoLevelCode.GDBlackTileObjects1= [];
gdjs.AutoLevelCode.GDBlackTileObjects2= [];
gdjs.AutoLevelCode.GDBlackTileObjects3= [];
gdjs.AutoLevelCode.GDBlackTileObjects4= [];
gdjs.AutoLevelCode.GDBlackTileObjects5= [];
gdjs.AutoLevelCode.GDBlackTileObjects6= [];
gdjs.AutoLevelCode.GDBlackTileObjects7= [];
gdjs.AutoLevelCode.GDBlackTileObjects8= [];
gdjs.AutoLevelCode.GDBlackTileObjects9= [];
gdjs.AutoLevelCode.GDBlackTileObjects10= [];
gdjs.AutoLevelCode.GDBlackTileObjects11= [];
gdjs.AutoLevelCode.GDBlackTileObjects12= [];
gdjs.AutoLevelCode.GDBlackTileObjects13= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects1= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects2= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects3= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects4= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects5= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects6= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects7= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects8= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects9= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects10= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects11= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects12= [];
gdjs.AutoLevelCode.GDNodeMarkerObjects13= [];
gdjs.AutoLevelCode.GDFondoNegroObjects1= [];
gdjs.AutoLevelCode.GDFondoNegroObjects2= [];
gdjs.AutoLevelCode.GDFondoNegroObjects3= [];
gdjs.AutoLevelCode.GDFondoNegroObjects4= [];
gdjs.AutoLevelCode.GDFondoNegroObjects5= [];
gdjs.AutoLevelCode.GDFondoNegroObjects6= [];
gdjs.AutoLevelCode.GDFondoNegroObjects7= [];
gdjs.AutoLevelCode.GDFondoNegroObjects8= [];
gdjs.AutoLevelCode.GDFondoNegroObjects9= [];
gdjs.AutoLevelCode.GDFondoNegroObjects10= [];
gdjs.AutoLevelCode.GDFondoNegroObjects11= [];
gdjs.AutoLevelCode.GDFondoNegroObjects12= [];
gdjs.AutoLevelCode.GDFondoNegroObjects13= [];
gdjs.AutoLevelCode.GDPausaObjects1= [];
gdjs.AutoLevelCode.GDPausaObjects2= [];
gdjs.AutoLevelCode.GDPausaObjects3= [];
gdjs.AutoLevelCode.GDPausaObjects4= [];
gdjs.AutoLevelCode.GDPausaObjects5= [];
gdjs.AutoLevelCode.GDPausaObjects6= [];
gdjs.AutoLevelCode.GDPausaObjects7= [];
gdjs.AutoLevelCode.GDPausaObjects8= [];
gdjs.AutoLevelCode.GDPausaObjects9= [];
gdjs.AutoLevelCode.GDPausaObjects10= [];
gdjs.AutoLevelCode.GDPausaObjects11= [];
gdjs.AutoLevelCode.GDPausaObjects12= [];
gdjs.AutoLevelCode.GDPausaObjects13= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects1= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects2= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects3= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects4= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects5= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects6= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects7= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects8= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects9= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects10= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects11= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects12= [];
gdjs.AutoLevelCode.GDBotonVerdeObjects13= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects1= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects2= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects3= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects4= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects5= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects6= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects7= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects8= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects9= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects10= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects11= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects12= [];
gdjs.AutoLevelCode.GDBotonVerde2Objects13= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects1= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects2= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects3= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects4= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects5= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects6= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects7= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects8= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects9= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects10= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects11= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects12= [];
gdjs.AutoLevelCode.GDContinuarBtnObjects13= [];
gdjs.AutoLevelCode.GDSalirBtnObjects1= [];
gdjs.AutoLevelCode.GDSalirBtnObjects2= [];
gdjs.AutoLevelCode.GDSalirBtnObjects3= [];
gdjs.AutoLevelCode.GDSalirBtnObjects4= [];
gdjs.AutoLevelCode.GDSalirBtnObjects5= [];
gdjs.AutoLevelCode.GDSalirBtnObjects6= [];
gdjs.AutoLevelCode.GDSalirBtnObjects7= [];
gdjs.AutoLevelCode.GDSalirBtnObjects8= [];
gdjs.AutoLevelCode.GDSalirBtnObjects9= [];
gdjs.AutoLevelCode.GDSalirBtnObjects10= [];
gdjs.AutoLevelCode.GDSalirBtnObjects11= [];
gdjs.AutoLevelCode.GDSalirBtnObjects12= [];
gdjs.AutoLevelCode.GDSalirBtnObjects13= [];
gdjs.AutoLevelCode.GDDebugObjects1= [];
gdjs.AutoLevelCode.GDDebugObjects2= [];
gdjs.AutoLevelCode.GDDebugObjects3= [];
gdjs.AutoLevelCode.GDDebugObjects4= [];
gdjs.AutoLevelCode.GDDebugObjects5= [];
gdjs.AutoLevelCode.GDDebugObjects6= [];
gdjs.AutoLevelCode.GDDebugObjects7= [];
gdjs.AutoLevelCode.GDDebugObjects8= [];
gdjs.AutoLevelCode.GDDebugObjects9= [];
gdjs.AutoLevelCode.GDDebugObjects10= [];
gdjs.AutoLevelCode.GDDebugObjects11= [];
gdjs.AutoLevelCode.GDDebugObjects12= [];
gdjs.AutoLevelCode.GDDebugObjects13= [];

gdjs.AutoLevelCode.conditionTrue_0 = {val:false};
gdjs.AutoLevelCode.condition0IsTrue_0 = {val:false};
gdjs.AutoLevelCode.condition1IsTrue_0 = {val:false};
gdjs.AutoLevelCode.condition2IsTrue_0 = {val:false};
gdjs.AutoLevelCode.conditionTrue_1 = {val:false};
gdjs.AutoLevelCode.condition0IsTrue_1 = {val:false};
gdjs.AutoLevelCode.condition1IsTrue_1 = {val:false};
gdjs.AutoLevelCode.condition2IsTrue_1 = {val:false};


gdjs.AutoLevelCode.asyncCallback11918236 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects3);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].hide();
}
}}
gdjs.AutoLevelCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects2) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11918236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList1 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 0;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(29);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.AutoLevelCode.GDScoreTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("Title"), gdjs.AutoLevelCode.GDTitleObjects2);
{for(var i = 0, len = gdjs.AutoLevelCode.GDTitleObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDTitleObjects2[i].setString("Nivel " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDScoreTextObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) + " pt");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects2[i].setString("Nivel Iniciado");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


{
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(Math.floor((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) - 1) / 10) * 10);
}{runtimeScene.getVariables().getFromIndex(10).setNumber(Math.floor((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))) / 6) + 1);
}{runtimeScene.getVariables().getFromIndex(9).setNumber(Math.floor((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))) / 7) + 1);
}{runtimeScene.getVariables().getFromIndex(11).setNumber(Math.floor((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10))) * 1.1));
}{runtimeScene.getVariables().getFromIndex(12).setNumber(Math.ceil((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10))) * 0.6));
}{runtimeScene.getGame().getVariables().getFromIndex(8).setNumber(0.5 - ((Math.floor((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) - 1) / 10)) / 10));
}}

}


};gdjs.AutoLevelCode.mapOfEmptyGDCoinObjects = Hashtable.newFrom({"Coin": []});
gdjs.AutoLevelCode.mapOfEmptyGDEnemy9ObjectsEmptyGDEnemy1ObjectsEmptyGDEnemy2ObjectsEmptyGDEnemy3ObjectsEmptyGDEnemy4ObjectsEmptyGDEnemy5ObjectsEmptyGDEnemy6ObjectsEmptyGDEnemy7ObjectsEmptyGDEnemy8ObjectsEmptyGDEnemy10ObjectsEmptyGDEnemy11ObjectsEmptyGDEnemy12ObjectsEmptyGDEnemy13ObjectsEmptyGDEnemy14ObjectsEmptyGDEnemy15ObjectsEmptyGDEnemy16ObjectsEmptyGDEnemy17ObjectsEmptyGDEnemy18ObjectsEmptyGDEnemy19ObjectsEmptyGDEnemy20ObjectsEmptyGDEnemy21ObjectsEmptyGDEnemy22ObjectsEmptyGDEnemy23ObjectsEmptyGDEnemy24ObjectsEmptyGDEnemy25ObjectsEmptyGDEnemy26ObjectsEmptyGDEnemy27ObjectsEmptyGDEnemy28ObjectsEmptyGDEnemy29ObjectsEmptyGDEnemy30Objects = Hashtable.newFrom({"Enemy9": [], "Enemy1": [], "Enemy2": [], "Enemy3": [], "Enemy4": [], "Enemy5": [], "Enemy6": [], "Enemy7": [], "Enemy8": [], "Enemy10": [], "Enemy11": [], "Enemy12": [], "Enemy13": [], "Enemy14": [], "Enemy15": [], "Enemy16": [], "Enemy17": [], "Enemy18": [], "Enemy19": [], "Enemy20": [], "Enemy21": [], "Enemy22": [], "Enemy23": [], "Enemy24": [], "Enemy25": [], "Enemy26": [], "Enemy27": [], "Enemy28": [], "Enemy29": [], "Enemy30": []});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBotonVerdeObjects3Objects = Hashtable.newFrom({"BotonVerde": gdjs.AutoLevelCode.GDBotonVerdeObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBotonVerde2Objects2Objects = Hashtable.newFrom({"BotonVerde2": gdjs.AutoLevelCode.GDBotonVerde2Objects2});
gdjs.AutoLevelCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BotonVerde"), gdjs.AutoLevelCode.GDBotonVerdeObjects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBotonVerdeObjects3Objects, runtimeScene, true, false);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition1IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11923116);
}
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDBotonVerdeObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/click1.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDBotonVerdeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDBotonVerdeObjects3[i].setAnimation(1);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("BotonVerde2"), gdjs.AutoLevelCode.GDBotonVerde2Objects2);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBotonVerde2Objects2Objects, runtimeScene, true, false);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition1IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11923804);
}
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDBotonVerde2Objects2 */
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/click1.ogg", false, 100, 1);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDBotonVerde2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDBotonVerde2Objects2[i].setAnimation(1);
}
}{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDPauseButtonObjects1Objects = Hashtable.newFrom({"PauseButton": gdjs.AutoLevelCode.GDPauseButtonObjects1});
gdjs.AutoLevelCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("PauseButton"), gdjs.AutoLevelCode.GDPauseButtonObjects1);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDPauseButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition1IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11924868);
}
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}}

}


};gdjs.AutoLevelCode.eventsList4 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition1IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11922172);
}
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0));
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Debug"), gdjs.AutoLevelCode.GDDebugObjects2);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "PauseGame");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDDebugObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDDebugObjects2[i].setString("Nivel " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))) + "/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1))) + "\nMonedas " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfEmptyGDCoinObjects)) + "/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(11))) + "\nEnemigos " + gdjs.evtTools.common.toString(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfEmptyGDEnemy9ObjectsEmptyGDEnemy1ObjectsEmptyGDEnemy2ObjectsEmptyGDEnemy3ObjectsEmptyGDEnemy4ObjectsEmptyGDEnemy5ObjectsEmptyGDEnemy6ObjectsEmptyGDEnemy7ObjectsEmptyGDEnemy8ObjectsEmptyGDEnemy10ObjectsEmptyGDEnemy11ObjectsEmptyGDEnemy12ObjectsEmptyGDEnemy13ObjectsEmptyGDEnemy14ObjectsEmptyGDEnemy15ObjectsEmptyGDEnemy16ObjectsEmptyGDEnemy17ObjectsEmptyGDEnemy18ObjectsEmptyGDEnemy19ObjectsEmptyGDEnemy20ObjectsEmptyGDEnemy21ObjectsEmptyGDEnemy22ObjectsEmptyGDEnemy23ObjectsEmptyGDEnemy24ObjectsEmptyGDEnemy25ObjectsEmptyGDEnemy26ObjectsEmptyGDEnemy27ObjectsEmptyGDEnemy28ObjectsEmptyGDEnemy29ObjectsEmptyGDEnemy30Objects)) + "/" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(12))) + "\nVelocidad" + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))));
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "PauseGame");
}
{ //Subevents
gdjs.AutoLevelCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects2Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects2});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects2});
gdjs.AutoLevelCode.eventsList5 = function(runtimeScene) {

{


{
/* Reuse gdjs.AutoLevelCode.GDDoorObjects2 */
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects2 */
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects2Objects, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 16) - 2) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 16) - 2) * 16, "");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDDoorObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDDoorObjects2[i].setAnimation(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects, gdjs.randomInRange(0, 9) * 16, gdjs.randomInRange(0, 17) * 16, "Player");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i].activateBehavior("Pathfinding", false);
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDTileObjects3Objects = Hashtable.newFrom({"Tile": gdjs.AutoLevelCode.GDTileObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects3Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects3});
gdjs.AutoLevelCode.eventsList6 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= (10 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(2), false);
}}

}


};gdjs.AutoLevelCode.eventsList7 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) == 1;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.AutoLevelCode.GDFloorObjects3, gdjs.AutoLevelCode.GDFloorObjects4);

{for(var i = 0, len = gdjs.AutoLevelCode.GDFloorObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDFloorObjects4[i].setAnimation(gdjs.randomInRange(0, 7));
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (18 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(0).add(1);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects = Hashtable.newFrom({"BlackTile": gdjs.AutoLevelCode.GDBlackTileObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects = Hashtable.newFrom({"BlackTile": gdjs.AutoLevelCode.GDBlackTileObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects = Hashtable.newFrom({"BlackTile": gdjs.AutoLevelCode.GDBlackTileObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects = Hashtable.newFrom({"BlackTile": gdjs.AutoLevelCode.GDBlackTileObjects3});
gdjs.AutoLevelCode.eventsList8 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) >= (10 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(3), false);
}}

}


};gdjs.AutoLevelCode.eventsList9 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) >= (18 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(0).add(1);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDTileObjects4Objects = Hashtable.newFrom({"Tile": gdjs.AutoLevelCode.GDTileObjects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects4Objects = Hashtable.newFrom({"BlackTile": gdjs.AutoLevelCode.GDBlackTileObjects4});
gdjs.AutoLevelCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects4);
gdjs.copyArray(gdjs.AutoLevelCode.GDTileObjects3, gdjs.AutoLevelCode.GDTileObjects4);


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDTileObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDTileObjects4[i].getOpacity() < 100 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDTileObjects4[k] = gdjs.AutoLevelCode.GDTileObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDTileObjects4.length = k;}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
gdjs.AutoLevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDTileObjects4Objects, false, runtimeScene, true);
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDFloorObjects4 */
gdjs.AutoLevelCode.GDBlackTileObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects4Objects, (( gdjs.AutoLevelCode.GDFloorObjects4.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDFloorObjects4[0].getPointX("")), (( gdjs.AutoLevelCode.GDFloorObjects4.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDFloorObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDFloorObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDFloorObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects6Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects6Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects6});
gdjs.AutoLevelCode.eventsList11 = function(runtimeScene, asyncObjectsList) {

};gdjs.AutoLevelCode.eventsList12 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile6 = false;
do {gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects6);
gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects4, gdjs.AutoLevelCode.GDGenericCharacter2Objects6);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects6Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects6Objects, false, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects6.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects6[i].setPosition(gdjs.randomInRange(0, 9) * 16,gdjs.randomInRange(0, 17) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList11(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile6 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile6 );

}


};gdjs.AutoLevelCode.asyncCallback9188700 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects5);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects5[i].hide();
}
}}
gdjs.AutoLevelCode.eventsList13 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects4) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9188700(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects5Objects = Hashtable.newFrom({"Chest": gdjs.AutoLevelCode.GDChestObjects5});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects6Objects = Hashtable.newFrom({"Chest": gdjs.AutoLevelCode.GDChestObjects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects6Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects8Objects = Hashtable.newFrom({"Chest": gdjs.AutoLevelCode.GDChestObjects8});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects8Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects8});
gdjs.AutoLevelCode.eventsList14 = function(runtimeScene, asyncObjectsList) {

};gdjs.AutoLevelCode.eventsList15 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile8 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDChestObjects6, gdjs.AutoLevelCode.GDChestObjects8);

gdjs.copyArray(asyncObjectsList.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects8);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects8Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects8Objects, false, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDChestObjects8.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDChestObjects8[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList14(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile8 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile8 );

}


};gdjs.AutoLevelCode.eventsList16 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile6 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDChestObjects5, gdjs.AutoLevelCode.GDChestObjects6);

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects6);
gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects6Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects6Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDChestObjects6.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDChestObjects6[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList15(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile6 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile6 );

}


};gdjs.AutoLevelCode.mapOfEmptyGDCoinObjects = Hashtable.newFrom({"Coin": []});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects6Objects = Hashtable.newFrom({"Coin": gdjs.AutoLevelCode.GDCoinObjects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects8ObjectsGDgdjs_46AutoLevelCode_46GDChestObjects8Objects = Hashtable.newFrom({"Coin": gdjs.AutoLevelCode.GDCoinObjects8, "Chest": gdjs.AutoLevelCode.GDChestObjects8});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects8Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects8});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects10ObjectsGDgdjs_46AutoLevelCode_46GDChestObjects10Objects = Hashtable.newFrom({"Coin": gdjs.AutoLevelCode.GDCoinObjects10, "Chest": gdjs.AutoLevelCode.GDChestObjects10});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects10Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects10});
gdjs.AutoLevelCode.eventsList17 = function(runtimeScene, asyncObjectsList) {

};gdjs.AutoLevelCode.eventsList18 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile10 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDChestObjects8, gdjs.AutoLevelCode.GDChestObjects10);

gdjs.copyArray(gdjs.AutoLevelCode.GDCoinObjects8, gdjs.AutoLevelCode.GDCoinObjects10);

gdjs.copyArray(asyncObjectsList.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects10);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects10ObjectsGDgdjs_46AutoLevelCode_46GDChestObjects10Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects10Objects, false, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDCoinObjects10.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDCoinObjects10[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDChestObjects10.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDChestObjects10[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList17(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile10 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile10 );

}


};gdjs.AutoLevelCode.eventsList19 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile8 = false;
do {gdjs.copyArray(runtimeScene.getObjects("Chest"), gdjs.AutoLevelCode.GDChestObjects8);
gdjs.copyArray(gdjs.AutoLevelCode.GDCoinObjects6, gdjs.AutoLevelCode.GDCoinObjects8);

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects8);
gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects8ObjectsGDgdjs_46AutoLevelCode_46GDChestObjects8Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects8Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDCoinObjects8.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDCoinObjects8[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDChestObjects8.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDChestObjects8[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList18(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile8 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile8 );

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects6Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects6, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects6, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects6, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects6Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects6, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects6, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects6, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects6Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects6, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects6, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects6, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects6});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects9ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects9ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects9ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects9Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects9, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects9, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects9, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects9});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects9Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects9});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects11ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects11ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects11ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects11Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects11, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects11, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects11, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects11});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects11Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects11});
gdjs.AutoLevelCode.eventsList20 = function(runtimeScene, asyncObjectsList) {

};gdjs.AutoLevelCode.eventsList21 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile11 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDAnimeSwordObjects9, gdjs.AutoLevelCode.GDAnimeSwordObjects11);

gdjs.copyArray(asyncObjectsList.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDKnifeObjects9, gdjs.AutoLevelCode.GDKnifeObjects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDRegularSwordObjects9, gdjs.AutoLevelCode.GDRegularSwordObjects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDRustySwordObjects9, gdjs.AutoLevelCode.GDRustySwordObjects11);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects11ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects11ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects11ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects11Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects11Objects, false, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList20(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile11 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile11 );

}


};gdjs.AutoLevelCode.asyncCallback11506364 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects9);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects9[i].hide();
}
}}
gdjs.AutoLevelCode.eventsList22 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects8) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11506364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList23 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile9 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDAnimeSwordObjects7, gdjs.AutoLevelCode.GDAnimeSwordObjects9);

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects9);
gdjs.copyArray(gdjs.AutoLevelCode.GDKnifeObjects7, gdjs.AutoLevelCode.GDKnifeObjects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDRegularSwordObjects7, gdjs.AutoLevelCode.GDRegularSwordObjects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDRustySwordObjects7, gdjs.AutoLevelCode.GDRustySwordObjects9);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects9ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects9ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects9ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects9Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects9Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList21(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile9 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile9 );

}


{


{
gdjs.copyArray(gdjs.AutoLevelCode.GDLoadingTextObjects5, gdjs.AutoLevelCode.GDLoadingTextObjects8);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects8.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects8[i].setString("Armas Generados");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects8.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects8[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList22(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfEmptyGDEnemy9ObjectsEmptyGDEnemy1ObjectsEmptyGDEnemy2ObjectsEmptyGDEnemy3ObjectsEmptyGDEnemy4ObjectsEmptyGDEnemy5ObjectsEmptyGDEnemy6ObjectsEmptyGDEnemy7ObjectsEmptyGDEnemy8ObjectsEmptyGDEnemy10ObjectsEmptyGDEnemy11ObjectsEmptyGDEnemy12ObjectsEmptyGDEnemy13ObjectsEmptyGDEnemy14ObjectsEmptyGDEnemy15ObjectsEmptyGDEnemy16ObjectsEmptyGDEnemy17ObjectsEmptyGDEnemy18ObjectsEmptyGDEnemy19ObjectsEmptyGDEnemy20ObjectsEmptyGDEnemy21ObjectsEmptyGDEnemy22ObjectsEmptyGDEnemy23ObjectsEmptyGDEnemy24ObjectsEmptyGDEnemy25ObjectsEmptyGDEnemy26ObjectsEmptyGDEnemy27ObjectsEmptyGDEnemy28ObjectsEmptyGDEnemy29ObjectsEmptyGDEnemy30Objects = Hashtable.newFrom({"Enemy9": [], "Enemy1": [], "Enemy2": [], "Enemy3": [], "Enemy4": [], "Enemy5": [], "Enemy6": [], "Enemy7": [], "Enemy8": [], "Enemy10": [], "Enemy11": [], "Enemy12": [], "Enemy13": [], "Enemy14": [], "Enemy15": [], "Enemy16": [], "Enemy17": [], "Enemy18": [], "Enemy19": [], "Enemy20": [], "Enemy21": [], "Enemy22": [], "Enemy23": [], "Enemy24": [], "Enemy25": [], "Enemy26": [], "Enemy27": [], "Enemy28": [], "Enemy29": [], "Enemy30": []});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects7Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects7, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects7, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects7, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects7, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects7, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects7, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects7, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects7, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects7, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects7, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects7, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects7, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects7, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects7, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects7, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects7, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects7, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects7, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects7, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects7, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects7, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects7, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects7, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects7, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects7, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects7, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects7, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects7, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects7, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects7});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects9Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects9, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects9, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects9, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects9, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects9, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects9, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects9, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects9, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects9, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects9, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects9, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects9, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects9, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects9, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects9, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects9, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects9, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects9, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects9, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects9, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects9, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects9, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects9, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects9, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects9, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects9, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects9, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects9, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects9, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects9});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects9Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects9});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects11Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects11, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects11, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects11, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects11, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects11, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects11, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects11, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects11, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects11, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects11, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects11, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects11, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects11, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects11, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects11, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects11, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects11, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects11, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects11, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects11, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects11, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects11, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects11, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects11, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects11, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects11, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects11, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects11, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects11, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects11});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects11Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects11});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects13Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects13, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects13, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects13, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects13, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects13, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects13, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects13, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects13, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects13, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects13, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects13, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects13, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects13, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects13, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects13, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects13, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects13, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects13, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects13, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects13, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects13, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects13, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects13, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects13, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects13, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects13, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects13, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects13, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects13, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects13});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects13Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects13});
gdjs.AutoLevelCode.eventsList24 = function(runtimeScene, asyncObjectsList) {

};gdjs.AutoLevelCode.eventsList25 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile13 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy1Objects11, gdjs.AutoLevelCode.GDEnemy1Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy10Objects11, gdjs.AutoLevelCode.GDEnemy10Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy11Objects11, gdjs.AutoLevelCode.GDEnemy11Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy12Objects11, gdjs.AutoLevelCode.GDEnemy12Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy13Objects11, gdjs.AutoLevelCode.GDEnemy13Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy14Objects11, gdjs.AutoLevelCode.GDEnemy14Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy15Objects11, gdjs.AutoLevelCode.GDEnemy15Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy16Objects11, gdjs.AutoLevelCode.GDEnemy16Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy17Objects11, gdjs.AutoLevelCode.GDEnemy17Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy18Objects11, gdjs.AutoLevelCode.GDEnemy18Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy19Objects11, gdjs.AutoLevelCode.GDEnemy19Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy2Objects11, gdjs.AutoLevelCode.GDEnemy2Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy20Objects11, gdjs.AutoLevelCode.GDEnemy20Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy21Objects11, gdjs.AutoLevelCode.GDEnemy21Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy22Objects11, gdjs.AutoLevelCode.GDEnemy22Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy23Objects11, gdjs.AutoLevelCode.GDEnemy23Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy24Objects11, gdjs.AutoLevelCode.GDEnemy24Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy25Objects11, gdjs.AutoLevelCode.GDEnemy25Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy26Objects11, gdjs.AutoLevelCode.GDEnemy26Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy27Objects11, gdjs.AutoLevelCode.GDEnemy27Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy28Objects11, gdjs.AutoLevelCode.GDEnemy28Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy29Objects11, gdjs.AutoLevelCode.GDEnemy29Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy3Objects11, gdjs.AutoLevelCode.GDEnemy3Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy30Objects11, gdjs.AutoLevelCode.GDEnemy30Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy4Objects11, gdjs.AutoLevelCode.GDEnemy4Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy5Objects11, gdjs.AutoLevelCode.GDEnemy5Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy6Objects11, gdjs.AutoLevelCode.GDEnemy6Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy7Objects11, gdjs.AutoLevelCode.GDEnemy7Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy8Objects11, gdjs.AutoLevelCode.GDEnemy8Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy9Objects11, gdjs.AutoLevelCode.GDEnemy9Objects13);

gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects11, gdjs.AutoLevelCode.GDGenericCharacter2Objects13);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects13ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects13Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects13Objects, 10, false);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects13[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects13.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects13[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects13[0].getPointY("")));
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList24(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile13 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile13 );

}


};gdjs.AutoLevelCode.eventsList26 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile11 = false;
do {gdjs.copyArray(asyncObjectsList.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy1Objects9, gdjs.AutoLevelCode.GDEnemy1Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy10Objects9, gdjs.AutoLevelCode.GDEnemy10Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy11Objects9, gdjs.AutoLevelCode.GDEnemy11Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy12Objects9, gdjs.AutoLevelCode.GDEnemy12Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy13Objects9, gdjs.AutoLevelCode.GDEnemy13Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy14Objects9, gdjs.AutoLevelCode.GDEnemy14Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy15Objects9, gdjs.AutoLevelCode.GDEnemy15Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy16Objects9, gdjs.AutoLevelCode.GDEnemy16Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy17Objects9, gdjs.AutoLevelCode.GDEnemy17Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy18Objects9, gdjs.AutoLevelCode.GDEnemy18Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy19Objects9, gdjs.AutoLevelCode.GDEnemy19Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy2Objects9, gdjs.AutoLevelCode.GDEnemy2Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy20Objects9, gdjs.AutoLevelCode.GDEnemy20Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy21Objects9, gdjs.AutoLevelCode.GDEnemy21Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy22Objects9, gdjs.AutoLevelCode.GDEnemy22Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy23Objects9, gdjs.AutoLevelCode.GDEnemy23Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy24Objects9, gdjs.AutoLevelCode.GDEnemy24Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy25Objects9, gdjs.AutoLevelCode.GDEnemy25Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy26Objects9, gdjs.AutoLevelCode.GDEnemy26Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy27Objects9, gdjs.AutoLevelCode.GDEnemy27Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy28Objects9, gdjs.AutoLevelCode.GDEnemy28Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy29Objects9, gdjs.AutoLevelCode.GDEnemy29Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy3Objects9, gdjs.AutoLevelCode.GDEnemy3Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy30Objects9, gdjs.AutoLevelCode.GDEnemy30Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy4Objects9, gdjs.AutoLevelCode.GDEnemy4Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy5Objects9, gdjs.AutoLevelCode.GDEnemy5Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy6Objects9, gdjs.AutoLevelCode.GDEnemy6Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy7Objects9, gdjs.AutoLevelCode.GDEnemy7Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy8Objects9, gdjs.AutoLevelCode.GDEnemy8Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy9Objects9, gdjs.AutoLevelCode.GDEnemy9Objects11);

gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects9, gdjs.AutoLevelCode.GDGenericCharacter2Objects11);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects11ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects11Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects11Objects, false, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects11[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects11.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects11[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects11[0].getPointY("")));
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList25(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile11 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile11 );

}


};gdjs.AutoLevelCode.eventsList27 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile9 = false;
do {gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy1Objects7, gdjs.AutoLevelCode.GDEnemy1Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy10Objects7, gdjs.AutoLevelCode.GDEnemy10Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy11Objects7, gdjs.AutoLevelCode.GDEnemy11Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy12Objects7, gdjs.AutoLevelCode.GDEnemy12Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy13Objects7, gdjs.AutoLevelCode.GDEnemy13Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy14Objects7, gdjs.AutoLevelCode.GDEnemy14Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy15Objects7, gdjs.AutoLevelCode.GDEnemy15Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy16Objects7, gdjs.AutoLevelCode.GDEnemy16Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy17Objects7, gdjs.AutoLevelCode.GDEnemy17Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy18Objects7, gdjs.AutoLevelCode.GDEnemy18Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy19Objects7, gdjs.AutoLevelCode.GDEnemy19Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy2Objects7, gdjs.AutoLevelCode.GDEnemy2Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy20Objects7, gdjs.AutoLevelCode.GDEnemy20Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy21Objects7, gdjs.AutoLevelCode.GDEnemy21Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy22Objects7, gdjs.AutoLevelCode.GDEnemy22Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy23Objects7, gdjs.AutoLevelCode.GDEnemy23Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy24Objects7, gdjs.AutoLevelCode.GDEnemy24Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy25Objects7, gdjs.AutoLevelCode.GDEnemy25Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy26Objects7, gdjs.AutoLevelCode.GDEnemy26Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy27Objects7, gdjs.AutoLevelCode.GDEnemy27Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy28Objects7, gdjs.AutoLevelCode.GDEnemy28Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy29Objects7, gdjs.AutoLevelCode.GDEnemy29Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy3Objects7, gdjs.AutoLevelCode.GDEnemy3Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy30Objects7, gdjs.AutoLevelCode.GDEnemy30Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy4Objects7, gdjs.AutoLevelCode.GDEnemy4Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy5Objects7, gdjs.AutoLevelCode.GDEnemy5Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy6Objects7, gdjs.AutoLevelCode.GDEnemy6Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy7Objects7, gdjs.AutoLevelCode.GDEnemy7Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy8Objects7, gdjs.AutoLevelCode.GDEnemy8Objects9);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy9Objects7, gdjs.AutoLevelCode.GDEnemy9Objects9);

gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects9);
gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects7, gdjs.AutoLevelCode.GDGenericCharacter2Objects9);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects9ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects9Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects9Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects9[i].setPosition(gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16,gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects9.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects9[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects9[0].getPointY("")));
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList26(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile9 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile9 );

}


};gdjs.AutoLevelCode.asyncCallback9452076 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects6);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects6.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects6[i].hide();
}
}}
gdjs.AutoLevelCode.eventsList28 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects5) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9452076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList29 = function(runtimeScene, asyncObjectsList) {

{



}


{


gdjs.AutoLevelCode.stopDoWhile7 = false;
do {gdjs.copyArray(asyncObjectsList.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects7);

gdjs.AutoLevelCode.GDEnemy1Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy10Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy11Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy12Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy13Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy14Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy15Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy16Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy17Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy18Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy19Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy2Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy20Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy21Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy22Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy23Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy24Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy25Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy26Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy27Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy28Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy29Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy3Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy30Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy4Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy5Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy6Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy7Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy8Objects7.length = 0;

gdjs.AutoLevelCode.GDEnemy9Objects7.length = 0;

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfEmptyGDEnemy9ObjectsEmptyGDEnemy1ObjectsEmptyGDEnemy2ObjectsEmptyGDEnemy3ObjectsEmptyGDEnemy4ObjectsEmptyGDEnemy5ObjectsEmptyGDEnemy6ObjectsEmptyGDEnemy7ObjectsEmptyGDEnemy8ObjectsEmptyGDEnemy10ObjectsEmptyGDEnemy11ObjectsEmptyGDEnemy12ObjectsEmptyGDEnemy13ObjectsEmptyGDEnemy14ObjectsEmptyGDEnemy15ObjectsEmptyGDEnemy16ObjectsEmptyGDEnemy17ObjectsEmptyGDEnemy18ObjectsEmptyGDEnemy19ObjectsEmptyGDEnemy20ObjectsEmptyGDEnemy21ObjectsEmptyGDEnemy22ObjectsEmptyGDEnemy23ObjectsEmptyGDEnemy24ObjectsEmptyGDEnemy25ObjectsEmptyGDEnemy26ObjectsEmptyGDEnemy27ObjectsEmptyGDEnemy28ObjectsEmptyGDEnemy29ObjectsEmptyGDEnemy30Objects) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(12));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects7ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects7Objects, "Enemy" + gdjs.evtTools.common.toString(gdjs.randomInRange(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)))), gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16, "Enemies");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects7[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects7.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects7[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects7[0].getPointY("")));
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList27(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile7 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile7 );

}


{


{
/* Reuse gdjs.AutoLevelCode.GDLoadingTextObjects5 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects5[i].setString("Enemigos Generados");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects5[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList28(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList30 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 5;
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 10;
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.AutoLevelCode.GDAnimeSwordObjects6.length = 0;

gdjs.AutoLevelCode.GDKnifeObjects6.length = 0;

gdjs.AutoLevelCode.GDRegularSwordObjects6.length = 0;

gdjs.AutoLevelCode.GDRustySwordObjects6.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects6Objects, "RustySword", gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16, "Objects");
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 15;
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 20;
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.AutoLevelCode.GDAnimeSwordObjects6.length = 0;

gdjs.AutoLevelCode.GDKnifeObjects6.length = 0;

gdjs.AutoLevelCode.GDRegularSwordObjects6.length = 0;

gdjs.AutoLevelCode.GDRustySwordObjects6.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects6Objects, "RegularSword", gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16, "Objects");
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 25;
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) == 30;
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.AutoLevelCode.GDAnimeSwordObjects6.length = 0;

gdjs.AutoLevelCode.GDKnifeObjects6.length = 0;

gdjs.AutoLevelCode.GDRegularSwordObjects6.length = 0;

gdjs.AutoLevelCode.GDRustySwordObjects6.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects6ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects6Objects, "AnimeSword", gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16, "Objects");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects6);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects6);
gdjs.copyArray(runtimeScene.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects6);
gdjs.copyArray(runtimeScene.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects6);

gdjs.AutoLevelCode.forEachTotalCount7 = 0;
gdjs.AutoLevelCode.forEachObjects7.length = 0;
gdjs.AutoLevelCode.forEachCount0_7 = gdjs.AutoLevelCode.GDKnifeObjects6.length;
gdjs.AutoLevelCode.forEachTotalCount7 += gdjs.AutoLevelCode.forEachCount0_7;
gdjs.AutoLevelCode.forEachObjects7.push.apply(gdjs.AutoLevelCode.forEachObjects7,gdjs.AutoLevelCode.GDKnifeObjects6);
gdjs.AutoLevelCode.forEachCount1_7 = gdjs.AutoLevelCode.GDRustySwordObjects6.length;
gdjs.AutoLevelCode.forEachTotalCount7 += gdjs.AutoLevelCode.forEachCount1_7;
gdjs.AutoLevelCode.forEachObjects7.push.apply(gdjs.AutoLevelCode.forEachObjects7,gdjs.AutoLevelCode.GDRustySwordObjects6);
gdjs.AutoLevelCode.forEachCount2_7 = gdjs.AutoLevelCode.GDRegularSwordObjects6.length;
gdjs.AutoLevelCode.forEachTotalCount7 += gdjs.AutoLevelCode.forEachCount2_7;
gdjs.AutoLevelCode.forEachObjects7.push.apply(gdjs.AutoLevelCode.forEachObjects7,gdjs.AutoLevelCode.GDRegularSwordObjects6);
gdjs.AutoLevelCode.forEachCount3_7 = gdjs.AutoLevelCode.GDAnimeSwordObjects6.length;
gdjs.AutoLevelCode.forEachTotalCount7 += gdjs.AutoLevelCode.forEachCount3_7;
gdjs.AutoLevelCode.forEachObjects7.push.apply(gdjs.AutoLevelCode.forEachObjects7,gdjs.AutoLevelCode.GDAnimeSwordObjects6);
for(gdjs.AutoLevelCode.forEachIndex7 = 0;gdjs.AutoLevelCode.forEachIndex7 < gdjs.AutoLevelCode.forEachTotalCount7;++gdjs.AutoLevelCode.forEachIndex7) {
gdjs.AutoLevelCode.GDAnimeSwordObjects7.length = 0;

gdjs.AutoLevelCode.GDKnifeObjects7.length = 0;

gdjs.AutoLevelCode.GDRegularSwordObjects7.length = 0;

gdjs.AutoLevelCode.GDRustySwordObjects7.length = 0;


if (gdjs.AutoLevelCode.forEachIndex7 < gdjs.AutoLevelCode.forEachCount0_7) {
    gdjs.AutoLevelCode.GDKnifeObjects7.push(gdjs.AutoLevelCode.forEachObjects7[gdjs.AutoLevelCode.forEachIndex7]);
}
else if (gdjs.AutoLevelCode.forEachIndex7 < gdjs.AutoLevelCode.forEachCount0_7+gdjs.AutoLevelCode.forEachCount1_7) {
    gdjs.AutoLevelCode.GDRustySwordObjects7.push(gdjs.AutoLevelCode.forEachObjects7[gdjs.AutoLevelCode.forEachIndex7]);
}
else if (gdjs.AutoLevelCode.forEachIndex7 < gdjs.AutoLevelCode.forEachCount0_7+gdjs.AutoLevelCode.forEachCount1_7+gdjs.AutoLevelCode.forEachCount2_7) {
    gdjs.AutoLevelCode.GDRegularSwordObjects7.push(gdjs.AutoLevelCode.forEachObjects7[gdjs.AutoLevelCode.forEachIndex7]);
}
else if (gdjs.AutoLevelCode.forEachIndex7 < gdjs.AutoLevelCode.forEachCount0_7+gdjs.AutoLevelCode.forEachCount1_7+gdjs.AutoLevelCode.forEachCount2_7+gdjs.AutoLevelCode.forEachCount3_7) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects7.push(gdjs.AutoLevelCode.forEachObjects7[gdjs.AutoLevelCode.forEachIndex7]);
}
gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects7.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects7[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects7[k] = gdjs.AutoLevelCode.GDKnifeObjects7[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects7.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects7.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects7[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects7[k] = gdjs.AutoLevelCode.GDRustySwordObjects7[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects7.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects7.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects7[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects7[k] = gdjs.AutoLevelCode.GDRegularSwordObjects7[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects7.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects7.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects7[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects7[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects7[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects7.length = k;}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.AutoLevelCode.eventsList23(runtimeScene, asyncObjectsList);} //Subevents end.
}
}

}


{


gdjs.AutoLevelCode.eventsList29(runtimeScene, asyncObjectsList);
}


};gdjs.AutoLevelCode.eventsList31 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.eventsList30(runtimeScene, asyncObjectsList);
}


};gdjs.AutoLevelCode.asyncCallback9383684 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects5);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects5[i].hide();
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList31(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AutoLevelCode.eventsList32 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
/* Don't save Door as it will be provided by the parent asyncObjectsList. */
/* Don't save GenericCharacter2 as it will be provided by the parent asyncObjectsList. */
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects4) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9383684(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList33 = function(runtimeScene, asyncObjectsList) {

{



}


{


{
gdjs.AutoLevelCode.GDChestObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects5Objects, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16, "Objects");
}
{ //Subevents
gdjs.AutoLevelCode.eventsList16(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{


gdjs.AutoLevelCode.stopDoWhile6 = false;
do {gdjs.AutoLevelCode.GDCoinObjects6.length = 0;

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfEmptyGDCoinObjects) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(11));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects6Objects, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(9)) * 10) - 1) * 16, gdjs.randomInRange(0, (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(10)) * 18) - 1) * 16, "Objects");
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList19(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile6 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile6 );

}


{


{
/* Reuse gdjs.AutoLevelCode.GDLoadingTextObjects4 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects4[i].setString("Monedas Generadas");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList32(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList34 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.eventsList33(runtimeScene, asyncObjectsList);
}


};gdjs.AutoLevelCode.eventsList35 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(6), false);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList34(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.asyncCallback9470404 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects4);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects4[i].hide();
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList35(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AutoLevelCode.eventsList36 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.AutoLevelCode.GDDoorObjects3) asyncObjectsList.addObject("Door", obj);
for (const obj of gdjs.AutoLevelCode.GDGenericCharacter2Objects3) asyncObjectsList.addObject("GenericCharacter2", obj);
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects3) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9470404(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList37 = function(runtimeScene, asyncObjectsList) {

{



}


{

gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects3, gdjs.AutoLevelCode.GDGenericCharacter2Objects4);


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length;i<l;++i) {
    if ( !(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getBehavior("Pathfinding").pathFound()) ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDGenericCharacter2Objects4[k] = gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length = k;}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.AutoLevelCode.GDLoadingTextObjects3, gdjs.AutoLevelCode.GDLoadingTextObjects4);

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(6), true);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects4[i].setString("No hay ruta hacia puerta");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects4[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList13(runtimeScene, asyncObjectsList);} //End of subevents
}

}


{

/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].getBehavior("Pathfinding").pathFound() ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDGenericCharacter2Objects3[k] = gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length = k;}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */
/* Reuse gdjs.AutoLevelCode.GDLoadingTextObjects3 */
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(6), false);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].setString("Ruta hacie puerta \nEXISTENTE");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList36(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList38 = function(runtimeScene, asyncObjectsList) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);
gdjs.copyArray(runtimeScene.getObjects("NodeMarker"), gdjs.AutoLevelCode.GDNodeMarkerObjects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].activateBehavior("Pathfinding", true);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDDoorObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDDoorObjects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDDoorObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDDoorObjects3[0].getPointY("")));
}
}{runtimeScene.getVariables().getFromIndex(7).setNumber(0);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDNodeMarkerObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDNodeMarkerObjects3[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList37(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.asyncCallback9385428 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects3);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].hide();
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList38(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AutoLevelCode.eventsList39 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects2) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9385428(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList40 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.stopDoWhile4 = false;
do {gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects4);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects4);
gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setPosition(gdjs.randomInRange(0, 9) * 16,gdjs.randomInRange(0, 17) * 16);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList12(runtimeScene, asyncObjectsList);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile4 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile4 );

}


{


{
/* Reuse gdjs.AutoLevelCode.GDLoadingTextObjects2 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects2[i].setString("Personaje en suelo");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList39(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.asyncCallback9157796 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects2);

{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects2[i].hide();
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList40(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AutoLevelCode.eventsList41 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.AutoLevelCode.GDLoadingTextObjects1) asyncObjectsList.addObject("LoadingText", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9157796(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList42 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects2);
gdjs.copyArray(runtimeScene.getObjects("BlackTile"), gdjs.AutoLevelCode.GDBlackTileObjects2);
gdjs.copyArray(runtimeScene.getObjects("Chest"), gdjs.AutoLevelCode.GDChestObjects2);
gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.AutoLevelCode.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects2);
gdjs.copyArray(runtimeScene.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects2);
gdjs.copyArray(runtimeScene.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects2);
{gdjs.evtsExt__Noise__Create.func(runtimeScene, "generator", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Noise__SetFrequency.func(runtimeScene, 2, "generator", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Noise__SetSeed.func(runtimeScene, gdjs.randomInRange(1, 999999999), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(2), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(3), true);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDFloorObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDFloorObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDBlackTileObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDBlackTileObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDDoorObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDDoorObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDCoinObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDChestObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDChestObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(6), false);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.stopDoWhile3 = false;
do {gdjs.AutoLevelCode.GDFloorObjects3.length = 0;

gdjs.AutoLevelCode.GDTileObjects3.length = 0;

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(2), true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDTileObjects3Objects, 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)), 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects3Objects, 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)), 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)), "");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDTileObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDTileObjects3[i].setOpacity(gdjs.evtsExt__ExtendedMath__Map.func(runtimeScene, gdjs.evtsExt__Noise__Noise2d.func(runtimeScene, "generator", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5)), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), -(1), 1, 0, 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}{runtimeScene.getVariables().getFromIndex(1).add(1);
}{runtimeScene.getVariables().getFromIndex(4).setNumber(gdjs.randomInRange(1, 5));
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList7(runtimeScene);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile3 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile3 );

}


{


{
{runtimeScene.getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}}

}


{


gdjs.AutoLevelCode.stopDoWhile3 = false;
do {gdjs.AutoLevelCode.GDBlackTileObjects3.length = 0;

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(3), true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects, -(16), 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects, 160, 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects, 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)), -(16), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects3Objects, 16 * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)), 288, "");
}{runtimeScene.getVariables().getFromIndex(1).add(1);
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList9(runtimeScene);} //Subevents end.
}
} else gdjs.AutoLevelCode.stopDoWhile3 = true; 
} while ( !gdjs.AutoLevelCode.stopDoWhile3 );

}


{

gdjs.copyArray(runtimeScene.getObjects("Tile"), gdjs.AutoLevelCode.GDTileObjects2);

for(gdjs.AutoLevelCode.forEachIndex3 = 0;gdjs.AutoLevelCode.forEachIndex3 < gdjs.AutoLevelCode.GDTileObjects2.length;++gdjs.AutoLevelCode.forEachIndex3) {
gdjs.AutoLevelCode.GDTileObjects3.length = 0;


gdjs.AutoLevelCode.forEachTemporary3 = gdjs.AutoLevelCode.GDTileObjects2[gdjs.AutoLevelCode.forEachIndex3];
gdjs.AutoLevelCode.GDTileObjects3.push(gdjs.AutoLevelCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.AutoLevelCode.GDTileObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDTileObjects3[i].deleteFromScene(runtimeScene);
}
}
{ //Subevents: 
gdjs.AutoLevelCode.eventsList10(runtimeScene);} //Subevents end.
}
}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects1);
{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects1[i].setString("Calabozo Generado");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList41(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList43 = function(runtimeScene) {

{


gdjs.AutoLevelCode.eventsList42(runtimeScene);
}


};gdjs.AutoLevelCode.eventsList44 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.adMob.isInterstitialShowing());
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.AutoLevelCode.eventsList45 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.adMob.isInterstitialReady();
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.adMob.showInterstitial();
}
{ //Subevents
gdjs.AutoLevelCode.eventsList44(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.adMob.isInterstitialErrored();
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.AutoLevelCode.eventsList46 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = !(gdjs.evtTools.systemInfo.isMobile());
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.systemInfo.isMobile();
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList45(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList47 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) <= 0;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(0);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].setString("GAME OVER");
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList46(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 1;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(0);
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 2;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(0);
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 3;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(0);
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 4;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(0);
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 5;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(2);
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) == 6;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("UiHeart1"), gdjs.AutoLevelCode.GDUiHeart1Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart2"), gdjs.AutoLevelCode.GDUiHeart2Objects3);
gdjs.copyArray(runtimeScene.getObjects("UiHeart3"), gdjs.AutoLevelCode.GDUiHeart3Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart1Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart2Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDUiHeart3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDUiHeart3Objects3[i].setAnimation(1);
}
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) > 6;
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(6);
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadBottomObjects5Objects = Hashtable.newFrom({"DPadBottom": gdjs.AutoLevelCode.GDDPadBottomObjects5});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects4, "Door": gdjs.AutoLevelCode.GDDoorObjects4});
gdjs.AutoLevelCode.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects4);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects4);
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects4 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects4Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects4 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setCenterYInScene(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getCenterYInScene() - (16));
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadUpObjects5Objects = Hashtable.newFrom({"DPadUp": gdjs.AutoLevelCode.GDDPadUpObjects5});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects4, "Door": gdjs.AutoLevelCode.GDDoorObjects4});
gdjs.AutoLevelCode.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects4);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects4);
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects4 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects4Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects4 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setCenterYInScene(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getCenterYInScene() + (16));
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadRightObjects5Objects = Hashtable.newFrom({"DPadRight": gdjs.AutoLevelCode.GDDPadRightObjects5});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects4Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects4, "Door": gdjs.AutoLevelCode.GDDoorObjects4});
gdjs.AutoLevelCode.eventsList50 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects4);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects4);
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects4 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects4ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects4Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects4 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setCenterXInScene(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getCenterXInScene() - (16));
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadLeftObjects4Objects = Hashtable.newFrom({"DPadLeft": gdjs.AutoLevelCode.GDDPadLeftObjects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects3ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects3Objects = Hashtable.newFrom({"Floor": gdjs.AutoLevelCode.GDFloorObjects3, "Door": gdjs.AutoLevelCode.GDDoorObjects3});
gdjs.AutoLevelCode.eventsList51 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.AutoLevelCode.GDFloorObjects3);
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFloorObjects3ObjectsGDgdjs_46AutoLevelCode_46GDDoorObjects3Objects, true, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].setCenterXInScene(gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].getCenterXInScene() + (16));
}
}}

}


};gdjs.AutoLevelCode.eventsList52 = function(runtimeScene) {

{

gdjs.AutoLevelCode.GDDPadBottomObjects4.length = 0;


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.GDDPadBottomObjects4_1final.length = 0;gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadBottom"), gdjs.AutoLevelCode.GDDPadBottomObjects5);
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadBottomObjects5Objects, runtimeScene, true, false);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.AutoLevelCode.GDDPadBottomObjects5.length;j<jLen;++j) {
        if ( gdjs.AutoLevelCode.GDDPadBottomObjects4_1final.indexOf(gdjs.AutoLevelCode.GDDPadBottomObjects5[j]) === -1 )
            gdjs.AutoLevelCode.GDDPadBottomObjects4_1final.push(gdjs.AutoLevelCode.GDDPadBottomObjects5[j]);
    }
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.AutoLevelCode.GDDPadBottomObjects4_1final, gdjs.AutoLevelCode.GDDPadBottomObjects4);
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects3, gdjs.AutoLevelCode.GDGenericCharacter2Objects4);

{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setVariableBoolean(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].playAnimation();
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setY(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getY() + (16));
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList48(runtimeScene);} //End of subevents
}

}


{

gdjs.AutoLevelCode.GDDPadUpObjects4.length = 0;


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.GDDPadUpObjects4_1final.length = 0;gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadUp"), gdjs.AutoLevelCode.GDDPadUpObjects5);
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadUpObjects5Objects, runtimeScene, true, false);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.AutoLevelCode.GDDPadUpObjects5.length;j<jLen;++j) {
        if ( gdjs.AutoLevelCode.GDDPadUpObjects4_1final.indexOf(gdjs.AutoLevelCode.GDDPadUpObjects5[j]) === -1 )
            gdjs.AutoLevelCode.GDDPadUpObjects4_1final.push(gdjs.AutoLevelCode.GDDPadUpObjects5[j]);
    }
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.AutoLevelCode.GDDPadUpObjects4_1final, gdjs.AutoLevelCode.GDDPadUpObjects4);
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects3, gdjs.AutoLevelCode.GDGenericCharacter2Objects4);

{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setVariableBoolean(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].playAnimation();
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setY(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getY() - (16));
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList49(runtimeScene);} //End of subevents
}

}


{

gdjs.AutoLevelCode.GDDPadRightObjects4.length = 0;


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.GDDPadRightObjects4_1final.length = 0;gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadRight"), gdjs.AutoLevelCode.GDDPadRightObjects5);
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadRightObjects5Objects, runtimeScene, true, false);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.AutoLevelCode.GDDPadRightObjects5.length;j<jLen;++j) {
        if ( gdjs.AutoLevelCode.GDDPadRightObjects4_1final.indexOf(gdjs.AutoLevelCode.GDDPadRightObjects5[j]) === -1 )
            gdjs.AutoLevelCode.GDDPadRightObjects4_1final.push(gdjs.AutoLevelCode.GDDPadRightObjects5[j]);
    }
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.AutoLevelCode.GDDPadRightObjects4_1final, gdjs.AutoLevelCode.GDDPadRightObjects4);
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.AutoLevelCode.GDGenericCharacter2Objects3, gdjs.AutoLevelCode.GDGenericCharacter2Objects4);

{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setVariableBoolean(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].playAnimation();
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].setX(gdjs.AutoLevelCode.GDGenericCharacter2Objects4[i].getX() + (16));
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList50(runtimeScene);} //End of subevents
}

}


{

gdjs.AutoLevelCode.GDDPadLeftObjects3.length = 0;


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.GDDPadLeftObjects3_1final.length = 0;gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadLeft"), gdjs.AutoLevelCode.GDDPadLeftObjects4);
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDPadLeftObjects4Objects, runtimeScene, true, false);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.AutoLevelCode.GDDPadLeftObjects4.length;j<jLen;++j) {
        if ( gdjs.AutoLevelCode.GDDPadLeftObjects3_1final.indexOf(gdjs.AutoLevelCode.GDDPadLeftObjects4[j]) === -1 )
            gdjs.AutoLevelCode.GDDPadLeftObjects3_1final.push(gdjs.AutoLevelCode.GDDPadLeftObjects4[j]);
    }
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.AutoLevelCode.GDDPadLeftObjects3_1final, gdjs.AutoLevelCode.GDDPadLeftObjects3);
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].setVariableBoolean(gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].playAnimation();
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].setX(gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].getX() - (16));
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects2});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects2Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects2});
gdjs.AutoLevelCode.asyncCallback9469116 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);

{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].pauseAnimation();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}
gdjs.AutoLevelCode.eventsList53 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.AutoLevelCode.GDGenericCharacter2Objects2) asyncObjectsList.addObject("GenericCharacter2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9469116(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList54 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects2);
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects2 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects2Objects, true, runtimeScene, false);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList53(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList55 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "GrupoTouch");
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects3[i].pauseAnimation();
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList52(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects2);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i].getVariableBoolean(gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i].getVariables().getFromIndex(0), true) ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDGenericCharacter2Objects2[k] = gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length = k;}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects2 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i].setVariableBoolean(gdjs.AutoLevelCode.GDGenericCharacter2Objects2[i].getVariables().getFromIndex(0), false);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList54(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects2});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects2Objects = Hashtable.newFrom({"Door": gdjs.AutoLevelCode.GDDoorObjects2});
gdjs.AutoLevelCode.asyncCallback11507236 = function (runtimeScene, asyncObjectsList) {
}
gdjs.AutoLevelCode.eventsList56 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11507236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList57 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ganado", false);
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", true);
}}

}


};gdjs.AutoLevelCode.asyncCallback11462892 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AutoLevelCode.eventsList57(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AutoLevelCode.eventsList58 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11462892(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList59 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ganado", true);
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", true);
}}

}


};gdjs.AutoLevelCode.eventsList60 = function(runtimeScene, asyncObjectsList) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.adMob.isInterstitialShowing());
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList59(runtimeScene, asyncObjectsList);} //End of subevents
}

}


};gdjs.AutoLevelCode.asyncCallback11517844 = function (runtimeScene, asyncObjectsList) {

{ //Subevents
gdjs.AutoLevelCode.eventsList60(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.AutoLevelCode.eventsList61 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11517844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList62 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ganado", true);
}}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)));
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", true);
}}

}


};gdjs.AutoLevelCode.eventsList63 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.adMob.isInterstitialReady();
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.adMob.showInterstitial();
}
{ //Subevents
gdjs.AutoLevelCode.eventsList61(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.adMob.isInterstitialErrored();
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = !(gdjs.adMob.isInterstitialReady());
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList62(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList64 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9137524);
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.AutoLevelCode.GDDoorObjects2, gdjs.AutoLevelCode.GDDoorObjects3);

gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.AutoLevelCode.GDLoadingTextObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/OpenDoor.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDDoorObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDDoorObjects3[i].setAnimation(0);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].setString("Cargando Nivel");
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDLoadingTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDLoadingTextObjects3[i].hide(false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(7).add(20);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList56(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = !(gdjs.evtTools.systemInfo.isMobile());
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList58(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_1.val = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.systemInfo.isMobile();
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList63(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.eventsList65 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.AutoLevelCode.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects2);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDDoorObjects2Objects, false, runtimeScene, false);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects3, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects3, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects3, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects3, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects3, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects3, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects4Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects4, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects4, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects4, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects4Objects = Hashtable.newFrom({"BlackTile": gdjs.AutoLevelCode.GDBlackTileObjects4});
gdjs.AutoLevelCode.eventsList66 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.AutoLevelCode.GDAnimeSwordObjects3, gdjs.AutoLevelCode.GDAnimeSwordObjects4);

gdjs.copyArray(runtimeScene.getObjects("BlackTile"), gdjs.AutoLevelCode.GDBlackTileObjects4);
gdjs.copyArray(gdjs.AutoLevelCode.GDKnifeObjects3, gdjs.AutoLevelCode.GDKnifeObjects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDRegularSwordObjects3, gdjs.AutoLevelCode.GDRegularSwordObjects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDRustySwordObjects3, gdjs.AutoLevelCode.GDRustySwordObjects4);


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects4[i].isOnLayer("UI") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects4[k] = gdjs.AutoLevelCode.GDKnifeObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects4.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects4[i].isOnLayer("UI") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects4[k] = gdjs.AutoLevelCode.GDRustySwordObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects4.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects4[i].isOnLayer("UI") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects4[k] = gdjs.AutoLevelCode.GDRegularSwordObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects4.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects4[i].isOnLayer("UI") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects4[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects4.length = k;}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
gdjs.AutoLevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDBlackTileObjects4Objects, false, runtimeScene, false);
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects4 */
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects4 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects4 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects4 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects3 */
gdjs.copyArray(runtimeScene.getObjects("BlankButton"), gdjs.AutoLevelCode.GDBlankButtonObjects3);
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].setPosition((( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointX("Origin")),(( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointY("Origin")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].setPosition((( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointX("Origin")),(( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointY("Origin")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].setPosition((( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointX("Origin")),(( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointY("Origin")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].setPosition((( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointX("Origin")),(( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointY("Origin")));
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].setLayer("UI");
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].setLayer("UI");
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].setLayer("UI");
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].setLayer("UI");
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFireRoundButtonObjects4Objects = Hashtable.newFrom({"FireRoundButton": gdjs.AutoLevelCode.GDFireRoundButtonObjects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects3, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects3, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects3, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects3});
gdjs.AutoLevelCode.asyncCallback11486708 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3), false);
}}
gdjs.AutoLevelCode.eventsList67 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11486708(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList68 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = 0;

gdjs.AutoLevelCode.GDKnifeObjects3.length = 0;

gdjs.AutoLevelCode.GDRegularSwordObjects3.length = 0;

gdjs.AutoLevelCode.GDRustySwordObjects3.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("Origin")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("Origin")), "Player");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].setZOrder(1000);
}
}
{ //Subevents
gdjs.AutoLevelCode.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.AutoLevelCode.mapOfEmptyGDEnemy9ObjectsEmptyGDEnemy1ObjectsEmptyGDEnemy2ObjectsEmptyGDEnemy3ObjectsEmptyGDEnemy4ObjectsEmptyGDEnemy5ObjectsEmptyGDEnemy6ObjectsEmptyGDEnemy7ObjectsEmptyGDEnemy8ObjectsEmptyGDEnemy10ObjectsEmptyGDEnemy11ObjectsEmptyGDEnemy12ObjectsEmptyGDEnemy13ObjectsEmptyGDEnemy14ObjectsEmptyGDEnemy15ObjectsEmptyGDEnemy16ObjectsEmptyGDEnemy17ObjectsEmptyGDEnemy18ObjectsEmptyGDEnemy19ObjectsEmptyGDEnemy20ObjectsEmptyGDEnemy21ObjectsEmptyGDEnemy22ObjectsEmptyGDEnemy23ObjectsEmptyGDEnemy24ObjectsEmptyGDEnemy25ObjectsEmptyGDEnemy26ObjectsEmptyGDEnemy27ObjectsEmptyGDEnemy28ObjectsEmptyGDEnemy29ObjectsEmptyGDEnemy30Objects = Hashtable.newFrom({"Enemy9": [], "Enemy1": [], "Enemy2": [], "Enemy3": [], "Enemy4": [], "Enemy5": [], "Enemy6": [], "Enemy7": [], "Enemy8": [], "Enemy10": [], "Enemy11": [], "Enemy12": [], "Enemy13": [], "Enemy14": [], "Enemy15": [], "Enemy16": [], "Enemy17": [], "Enemy18": [], "Enemy19": [], "Enemy20": [], "Enemy21": [], "Enemy22": [], "Enemy23": [], "Enemy24": [], "Enemy25": [], "Enemy26": [], "Enemy27": [], "Enemy28": [], "Enemy29": [], "Enemy30": []});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects3, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects3, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects3, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects3, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects3, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects3, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects3, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects3, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects3, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects3, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects3, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects3, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects3, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects3, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects3, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects3, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects3, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects3, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects3, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects3, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects3, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects3, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects3, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects3, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects3, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects3, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects3, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects3, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects3, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects4Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects4, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects4, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects4, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects4, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects4, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects4, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects4, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects4, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects4, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects4, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects4, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects4, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects4, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects4, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects4, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects4, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects4, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects4, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects4, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects4, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects4, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects4, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects4, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects4, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects4, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects4, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects4, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects4, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects4, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects4});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects4Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects4, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects4, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects4, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects4});
gdjs.AutoLevelCode.asyncCallback9476740 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects5);

{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects5[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects5.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects5[i].deleteFromScene(runtimeScene);
}
}}
gdjs.AutoLevelCode.eventsList69 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.AutoLevelCode.GDAnimeSwordObjects4) asyncObjectsList.addObject("AnimeSword", obj);
for (const obj of gdjs.AutoLevelCode.GDKnifeObjects4) asyncObjectsList.addObject("Knife", obj);
for (const obj of gdjs.AutoLevelCode.GDRegularSwordObjects4) asyncObjectsList.addObject("RegularSword", obj);
for (const obj of gdjs.AutoLevelCode.GDRustySwordObjects4) asyncObjectsList.addObject("RustySword", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback9476740(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects3, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects3, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects3, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects3, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects3, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects3, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects3, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects3, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects3, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects3, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects3, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects3, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects3, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects3, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects3, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects3, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects3, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects3, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects3, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects3, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects3, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects3, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects3, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects3, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects3, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects3, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects3, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects3, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects3, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects3, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects3, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects3, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects3});
gdjs.AutoLevelCode.eventsList70 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.AutoLevelCode.GDAnimeSwordObjects3, gdjs.AutoLevelCode.GDAnimeSwordObjects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy1Objects3, gdjs.AutoLevelCode.GDEnemy1Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy10Objects3, gdjs.AutoLevelCode.GDEnemy10Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy11Objects3, gdjs.AutoLevelCode.GDEnemy11Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy12Objects3, gdjs.AutoLevelCode.GDEnemy12Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy13Objects3, gdjs.AutoLevelCode.GDEnemy13Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy14Objects3, gdjs.AutoLevelCode.GDEnemy14Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy15Objects3, gdjs.AutoLevelCode.GDEnemy15Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy16Objects3, gdjs.AutoLevelCode.GDEnemy16Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy17Objects3, gdjs.AutoLevelCode.GDEnemy17Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy18Objects3, gdjs.AutoLevelCode.GDEnemy18Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy19Objects3, gdjs.AutoLevelCode.GDEnemy19Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy2Objects3, gdjs.AutoLevelCode.GDEnemy2Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy20Objects3, gdjs.AutoLevelCode.GDEnemy20Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy21Objects3, gdjs.AutoLevelCode.GDEnemy21Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy22Objects3, gdjs.AutoLevelCode.GDEnemy22Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy23Objects3, gdjs.AutoLevelCode.GDEnemy23Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy24Objects3, gdjs.AutoLevelCode.GDEnemy24Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy25Objects3, gdjs.AutoLevelCode.GDEnemy25Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy26Objects3, gdjs.AutoLevelCode.GDEnemy26Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy27Objects3, gdjs.AutoLevelCode.GDEnemy27Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy28Objects3, gdjs.AutoLevelCode.GDEnemy28Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy29Objects3, gdjs.AutoLevelCode.GDEnemy29Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy3Objects3, gdjs.AutoLevelCode.GDEnemy3Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy30Objects3, gdjs.AutoLevelCode.GDEnemy30Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy4Objects3, gdjs.AutoLevelCode.GDEnemy4Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy5Objects3, gdjs.AutoLevelCode.GDEnemy5Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy6Objects3, gdjs.AutoLevelCode.GDEnemy6Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy7Objects3, gdjs.AutoLevelCode.GDEnemy7Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy8Objects3, gdjs.AutoLevelCode.GDEnemy8Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDEnemy9Objects3, gdjs.AutoLevelCode.GDEnemy9Objects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDKnifeObjects3, gdjs.AutoLevelCode.GDKnifeObjects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDRegularSwordObjects3, gdjs.AutoLevelCode.GDRegularSwordObjects4);

gdjs.copyArray(gdjs.AutoLevelCode.GDRustySwordObjects3, gdjs.AutoLevelCode.GDRustySwordObjects4);


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects4ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects4Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects4ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects4Objects, 16 * 3, true);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects4[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects4[k] = gdjs.AutoLevelCode.GDKnifeObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects4.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects4[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects4[k] = gdjs.AutoLevelCode.GDRustySwordObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects4.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects4[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects4[k] = gdjs.AutoLevelCode.GDRegularSwordObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects4.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects4.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects4[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects4[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects4[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects4.length = k;}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList69(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects3 */
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects3 */

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects, 16 * 3, false);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects3[k] = gdjs.AutoLevelCode.GDKnifeObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects3[k] = gdjs.AutoLevelCode.GDRustySwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects3[k] = gdjs.AutoLevelCode.GDRegularSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects3[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = k;}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects3 */
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].setAngle((( gdjs.AutoLevelCode.GDEnemy30Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy29Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy28Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy27Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy26Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy25Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy24Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy23Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy22Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy21Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy20Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy19Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy18Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy17Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy16Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy15Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy14Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy13Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy12Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy11Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy10Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy8Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy7Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy6Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy5Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy4Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy3Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy2Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy1Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy9Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDEnemy9Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy1Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy3Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy4Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy5Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy6Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy7Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy8Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy10Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy11Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy12Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy13Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy14Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy15Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy16Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy17Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy18Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy19Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy20Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy21Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy22Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy23Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy24Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy25Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy26Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy27Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy28Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy29Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) :gdjs.AutoLevelCode.GDEnemy30Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDKnifeObjects3[i])) - 90);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].setAngle((( gdjs.AutoLevelCode.GDEnemy30Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy29Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy28Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy27Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy26Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy25Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy24Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy23Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy22Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy21Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy20Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy19Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy18Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy17Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy16Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy15Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy14Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy13Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy12Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy11Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy10Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy8Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy7Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy6Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy5Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy4Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy3Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy2Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy1Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy9Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDEnemy9Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy1Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy3Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy4Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy5Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy6Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy7Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy8Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy10Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy11Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy12Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy13Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy14Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy15Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy16Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy17Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy18Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy19Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy20Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy21Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy22Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy23Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy24Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy25Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy26Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy27Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy28Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy29Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy30Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRustySwordObjects3[i])) - 90);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].setAngle((( gdjs.AutoLevelCode.GDEnemy30Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy29Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy28Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy27Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy26Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy25Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy24Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy23Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy22Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy21Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy20Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy19Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy18Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy17Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy16Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy15Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy14Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy13Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy12Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy11Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy10Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy8Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy7Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy6Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy5Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy4Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy3Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy2Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy1Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy9Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDEnemy9Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy1Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy3Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy4Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy5Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy6Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy7Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy8Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy10Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy11Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy12Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy13Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy14Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy15Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy16Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy17Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy18Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy19Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy20Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy21Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy22Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy23Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy24Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy25Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy26Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy27Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy28Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy29Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy30Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDRegularSwordObjects3[i])) - 90);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].setAngle((( gdjs.AutoLevelCode.GDEnemy30Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy29Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy28Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy27Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy26Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy25Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy24Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy23Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy22Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy21Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy20Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy19Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy18Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy17Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy16Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy15Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy14Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy13Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy12Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy11Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy10Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy8Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy7Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy6Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy5Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy4Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy3Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy2Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy1Objects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDEnemy9Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDEnemy9Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy1Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy3Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy4Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy5Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy6Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy7Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy8Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy10Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy11Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy12Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy13Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy14Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy15Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy16Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy17Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy18Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy19Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy20Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy21Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy22Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy23Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy24Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy25Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy26Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy27Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy28Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy29Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) :gdjs.AutoLevelCode.GDEnemy30Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDAnimeSwordObjects3[i])) - 90);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].addForceTowardObject((gdjs.AutoLevelCode.GDEnemy9Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy9Objects3[0] : (gdjs.AutoLevelCode.GDEnemy1Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy1Objects3[0] : (gdjs.AutoLevelCode.GDEnemy2Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy2Objects3[0] : (gdjs.AutoLevelCode.GDEnemy3Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy3Objects3[0] : (gdjs.AutoLevelCode.GDEnemy4Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy4Objects3[0] : (gdjs.AutoLevelCode.GDEnemy5Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy5Objects3[0] : (gdjs.AutoLevelCode.GDEnemy6Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy6Objects3[0] : (gdjs.AutoLevelCode.GDEnemy7Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy7Objects3[0] : (gdjs.AutoLevelCode.GDEnemy8Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy8Objects3[0] : (gdjs.AutoLevelCode.GDEnemy10Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy10Objects3[0] : (gdjs.AutoLevelCode.GDEnemy11Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy11Objects3[0] : (gdjs.AutoLevelCode.GDEnemy12Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy12Objects3[0] : (gdjs.AutoLevelCode.GDEnemy13Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy13Objects3[0] : (gdjs.AutoLevelCode.GDEnemy14Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy14Objects3[0] : (gdjs.AutoLevelCode.GDEnemy15Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy15Objects3[0] : (gdjs.AutoLevelCode.GDEnemy16Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy16Objects3[0] : (gdjs.AutoLevelCode.GDEnemy17Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy17Objects3[0] : (gdjs.AutoLevelCode.GDEnemy18Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy18Objects3[0] : (gdjs.AutoLevelCode.GDEnemy19Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy19Objects3[0] : (gdjs.AutoLevelCode.GDEnemy20Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy20Objects3[0] : (gdjs.AutoLevelCode.GDEnemy21Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy21Objects3[0] : (gdjs.AutoLevelCode.GDEnemy22Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy22Objects3[0] : (gdjs.AutoLevelCode.GDEnemy23Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy23Objects3[0] : (gdjs.AutoLevelCode.GDEnemy24Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy24Objects3[0] : (gdjs.AutoLevelCode.GDEnemy25Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy25Objects3[0] : (gdjs.AutoLevelCode.GDEnemy26Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy26Objects3[0] : (gdjs.AutoLevelCode.GDEnemy27Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy27Objects3[0] : (gdjs.AutoLevelCode.GDEnemy28Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy28Objects3[0] : (gdjs.AutoLevelCode.GDEnemy29Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy29Objects3[0] : (gdjs.AutoLevelCode.GDEnemy30Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy30Objects3[0] : null)))))))))))))))))))))))))))))), 16, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].addForceTowardObject((gdjs.AutoLevelCode.GDEnemy9Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy9Objects3[0] : (gdjs.AutoLevelCode.GDEnemy1Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy1Objects3[0] : (gdjs.AutoLevelCode.GDEnemy2Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy2Objects3[0] : (gdjs.AutoLevelCode.GDEnemy3Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy3Objects3[0] : (gdjs.AutoLevelCode.GDEnemy4Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy4Objects3[0] : (gdjs.AutoLevelCode.GDEnemy5Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy5Objects3[0] : (gdjs.AutoLevelCode.GDEnemy6Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy6Objects3[0] : (gdjs.AutoLevelCode.GDEnemy7Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy7Objects3[0] : (gdjs.AutoLevelCode.GDEnemy8Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy8Objects3[0] : (gdjs.AutoLevelCode.GDEnemy10Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy10Objects3[0] : (gdjs.AutoLevelCode.GDEnemy11Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy11Objects3[0] : (gdjs.AutoLevelCode.GDEnemy12Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy12Objects3[0] : (gdjs.AutoLevelCode.GDEnemy13Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy13Objects3[0] : (gdjs.AutoLevelCode.GDEnemy14Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy14Objects3[0] : (gdjs.AutoLevelCode.GDEnemy15Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy15Objects3[0] : (gdjs.AutoLevelCode.GDEnemy16Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy16Objects3[0] : (gdjs.AutoLevelCode.GDEnemy17Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy17Objects3[0] : (gdjs.AutoLevelCode.GDEnemy18Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy18Objects3[0] : (gdjs.AutoLevelCode.GDEnemy19Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy19Objects3[0] : (gdjs.AutoLevelCode.GDEnemy20Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy20Objects3[0] : (gdjs.AutoLevelCode.GDEnemy21Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy21Objects3[0] : (gdjs.AutoLevelCode.GDEnemy22Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy22Objects3[0] : (gdjs.AutoLevelCode.GDEnemy23Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy23Objects3[0] : (gdjs.AutoLevelCode.GDEnemy24Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy24Objects3[0] : (gdjs.AutoLevelCode.GDEnemy25Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy25Objects3[0] : (gdjs.AutoLevelCode.GDEnemy26Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy26Objects3[0] : (gdjs.AutoLevelCode.GDEnemy27Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy27Objects3[0] : (gdjs.AutoLevelCode.GDEnemy28Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy28Objects3[0] : (gdjs.AutoLevelCode.GDEnemy29Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy29Objects3[0] : (gdjs.AutoLevelCode.GDEnemy30Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy30Objects3[0] : null)))))))))))))))))))))))))))))), 16, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].addForceTowardObject((gdjs.AutoLevelCode.GDEnemy9Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy9Objects3[0] : (gdjs.AutoLevelCode.GDEnemy1Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy1Objects3[0] : (gdjs.AutoLevelCode.GDEnemy2Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy2Objects3[0] : (gdjs.AutoLevelCode.GDEnemy3Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy3Objects3[0] : (gdjs.AutoLevelCode.GDEnemy4Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy4Objects3[0] : (gdjs.AutoLevelCode.GDEnemy5Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy5Objects3[0] : (gdjs.AutoLevelCode.GDEnemy6Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy6Objects3[0] : (gdjs.AutoLevelCode.GDEnemy7Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy7Objects3[0] : (gdjs.AutoLevelCode.GDEnemy8Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy8Objects3[0] : (gdjs.AutoLevelCode.GDEnemy10Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy10Objects3[0] : (gdjs.AutoLevelCode.GDEnemy11Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy11Objects3[0] : (gdjs.AutoLevelCode.GDEnemy12Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy12Objects3[0] : (gdjs.AutoLevelCode.GDEnemy13Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy13Objects3[0] : (gdjs.AutoLevelCode.GDEnemy14Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy14Objects3[0] : (gdjs.AutoLevelCode.GDEnemy15Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy15Objects3[0] : (gdjs.AutoLevelCode.GDEnemy16Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy16Objects3[0] : (gdjs.AutoLevelCode.GDEnemy17Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy17Objects3[0] : (gdjs.AutoLevelCode.GDEnemy18Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy18Objects3[0] : (gdjs.AutoLevelCode.GDEnemy19Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy19Objects3[0] : (gdjs.AutoLevelCode.GDEnemy20Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy20Objects3[0] : (gdjs.AutoLevelCode.GDEnemy21Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy21Objects3[0] : (gdjs.AutoLevelCode.GDEnemy22Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy22Objects3[0] : (gdjs.AutoLevelCode.GDEnemy23Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy23Objects3[0] : (gdjs.AutoLevelCode.GDEnemy24Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy24Objects3[0] : (gdjs.AutoLevelCode.GDEnemy25Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy25Objects3[0] : (gdjs.AutoLevelCode.GDEnemy26Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy26Objects3[0] : (gdjs.AutoLevelCode.GDEnemy27Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy27Objects3[0] : (gdjs.AutoLevelCode.GDEnemy28Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy28Objects3[0] : (gdjs.AutoLevelCode.GDEnemy29Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy29Objects3[0] : (gdjs.AutoLevelCode.GDEnemy30Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy30Objects3[0] : null)))))))))))))))))))))))))))))), 16, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].addForceTowardObject((gdjs.AutoLevelCode.GDEnemy9Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy9Objects3[0] : (gdjs.AutoLevelCode.GDEnemy1Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy1Objects3[0] : (gdjs.AutoLevelCode.GDEnemy2Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy2Objects3[0] : (gdjs.AutoLevelCode.GDEnemy3Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy3Objects3[0] : (gdjs.AutoLevelCode.GDEnemy4Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy4Objects3[0] : (gdjs.AutoLevelCode.GDEnemy5Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy5Objects3[0] : (gdjs.AutoLevelCode.GDEnemy6Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy6Objects3[0] : (gdjs.AutoLevelCode.GDEnemy7Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy7Objects3[0] : (gdjs.AutoLevelCode.GDEnemy8Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy8Objects3[0] : (gdjs.AutoLevelCode.GDEnemy10Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy10Objects3[0] : (gdjs.AutoLevelCode.GDEnemy11Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy11Objects3[0] : (gdjs.AutoLevelCode.GDEnemy12Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy12Objects3[0] : (gdjs.AutoLevelCode.GDEnemy13Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy13Objects3[0] : (gdjs.AutoLevelCode.GDEnemy14Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy14Objects3[0] : (gdjs.AutoLevelCode.GDEnemy15Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy15Objects3[0] : (gdjs.AutoLevelCode.GDEnemy16Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy16Objects3[0] : (gdjs.AutoLevelCode.GDEnemy17Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy17Objects3[0] : (gdjs.AutoLevelCode.GDEnemy18Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy18Objects3[0] : (gdjs.AutoLevelCode.GDEnemy19Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy19Objects3[0] : (gdjs.AutoLevelCode.GDEnemy20Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy20Objects3[0] : (gdjs.AutoLevelCode.GDEnemy21Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy21Objects3[0] : (gdjs.AutoLevelCode.GDEnemy22Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy22Objects3[0] : (gdjs.AutoLevelCode.GDEnemy23Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy23Objects3[0] : (gdjs.AutoLevelCode.GDEnemy24Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy24Objects3[0] : (gdjs.AutoLevelCode.GDEnemy25Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy25Objects3[0] : (gdjs.AutoLevelCode.GDEnemy26Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy26Objects3[0] : (gdjs.AutoLevelCode.GDEnemy27Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy27Objects3[0] : (gdjs.AutoLevelCode.GDEnemy28Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy28Objects3[0] : (gdjs.AutoLevelCode.GDEnemy29Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy29Objects3[0] : (gdjs.AutoLevelCode.GDEnemy30Objects3.length !== 0 ? gdjs.AutoLevelCode.GDEnemy30Objects3[0] : null)))))))))))))))))))))))))))))), 16, 0);
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects2ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects2ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects2ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects2Objects = Hashtable.newFrom({"Knife": gdjs.AutoLevelCode.GDKnifeObjects2, "RustySword": gdjs.AutoLevelCode.GDRustySwordObjects2, "RegularSword": gdjs.AutoLevelCode.GDRegularSwordObjects2, "AnimeSword": gdjs.AutoLevelCode.GDAnimeSwordObjects2});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects2Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects2, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects2, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects2, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects2, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects2, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects2, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects2, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects2, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects2, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects2, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects2, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects2, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects2, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects2, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects2, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects2, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects2, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects2, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects2, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects2, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects2, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects2, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects2, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects2, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects2, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects2, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects2, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects2, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects2, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects2});
gdjs.AutoLevelCode.eventsList71 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BlankButton"), gdjs.AutoLevelCode.GDBlankButtonObjects3);
gdjs.copyArray(runtimeScene.getObjects("TextoArma"), gdjs.AutoLevelCode.GDTextoArmaObjects3);
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = 0;

gdjs.AutoLevelCode.GDKnifeObjects3.length = 0;

gdjs.AutoLevelCode.GDRegularSwordObjects3.length = 0;

gdjs.AutoLevelCode.GDRustySwordObjects3.length = 0;

{for(var i = 0, len = gdjs.AutoLevelCode.GDTextoArmaObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDTextoArmaObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)));
}
}{gdjs.evtTools.object.createObjectFromGroupOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects, gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(9)), (( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDBlankButtonObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDBlankButtonObjects3[0].getPointY("")), "UI");
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].setZOrder(1000);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].setZOrder(1000);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects3);
gdjs.copyArray(runtimeScene.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects3ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects, false, runtimeScene, true);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects3[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects3[k] = gdjs.AutoLevelCode.GDKnifeObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects3[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects3[k] = gdjs.AutoLevelCode.GDRustySwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects3[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects3[k] = gdjs.AutoLevelCode.GDRegularSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].isOnLayer("Objects") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects3[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = k;}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/RecojeArma.wav", false, 80, 1);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(9).setString((( gdjs.AutoLevelCode.GDAnimeSwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDRegularSwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDRustySwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDKnifeObjects3.length === 0 ) ? "" :gdjs.AutoLevelCode.GDKnifeObjects3[0].getName()) :gdjs.AutoLevelCode.GDRustySwordObjects3[0].getName()) :gdjs.AutoLevelCode.GDRegularSwordObjects3[0].getName()) :gdjs.AutoLevelCode.GDAnimeSwordObjects3[0].getName()));
}
{ //Subevents
gdjs.AutoLevelCode.eventsList66(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.AutoLevelCode.GDFireRoundButtonObjects3.length = 0;


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition0IsTrue_0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects3_1final.length = 0;gdjs.AutoLevelCode.condition0IsTrue_1.val = false;
gdjs.AutoLevelCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("FireRoundButton"), gdjs.AutoLevelCode.GDFireRoundButtonObjects4);
gdjs.AutoLevelCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDFireRoundButtonObjects4Objects, runtimeScene, true, false);
if( gdjs.AutoLevelCode.condition0IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.AutoLevelCode.GDFireRoundButtonObjects4.length;j<jLen;++j) {
        if ( gdjs.AutoLevelCode.GDFireRoundButtonObjects3_1final.indexOf(gdjs.AutoLevelCode.GDFireRoundButtonObjects4[j]) === -1 )
            gdjs.AutoLevelCode.GDFireRoundButtonObjects3_1final.push(gdjs.AutoLevelCode.GDFireRoundButtonObjects4[j]);
    }
}
}
{
gdjs.AutoLevelCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.AutoLevelCode.condition1IsTrue_1.val ) {
    gdjs.AutoLevelCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.AutoLevelCode.GDFireRoundButtonObjects3_1final, gdjs.AutoLevelCode.GDFireRoundButtonObjects3);
}
}
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
gdjs.AutoLevelCode.condition1IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3), false);
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(3), true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/PlayerAtack.wav", false, 100, 1);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList68(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects3);
gdjs.copyArray(runtimeScene.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.AutoLevelCode.mapOfEmptyGDEnemy9ObjectsEmptyGDEnemy1ObjectsEmptyGDEnemy2ObjectsEmptyGDEnemy3ObjectsEmptyGDEnemy4ObjectsEmptyGDEnemy5ObjectsEmptyGDEnemy6ObjectsEmptyGDEnemy7ObjectsEmptyGDEnemy8ObjectsEmptyGDEnemy10ObjectsEmptyGDEnemy11ObjectsEmptyGDEnemy12ObjectsEmptyGDEnemy13ObjectsEmptyGDEnemy14ObjectsEmptyGDEnemy15ObjectsEmptyGDEnemy16ObjectsEmptyGDEnemy17ObjectsEmptyGDEnemy18ObjectsEmptyGDEnemy19ObjectsEmptyGDEnemy20ObjectsEmptyGDEnemy21ObjectsEmptyGDEnemy22ObjectsEmptyGDEnemy23ObjectsEmptyGDEnemy24ObjectsEmptyGDEnemy25ObjectsEmptyGDEnemy26ObjectsEmptyGDEnemy27ObjectsEmptyGDEnemy28ObjectsEmptyGDEnemy29ObjectsEmptyGDEnemy30Objects) == 0;
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects3[k] = gdjs.AutoLevelCode.GDKnifeObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects3[k] = gdjs.AutoLevelCode.GDRustySwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects3[k] = gdjs.AutoLevelCode.GDRegularSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects3[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = k;}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects3 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects3[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects3);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects3);
gdjs.copyArray(runtimeScene.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects3[k] = gdjs.AutoLevelCode.GDKnifeObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects3[k] = gdjs.AutoLevelCode.GDRustySwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects3[k] = gdjs.AutoLevelCode.GDRegularSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects3.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects3.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects3[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects3[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects3[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = k;}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
gdjs.AutoLevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects, (( gdjs.AutoLevelCode.GDAnimeSwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDRegularSwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDRustySwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDKnifeObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDKnifeObjects3[0].getPointX("Center")) :gdjs.AutoLevelCode.GDRustySwordObjects3[0].getPointX("Center")) :gdjs.AutoLevelCode.GDRegularSwordObjects3[0].getPointX("Center")) :gdjs.AutoLevelCode.GDAnimeSwordObjects3[0].getPointX("Center")), (( gdjs.AutoLevelCode.GDAnimeSwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDRegularSwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDRustySwordObjects3.length === 0 ) ? (( gdjs.AutoLevelCode.GDKnifeObjects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDKnifeObjects3[0].getPointY("Center")) :gdjs.AutoLevelCode.GDRustySwordObjects3[0].getPointY("Center")) :gdjs.AutoLevelCode.GDRegularSwordObjects3[0].getPointY("Center")) :gdjs.AutoLevelCode.GDAnimeSwordObjects3[0].getPointY("Center")), false);
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList70(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("AnimeSword"), gdjs.AutoLevelCode.GDAnimeSwordObjects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects2);
gdjs.copyArray(runtimeScene.getObjects("Knife"), gdjs.AutoLevelCode.GDKnifeObjects2);
gdjs.copyArray(runtimeScene.getObjects("RegularSword"), gdjs.AutoLevelCode.GDRegularSwordObjects2);
gdjs.copyArray(runtimeScene.getObjects("RustySword"), gdjs.AutoLevelCode.GDRustySwordObjects2);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDKnifeObjects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDKnifeObjects2[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDKnifeObjects2[k] = gdjs.AutoLevelCode.GDKnifeObjects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDKnifeObjects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRustySwordObjects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRustySwordObjects2[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRustySwordObjects2[k] = gdjs.AutoLevelCode.GDRustySwordObjects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRustySwordObjects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDRegularSwordObjects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDRegularSwordObjects2[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDRegularSwordObjects2[k] = gdjs.AutoLevelCode.GDRegularSwordObjects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDRegularSwordObjects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDAnimeSwordObjects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDAnimeSwordObjects2[i].isOnLayer("Player") ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDAnimeSwordObjects2[k] = gdjs.AutoLevelCode.GDAnimeSwordObjects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDAnimeSwordObjects2.length = k;}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
gdjs.AutoLevelCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDKnifeObjects2ObjectsGDgdjs_46AutoLevelCode_46GDRustySwordObjects2ObjectsGDgdjs_46AutoLevelCode_46GDRegularSwordObjects2ObjectsGDgdjs_46AutoLevelCode_46GDAnimeSwordObjects2Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects2ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects2Objects, false, runtimeScene, true);
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDAnimeSwordObjects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects2 */
/* Reuse gdjs.AutoLevelCode.GDKnifeObjects2 */
/* Reuse gdjs.AutoLevelCode.GDRegularSwordObjects2 */
/* Reuse gdjs.AutoLevelCode.GDRustySwordObjects2 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDKnifeObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDKnifeObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRustySwordObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRustySwordObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDRegularSwordObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDRegularSwordObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDAnimeSwordObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDAnimeSwordObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy9Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy1Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy2Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy3Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy4Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy5Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy6Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy7Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy8Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy10Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy11Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy12Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy13Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy14Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy15Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy16Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy17Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy18Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy19Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy20Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy21Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy22Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy23Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy24Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy25Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy26Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy27Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy28Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy29Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects2[i].returnVariable(gdjs.AutoLevelCode.GDEnemy30Objects2[i].getVariables().get("Salud")).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDAnimeSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRegularSwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDRustySwordObjects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDKnifeObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDKnifeObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRustySwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDRegularSwordObjects2[0].getVariables()) : gdjs.AutoLevelCode.GDAnimeSwordObjects2[0].getVariables()).get("Ataque"))));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/EnemyHurt.wav", false, 40, 1);
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects3Objects = Hashtable.newFrom({"Coin": gdjs.AutoLevelCode.GDCoinObjects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects2});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects2Objects = Hashtable.newFrom({"Chest": gdjs.AutoLevelCode.GDChestObjects2});
gdjs.AutoLevelCode.eventsList72 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.AutoLevelCode.GDCoinObjects3);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDCoinObjects3Objects, false, runtimeScene, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDCoinObjects3 */
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.AutoLevelCode.GDScoreTextObjects3);
{for(var i = 0, len = gdjs.AutoLevelCode.GDCoinObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDCoinObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/PickCoin.wav", false, 80, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(7).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDCoinObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDCoinObjects3[0].getVariables()).getFromIndex(0))));
}{for(var i = 0, len = gdjs.AutoLevelCode.GDScoreTextObjects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDScoreTextObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) + " pt");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Chest"), gdjs.AutoLevelCode.GDChestObjects2);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects2);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects2Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDChestObjects2Objects, false, runtimeScene, true);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDChestObjects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDChestObjects2[i].getAnimation() == 0 ) {
        gdjs.AutoLevelCode.condition1IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDChestObjects2[k] = gdjs.AutoLevelCode.GDChestObjects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDChestObjects2.length = k;}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDChestObjects2 */
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.AutoLevelCode.GDScoreTextObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/PickCoin.wav", false, 80, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(7).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDChestObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDChestObjects2[0].getVariables()).getFromIndex(0))));
}{for(var i = 0, len = gdjs.AutoLevelCode.GDChestObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDChestObjects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDScoreTextObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) + " pt");
}
}}

}


};gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects3, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects3, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects3, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects3, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects3, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects3, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects3, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects3, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects3, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects3, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects3, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects3, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects3, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects3, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects3, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects3, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects3, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects3, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects3, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects3, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects3, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects3, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects3, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects3, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects3, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects3, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects3, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects3, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects3, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects3, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects3, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects3, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects3, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects3, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects3, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects3, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects3, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects3, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects3, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects3, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects3, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects3, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects3, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects3, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects3, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects3, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects3, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects3, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects3, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects3, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects3, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects3, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects3, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects3, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects3, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects3, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects3, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects3, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects = Hashtable.newFrom({"Enemy9": gdjs.AutoLevelCode.GDEnemy9Objects3, "Enemy1": gdjs.AutoLevelCode.GDEnemy1Objects3, "Enemy2": gdjs.AutoLevelCode.GDEnemy2Objects3, "Enemy3": gdjs.AutoLevelCode.GDEnemy3Objects3, "Enemy4": gdjs.AutoLevelCode.GDEnemy4Objects3, "Enemy5": gdjs.AutoLevelCode.GDEnemy5Objects3, "Enemy6": gdjs.AutoLevelCode.GDEnemy6Objects3, "Enemy7": gdjs.AutoLevelCode.GDEnemy7Objects3, "Enemy8": gdjs.AutoLevelCode.GDEnemy8Objects3, "Enemy10": gdjs.AutoLevelCode.GDEnemy10Objects3, "Enemy11": gdjs.AutoLevelCode.GDEnemy11Objects3, "Enemy12": gdjs.AutoLevelCode.GDEnemy12Objects3, "Enemy13": gdjs.AutoLevelCode.GDEnemy13Objects3, "Enemy14": gdjs.AutoLevelCode.GDEnemy14Objects3, "Enemy15": gdjs.AutoLevelCode.GDEnemy15Objects3, "Enemy16": gdjs.AutoLevelCode.GDEnemy16Objects3, "Enemy17": gdjs.AutoLevelCode.GDEnemy17Objects3, "Enemy18": gdjs.AutoLevelCode.GDEnemy18Objects3, "Enemy19": gdjs.AutoLevelCode.GDEnemy19Objects3, "Enemy20": gdjs.AutoLevelCode.GDEnemy20Objects3, "Enemy21": gdjs.AutoLevelCode.GDEnemy21Objects3, "Enemy22": gdjs.AutoLevelCode.GDEnemy22Objects3, "Enemy23": gdjs.AutoLevelCode.GDEnemy23Objects3, "Enemy24": gdjs.AutoLevelCode.GDEnemy24Objects3, "Enemy25": gdjs.AutoLevelCode.GDEnemy25Objects3, "Enemy26": gdjs.AutoLevelCode.GDEnemy26Objects3, "Enemy27": gdjs.AutoLevelCode.GDEnemy27Objects3, "Enemy28": gdjs.AutoLevelCode.GDEnemy28Objects3, "Enemy29": gdjs.AutoLevelCode.GDEnemy29Objects3, "Enemy30": gdjs.AutoLevelCode.GDEnemy30Objects3});
gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.AutoLevelCode.GDGenericCharacter2Objects3});
gdjs.AutoLevelCode.asyncCallback11524044 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects4);

{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects4[i].activateBehavior("Pathfinding", true);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects4.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects4[i].activateBehavior("Pathfinding", true);
}
}}
gdjs.AutoLevelCode.eventsList73 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.AutoLevelCode.GDEnemy1Objects3) asyncObjectsList.addObject("Enemy1", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy10Objects3) asyncObjectsList.addObject("Enemy10", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy11Objects3) asyncObjectsList.addObject("Enemy11", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy12Objects3) asyncObjectsList.addObject("Enemy12", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy13Objects3) asyncObjectsList.addObject("Enemy13", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy14Objects3) asyncObjectsList.addObject("Enemy14", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy15Objects3) asyncObjectsList.addObject("Enemy15", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy16Objects3) asyncObjectsList.addObject("Enemy16", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy17Objects3) asyncObjectsList.addObject("Enemy17", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy18Objects3) asyncObjectsList.addObject("Enemy18", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy19Objects3) asyncObjectsList.addObject("Enemy19", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy2Objects3) asyncObjectsList.addObject("Enemy2", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy20Objects3) asyncObjectsList.addObject("Enemy20", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy21Objects3) asyncObjectsList.addObject("Enemy21", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy22Objects3) asyncObjectsList.addObject("Enemy22", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy23Objects3) asyncObjectsList.addObject("Enemy23", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy24Objects3) asyncObjectsList.addObject("Enemy24", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy25Objects3) asyncObjectsList.addObject("Enemy25", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy26Objects3) asyncObjectsList.addObject("Enemy26", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy27Objects3) asyncObjectsList.addObject("Enemy27", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy28Objects3) asyncObjectsList.addObject("Enemy28", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy29Objects3) asyncObjectsList.addObject("Enemy29", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy3Objects3) asyncObjectsList.addObject("Enemy3", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy30Objects3) asyncObjectsList.addObject("Enemy30", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy4Objects3) asyncObjectsList.addObject("Enemy4", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy5Objects3) asyncObjectsList.addObject("Enemy5", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy6Objects3) asyncObjectsList.addObject("Enemy6", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy7Objects3) asyncObjectsList.addObject("Enemy7", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy8Objects3) asyncObjectsList.addObject("Enemy8", obj);
for (const obj of gdjs.AutoLevelCode.GDEnemy9Objects3) asyncObjectsList.addObject("Enemy9", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.AutoLevelCode.asyncCallback11524044(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.AutoLevelCode.eventsList74 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects3);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects, 16 * 3, false);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition1IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11488748);
}
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects3 */
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy9Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy1Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy2Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy3Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy4Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy5Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy6Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy7Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy8Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy10Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy11Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy12Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy13Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy14Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy15Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy16Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy17Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy18Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy19Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy20Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy21Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy22Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy23Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy24Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy25Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy26Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy27Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy28Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy29Objects3[i].getVariables().get("Velocidad"))) * 16);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].getBehavior("Pathfinding").setMaxSpeed((gdjs.RuntimeObject.getVariableNumber(gdjs.AutoLevelCode.GDEnemy30Objects3[i].getVariables().get("Velocidad"))) * 16);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].setAnimation(1);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects3);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects, 16 * 3, true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects3 */
{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].getBehavior("Pathfinding").setMaxSpeed(0);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].setAnimation(0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].setAnimation(0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects3);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects3);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects3);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
gdjs.AutoLevelCode.condition1IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDEnemy9Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy1Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy2Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy3Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy4Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy5Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy6Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy7Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy8Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy10Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy11Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy12Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy13Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy14Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy15Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy16Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy17Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy18Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy19Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy20Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy21Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy22Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy23Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy24Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy25Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy26Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy27Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy28Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy29Objects3ObjectsGDgdjs_46AutoLevelCode_46GDEnemy30Objects3Objects, gdjs.AutoLevelCode.mapOfGDgdjs_46AutoLevelCode_46GDGenericCharacter2Objects3Objects, 5, false);
}if ( gdjs.AutoLevelCode.condition0IsTrue_0.val ) {
{
{gdjs.AutoLevelCode.conditionTrue_1 = gdjs.AutoLevelCode.condition1IsTrue_0;
gdjs.AutoLevelCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11460044);
}
}}
if (gdjs.AutoLevelCode.condition1IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects3 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects3 */
/* Reuse gdjs.AutoLevelCode.GDGenericCharacter2Objects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/EnemyDamage.wav", false, 80, 1);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].activateBehavior("Pathfinding", false);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].activateBehavior("Pathfinding", false);
}
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy9Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy1Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy2Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy3Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy4Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy5Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy6Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy7Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy8Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy10Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy11Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy12Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy13Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy14Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy15Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy16Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy17Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy18Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy19Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy20Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy21Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy22Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy23Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy24Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy25Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy26Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy27Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy28Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy29Objects3[i])), 850, 0);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects3.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects3[i].addPolarForce((( gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects3[0].getAngleToObject(gdjs.AutoLevelCode.GDEnemy30Objects3[i])), 850, 0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList73(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects2);

gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy9Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy9Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy9Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy9Objects2[k] = gdjs.AutoLevelCode.GDEnemy9Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy9Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy1Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy1Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy1Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy1Objects2[k] = gdjs.AutoLevelCode.GDEnemy1Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy1Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy2Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy2Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy2Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy2Objects2[k] = gdjs.AutoLevelCode.GDEnemy2Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy2Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy3Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy3Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy3Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy3Objects2[k] = gdjs.AutoLevelCode.GDEnemy3Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy3Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy4Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy4Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy4Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy4Objects2[k] = gdjs.AutoLevelCode.GDEnemy4Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy4Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy5Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy5Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy5Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy5Objects2[k] = gdjs.AutoLevelCode.GDEnemy5Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy5Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy6Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy6Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy6Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy6Objects2[k] = gdjs.AutoLevelCode.GDEnemy6Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy6Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy7Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy7Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy7Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy7Objects2[k] = gdjs.AutoLevelCode.GDEnemy7Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy7Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy8Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy8Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy8Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy8Objects2[k] = gdjs.AutoLevelCode.GDEnemy8Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy8Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy10Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy10Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy10Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy10Objects2[k] = gdjs.AutoLevelCode.GDEnemy10Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy10Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy11Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy11Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy11Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy11Objects2[k] = gdjs.AutoLevelCode.GDEnemy11Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy11Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy12Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy12Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy12Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy12Objects2[k] = gdjs.AutoLevelCode.GDEnemy12Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy12Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy13Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy13Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy13Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy13Objects2[k] = gdjs.AutoLevelCode.GDEnemy13Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy13Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy14Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy14Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy14Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy14Objects2[k] = gdjs.AutoLevelCode.GDEnemy14Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy14Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy15Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy15Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy15Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy15Objects2[k] = gdjs.AutoLevelCode.GDEnemy15Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy15Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy16Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy16Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy16Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy16Objects2[k] = gdjs.AutoLevelCode.GDEnemy16Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy16Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy17Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy17Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy17Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy17Objects2[k] = gdjs.AutoLevelCode.GDEnemy17Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy17Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy18Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy18Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy18Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy18Objects2[k] = gdjs.AutoLevelCode.GDEnemy18Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy18Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy19Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy19Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy19Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy19Objects2[k] = gdjs.AutoLevelCode.GDEnemy19Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy19Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy20Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy20Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy20Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy20Objects2[k] = gdjs.AutoLevelCode.GDEnemy20Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy20Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy21Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy21Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy21Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy21Objects2[k] = gdjs.AutoLevelCode.GDEnemy21Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy21Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy22Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy22Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy22Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy22Objects2[k] = gdjs.AutoLevelCode.GDEnemy22Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy22Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy23Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy23Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy23Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy23Objects2[k] = gdjs.AutoLevelCode.GDEnemy23Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy23Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy24Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy24Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy24Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy24Objects2[k] = gdjs.AutoLevelCode.GDEnemy24Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy24Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy25Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy25Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy25Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy25Objects2[k] = gdjs.AutoLevelCode.GDEnemy25Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy25Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy26Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy26Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy26Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy26Objects2[k] = gdjs.AutoLevelCode.GDEnemy26Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy26Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy27Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy27Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy27Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy27Objects2[k] = gdjs.AutoLevelCode.GDEnemy27Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy27Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy28Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy28Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy28Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy28Objects2[k] = gdjs.AutoLevelCode.GDEnemy28Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy28Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy29Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy29Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy29Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy29Objects2[k] = gdjs.AutoLevelCode.GDEnemy29Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy29Objects2.length = k;for(var i = 0, k = 0, l = gdjs.AutoLevelCode.GDEnemy30Objects2.length;i<l;++i) {
    if ( gdjs.AutoLevelCode.GDEnemy30Objects2[i].getVariableNumber(gdjs.AutoLevelCode.GDEnemy30Objects2[i].getVariables().get("Salud")) <= 0 ) {
        gdjs.AutoLevelCode.condition0IsTrue_0.val = true;
        gdjs.AutoLevelCode.GDEnemy30Objects2[k] = gdjs.AutoLevelCode.GDEnemy30Objects2[i];
        ++k;
    }
}
gdjs.AutoLevelCode.GDEnemy30Objects2.length = k;}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
/* Reuse gdjs.AutoLevelCode.GDEnemy1Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy10Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy11Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy12Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy13Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy14Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy15Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy16Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy17Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy18Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy19Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy2Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy20Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy21Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy22Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy23Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy24Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy25Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy26Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy27Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy28Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy29Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy3Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy30Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy4Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy5Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy6Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy7Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy8Objects2 */
/* Reuse gdjs.AutoLevelCode.GDEnemy9Objects2 */
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.AutoLevelCode.GDScoreTextObjects2);
{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getGame().getVariables().getFromIndex(7).add((gdjs.RuntimeObject.getVariableNumber(((gdjs.AutoLevelCode.GDEnemy30Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy29Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy28Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy27Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy26Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy25Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy24Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy23Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy22Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy21Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy20Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy19Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy18Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy17Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy16Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy15Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy14Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy13Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy12Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy11Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy10Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy8Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy7Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy6Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy5Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy4Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy3Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy2Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy1Objects2.length === 0 ) ? ((gdjs.AutoLevelCode.GDEnemy9Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.AutoLevelCode.GDEnemy9Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy1Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy2Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy3Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy4Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy5Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy6Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy7Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy8Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy10Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy11Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy12Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy13Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy14Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy15Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy16Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy17Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy18Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy19Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy20Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy21Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy22Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy23Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy24Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy25Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy26Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy27Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy28Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy29Objects2[0].getVariables()) : gdjs.AutoLevelCode.GDEnemy30Objects2[0].getVariables()).get("Valor"))));
}{for(var i = 0, len = gdjs.AutoLevelCode.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDScoreTextObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) + " pt");
}
}}

}


};gdjs.AutoLevelCode.eventsList75 = function(runtimeScene) {

{


gdjs.AutoLevelCode.eventsList47(runtimeScene);
}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Enemy1"), gdjs.AutoLevelCode.GDEnemy1Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy10"), gdjs.AutoLevelCode.GDEnemy10Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy11"), gdjs.AutoLevelCode.GDEnemy11Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy12"), gdjs.AutoLevelCode.GDEnemy12Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy13"), gdjs.AutoLevelCode.GDEnemy13Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy14"), gdjs.AutoLevelCode.GDEnemy14Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy15"), gdjs.AutoLevelCode.GDEnemy15Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy16"), gdjs.AutoLevelCode.GDEnemy16Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy17"), gdjs.AutoLevelCode.GDEnemy17Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy18"), gdjs.AutoLevelCode.GDEnemy18Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy19"), gdjs.AutoLevelCode.GDEnemy19Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy2"), gdjs.AutoLevelCode.GDEnemy2Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy20"), gdjs.AutoLevelCode.GDEnemy20Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy21"), gdjs.AutoLevelCode.GDEnemy21Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy22"), gdjs.AutoLevelCode.GDEnemy22Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy23"), gdjs.AutoLevelCode.GDEnemy23Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy24"), gdjs.AutoLevelCode.GDEnemy24Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy25"), gdjs.AutoLevelCode.GDEnemy25Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy26"), gdjs.AutoLevelCode.GDEnemy26Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy27"), gdjs.AutoLevelCode.GDEnemy27Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy28"), gdjs.AutoLevelCode.GDEnemy28Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy29"), gdjs.AutoLevelCode.GDEnemy29Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy3"), gdjs.AutoLevelCode.GDEnemy3Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy30"), gdjs.AutoLevelCode.GDEnemy30Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy4"), gdjs.AutoLevelCode.GDEnemy4Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy5"), gdjs.AutoLevelCode.GDEnemy5Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy6"), gdjs.AutoLevelCode.GDEnemy6Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy7"), gdjs.AutoLevelCode.GDEnemy7Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy8"), gdjs.AutoLevelCode.GDEnemy8Objects2);
gdjs.copyArray(runtimeScene.getObjects("Enemy9"), gdjs.AutoLevelCode.GDEnemy9Objects2);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.AutoLevelCode.GDGenericCharacter2Objects2);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length !== 0 ? gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0] : null), true, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length !== 0 ? gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0] : null), true, "Player", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length !== 0 ? gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0] : null), true, "Objects", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length !== 0 ? gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0] : null), true, "Enemies", 0);
}{for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy9Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy9Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy1Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy1Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy2Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy2Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy3Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy3Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy4Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy4Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy5Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy5Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy6Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy6Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy7Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy7Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy8Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy8Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy10Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy10Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy11Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy11Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy12Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy12Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy13Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy13Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy14Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy14Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy15Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy15Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy16Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy16Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy17Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy17Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy18Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy18Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy19Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy19Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy20Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy20Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy21Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy21Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy22Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy22Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy23Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy23Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy24Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy24Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy25Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy25Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy26Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy26Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy27Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy27Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy28Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy28Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy29Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy29Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
for(var i = 0, len = gdjs.AutoLevelCode.GDEnemy30Objects2.length ;i < len;++i) {
    gdjs.AutoLevelCode.GDEnemy30Objects2[i].getBehavior("Pathfinding").moveTo(runtimeScene, (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointX("")), (( gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length === 0 ) ? 0 :gdjs.AutoLevelCode.GDGenericCharacter2Objects2[0].getPointY("")));
}
}}

}


{


gdjs.AutoLevelCode.eventsList55(runtimeScene);
}


{


gdjs.AutoLevelCode.eventsList65(runtimeScene);
}


{


gdjs.AutoLevelCode.eventsList71(runtimeScene);
}


{


gdjs.AutoLevelCode.eventsList72(runtimeScene);
}


{


gdjs.AutoLevelCode.eventsList74(runtimeScene);
}


{



}


{



}


};gdjs.AutoLevelCode.eventsList76 = function(runtimeScene) {

{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.adMob.setTestMode(false);
}{gdjs.adMob.loadInterstitial("ca-app-pub-4671042942864334/6831724704", "", false);
}{gdjs.adMob.setupBanner("ca-app-pub-4671042942864334/5141703664", "", true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/The_Old_Tower_Inn.mp3", true, 90, 1);
}{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(6), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(2), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(3), true);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(0), false);
}
{ //Subevents
gdjs.AutoLevelCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = !(gdjs.adMob.isBannerLoading());
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {
{gdjs.adMob.showBanner();
}}

}


{


gdjs.AutoLevelCode.eventsList4(runtimeScene);
}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(6), true);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList43(runtimeScene);} //End of subevents
}

}


{


gdjs.AutoLevelCode.condition0IsTrue_0.val = false;
{
gdjs.AutoLevelCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(6), false);
}if (gdjs.AutoLevelCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.AutoLevelCode.eventsList75(runtimeScene);} //End of subevents
}

}


};

gdjs.AutoLevelCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.AutoLevelCode.GDFloorObjects1.length = 0;
gdjs.AutoLevelCode.GDFloorObjects2.length = 0;
gdjs.AutoLevelCode.GDFloorObjects3.length = 0;
gdjs.AutoLevelCode.GDFloorObjects4.length = 0;
gdjs.AutoLevelCode.GDFloorObjects5.length = 0;
gdjs.AutoLevelCode.GDFloorObjects6.length = 0;
gdjs.AutoLevelCode.GDFloorObjects7.length = 0;
gdjs.AutoLevelCode.GDFloorObjects8.length = 0;
gdjs.AutoLevelCode.GDFloorObjects9.length = 0;
gdjs.AutoLevelCode.GDFloorObjects10.length = 0;
gdjs.AutoLevelCode.GDFloorObjects11.length = 0;
gdjs.AutoLevelCode.GDFloorObjects12.length = 0;
gdjs.AutoLevelCode.GDFloorObjects13.length = 0;
gdjs.AutoLevelCode.GDDoorObjects1.length = 0;
gdjs.AutoLevelCode.GDDoorObjects2.length = 0;
gdjs.AutoLevelCode.GDDoorObjects3.length = 0;
gdjs.AutoLevelCode.GDDoorObjects4.length = 0;
gdjs.AutoLevelCode.GDDoorObjects5.length = 0;
gdjs.AutoLevelCode.GDDoorObjects6.length = 0;
gdjs.AutoLevelCode.GDDoorObjects7.length = 0;
gdjs.AutoLevelCode.GDDoorObjects8.length = 0;
gdjs.AutoLevelCode.GDDoorObjects9.length = 0;
gdjs.AutoLevelCode.GDDoorObjects10.length = 0;
gdjs.AutoLevelCode.GDDoorObjects11.length = 0;
gdjs.AutoLevelCode.GDDoorObjects12.length = 0;
gdjs.AutoLevelCode.GDDoorObjects13.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects1.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects2.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects3.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects4.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects5.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects6.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects7.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects8.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects9.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects10.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects11.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects12.length = 0;
gdjs.AutoLevelCode.GDUiHeart1Objects13.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects1.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects2.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects3.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects4.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects5.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects6.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects7.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects8.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects9.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects10.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects11.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects12.length = 0;
gdjs.AutoLevelCode.GDUiHeart2Objects13.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects1.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects2.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects3.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects4.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects5.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects6.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects7.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects8.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects9.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects10.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects11.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects12.length = 0;
gdjs.AutoLevelCode.GDUiHeart3Objects13.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects1.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects2.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects3.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects4.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects5.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects6.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects7.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects8.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects9.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects10.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects11.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects12.length = 0;
gdjs.AutoLevelCode.GDGenericCharacter2Objects13.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects1.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects2.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects3.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects4.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects5.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects6.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects7.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects8.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects9.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects10.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects11.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects12.length = 0;
gdjs.AutoLevelCode.GDLoadingTextObjects13.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects1.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects2.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects3.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects4.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects5.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects6.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects7.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects8.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects9.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects10.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects11.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects12.length = 0;
gdjs.AutoLevelCode.GDScoreTextObjects13.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects1.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects2.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects3.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects4.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects5.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects6.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects7.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects8.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects9.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects10.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects11.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects12.length = 0;
gdjs.AutoLevelCode.GDDPadBottomObjects13.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects1.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects2.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects3.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects4.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects5.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects6.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects7.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects8.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects9.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects10.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects11.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects12.length = 0;
gdjs.AutoLevelCode.GDDPadLeftObjects13.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects1.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects2.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects3.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects4.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects5.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects6.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects7.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects8.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects9.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects10.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects11.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects12.length = 0;
gdjs.AutoLevelCode.GDDPadRightObjects13.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects1.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects2.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects3.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects4.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects5.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects6.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects7.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects8.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects9.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects10.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects11.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects12.length = 0;
gdjs.AutoLevelCode.GDDPadUpObjects13.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects1.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects2.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects3.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects4.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects5.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects6.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects7.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects8.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects9.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects10.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects11.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects12.length = 0;
gdjs.AutoLevelCode.GDFireRoundButtonObjects13.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects1.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects2.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects3.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects4.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects5.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects6.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects7.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects8.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects9.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects10.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects11.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects12.length = 0;
gdjs.AutoLevelCode.GDPauseButtonObjects13.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects1.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects2.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects3.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects4.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects5.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects6.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects7.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects8.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects9.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects10.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects11.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects12.length = 0;
gdjs.AutoLevelCode.GDBlankButtonObjects13.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects1.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects2.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects3.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects4.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects5.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects6.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects7.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects8.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects9.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects10.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects11.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects12.length = 0;
gdjs.AutoLevelCode.GDTextoArmaObjects13.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects1.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects2.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects3.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects4.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects5.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects6.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects7.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects8.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects9.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects10.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects11.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects12.length = 0;
gdjs.AutoLevelCode.GDReiniciarJuegoObjects13.length = 0;
gdjs.AutoLevelCode.GDCoinObjects1.length = 0;
gdjs.AutoLevelCode.GDCoinObjects2.length = 0;
gdjs.AutoLevelCode.GDCoinObjects3.length = 0;
gdjs.AutoLevelCode.GDCoinObjects4.length = 0;
gdjs.AutoLevelCode.GDCoinObjects5.length = 0;
gdjs.AutoLevelCode.GDCoinObjects6.length = 0;
gdjs.AutoLevelCode.GDCoinObjects7.length = 0;
gdjs.AutoLevelCode.GDCoinObjects8.length = 0;
gdjs.AutoLevelCode.GDCoinObjects9.length = 0;
gdjs.AutoLevelCode.GDCoinObjects10.length = 0;
gdjs.AutoLevelCode.GDCoinObjects11.length = 0;
gdjs.AutoLevelCode.GDCoinObjects12.length = 0;
gdjs.AutoLevelCode.GDCoinObjects13.length = 0;
gdjs.AutoLevelCode.GDChestObjects1.length = 0;
gdjs.AutoLevelCode.GDChestObjects2.length = 0;
gdjs.AutoLevelCode.GDChestObjects3.length = 0;
gdjs.AutoLevelCode.GDChestObjects4.length = 0;
gdjs.AutoLevelCode.GDChestObjects5.length = 0;
gdjs.AutoLevelCode.GDChestObjects6.length = 0;
gdjs.AutoLevelCode.GDChestObjects7.length = 0;
gdjs.AutoLevelCode.GDChestObjects8.length = 0;
gdjs.AutoLevelCode.GDChestObjects9.length = 0;
gdjs.AutoLevelCode.GDChestObjects10.length = 0;
gdjs.AutoLevelCode.GDChestObjects11.length = 0;
gdjs.AutoLevelCode.GDChestObjects12.length = 0;
gdjs.AutoLevelCode.GDChestObjects13.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects1.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects2.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects3.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects4.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects5.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects6.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects7.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects8.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects9.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects10.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects11.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects12.length = 0;
gdjs.AutoLevelCode.GDKnifeObjects13.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects1.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects2.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects3.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects4.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects5.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects6.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects7.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects8.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects9.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects10.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects11.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects12.length = 0;
gdjs.AutoLevelCode.GDRustySwordObjects13.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects1.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects2.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects3.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects4.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects5.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects6.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects7.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects8.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects9.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects10.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects11.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects12.length = 0;
gdjs.AutoLevelCode.GDRegularSwordObjects13.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects1.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects2.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects3.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects4.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects5.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects6.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects7.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects8.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects9.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects10.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects11.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects12.length = 0;
gdjs.AutoLevelCode.GDAnimeSwordObjects13.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy1Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy2Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy3Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy4Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy5Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy6Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy7Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy8Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy9Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy10Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy11Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy12Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy13Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy14Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy15Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy16Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy17Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy18Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy19Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy20Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy21Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy22Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy23Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy24Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy25Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy26Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy27Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy28Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy29Objects13.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects1.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects2.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects3.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects4.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects5.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects6.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects7.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects8.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects9.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects10.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects11.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects12.length = 0;
gdjs.AutoLevelCode.GDEnemy30Objects13.length = 0;
gdjs.AutoLevelCode.GDTitleObjects1.length = 0;
gdjs.AutoLevelCode.GDTitleObjects2.length = 0;
gdjs.AutoLevelCode.GDTitleObjects3.length = 0;
gdjs.AutoLevelCode.GDTitleObjects4.length = 0;
gdjs.AutoLevelCode.GDTitleObjects5.length = 0;
gdjs.AutoLevelCode.GDTitleObjects6.length = 0;
gdjs.AutoLevelCode.GDTitleObjects7.length = 0;
gdjs.AutoLevelCode.GDTitleObjects8.length = 0;
gdjs.AutoLevelCode.GDTitleObjects9.length = 0;
gdjs.AutoLevelCode.GDTitleObjects10.length = 0;
gdjs.AutoLevelCode.GDTitleObjects11.length = 0;
gdjs.AutoLevelCode.GDTitleObjects12.length = 0;
gdjs.AutoLevelCode.GDTitleObjects13.length = 0;
gdjs.AutoLevelCode.GDTileObjects1.length = 0;
gdjs.AutoLevelCode.GDTileObjects2.length = 0;
gdjs.AutoLevelCode.GDTileObjects3.length = 0;
gdjs.AutoLevelCode.GDTileObjects4.length = 0;
gdjs.AutoLevelCode.GDTileObjects5.length = 0;
gdjs.AutoLevelCode.GDTileObjects6.length = 0;
gdjs.AutoLevelCode.GDTileObjects7.length = 0;
gdjs.AutoLevelCode.GDTileObjects8.length = 0;
gdjs.AutoLevelCode.GDTileObjects9.length = 0;
gdjs.AutoLevelCode.GDTileObjects10.length = 0;
gdjs.AutoLevelCode.GDTileObjects11.length = 0;
gdjs.AutoLevelCode.GDTileObjects12.length = 0;
gdjs.AutoLevelCode.GDTileObjects13.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects1.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects2.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects3.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects4.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects5.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects6.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects7.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects8.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects9.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects10.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects11.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects12.length = 0;
gdjs.AutoLevelCode.GDBlackTileObjects13.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects1.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects2.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects3.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects4.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects5.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects6.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects7.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects8.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects9.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects10.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects11.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects12.length = 0;
gdjs.AutoLevelCode.GDNodeMarkerObjects13.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects1.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects2.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects3.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects4.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects5.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects6.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects7.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects8.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects9.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects10.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects11.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects12.length = 0;
gdjs.AutoLevelCode.GDFondoNegroObjects13.length = 0;
gdjs.AutoLevelCode.GDPausaObjects1.length = 0;
gdjs.AutoLevelCode.GDPausaObjects2.length = 0;
gdjs.AutoLevelCode.GDPausaObjects3.length = 0;
gdjs.AutoLevelCode.GDPausaObjects4.length = 0;
gdjs.AutoLevelCode.GDPausaObjects5.length = 0;
gdjs.AutoLevelCode.GDPausaObjects6.length = 0;
gdjs.AutoLevelCode.GDPausaObjects7.length = 0;
gdjs.AutoLevelCode.GDPausaObjects8.length = 0;
gdjs.AutoLevelCode.GDPausaObjects9.length = 0;
gdjs.AutoLevelCode.GDPausaObjects10.length = 0;
gdjs.AutoLevelCode.GDPausaObjects11.length = 0;
gdjs.AutoLevelCode.GDPausaObjects12.length = 0;
gdjs.AutoLevelCode.GDPausaObjects13.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects1.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects2.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects3.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects4.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects5.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects6.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects7.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects8.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects9.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects10.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects11.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects12.length = 0;
gdjs.AutoLevelCode.GDBotonVerdeObjects13.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects1.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects2.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects3.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects4.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects5.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects6.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects7.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects8.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects9.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects10.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects11.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects12.length = 0;
gdjs.AutoLevelCode.GDBotonVerde2Objects13.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects1.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects2.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects3.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects4.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects5.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects6.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects7.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects8.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects9.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects10.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects11.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects12.length = 0;
gdjs.AutoLevelCode.GDContinuarBtnObjects13.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects1.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects2.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects3.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects4.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects5.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects6.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects7.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects8.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects9.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects10.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects11.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects12.length = 0;
gdjs.AutoLevelCode.GDSalirBtnObjects13.length = 0;
gdjs.AutoLevelCode.GDDebugObjects1.length = 0;
gdjs.AutoLevelCode.GDDebugObjects2.length = 0;
gdjs.AutoLevelCode.GDDebugObjects3.length = 0;
gdjs.AutoLevelCode.GDDebugObjects4.length = 0;
gdjs.AutoLevelCode.GDDebugObjects5.length = 0;
gdjs.AutoLevelCode.GDDebugObjects6.length = 0;
gdjs.AutoLevelCode.GDDebugObjects7.length = 0;
gdjs.AutoLevelCode.GDDebugObjects8.length = 0;
gdjs.AutoLevelCode.GDDebugObjects9.length = 0;
gdjs.AutoLevelCode.GDDebugObjects10.length = 0;
gdjs.AutoLevelCode.GDDebugObjects11.length = 0;
gdjs.AutoLevelCode.GDDebugObjects12.length = 0;
gdjs.AutoLevelCode.GDDebugObjects13.length = 0;

gdjs.AutoLevelCode.eventsList76(runtimeScene);
return;

}

gdjs['AutoLevelCode'] = gdjs.AutoLevelCode;
