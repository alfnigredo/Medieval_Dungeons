gdjs.GameOverCode = {};
gdjs.GameOverCode.GDFloorObjects1= [];
gdjs.GameOverCode.GDFloorObjects2= [];
gdjs.GameOverCode.GDDoorObjects1= [];
gdjs.GameOverCode.GDDoorObjects2= [];
gdjs.GameOverCode.GDUiHeart1Objects1= [];
gdjs.GameOverCode.GDUiHeart1Objects2= [];
gdjs.GameOverCode.GDUiHeart2Objects1= [];
gdjs.GameOverCode.GDUiHeart2Objects2= [];
gdjs.GameOverCode.GDUiHeart3Objects1= [];
gdjs.GameOverCode.GDUiHeart3Objects2= [];
gdjs.GameOverCode.GDGenericCharacter2Objects1= [];
gdjs.GameOverCode.GDGenericCharacter2Objects2= [];
gdjs.GameOverCode.GDLoadingTextObjects1= [];
gdjs.GameOverCode.GDLoadingTextObjects2= [];
gdjs.GameOverCode.GDScoreTextObjects1= [];
gdjs.GameOverCode.GDScoreTextObjects2= [];
gdjs.GameOverCode.GDDPadBottomObjects1= [];
gdjs.GameOverCode.GDDPadBottomObjects2= [];
gdjs.GameOverCode.GDDPadLeftObjects1= [];
gdjs.GameOverCode.GDDPadLeftObjects2= [];
gdjs.GameOverCode.GDDPadRightObjects1= [];
gdjs.GameOverCode.GDDPadRightObjects2= [];
gdjs.GameOverCode.GDDPadUpObjects1= [];
gdjs.GameOverCode.GDDPadUpObjects2= [];
gdjs.GameOverCode.GDFireRoundButtonObjects1= [];
gdjs.GameOverCode.GDFireRoundButtonObjects2= [];
gdjs.GameOverCode.GDPauseButtonObjects1= [];
gdjs.GameOverCode.GDPauseButtonObjects2= [];
gdjs.GameOverCode.GDBlankButtonObjects1= [];
gdjs.GameOverCode.GDBlankButtonObjects2= [];
gdjs.GameOverCode.GDTextoArmaObjects1= [];
gdjs.GameOverCode.GDTextoArmaObjects2= [];
gdjs.GameOverCode.GDReiniciarJuegoObjects1= [];
gdjs.GameOverCode.GDReiniciarJuegoObjects2= [];
gdjs.GameOverCode.GDCoinObjects1= [];
gdjs.GameOverCode.GDCoinObjects2= [];
gdjs.GameOverCode.GDWallFountainMidBlueObjects1= [];
gdjs.GameOverCode.GDWallFountainMidBlueObjects2= [];
gdjs.GameOverCode.GDTitleObjects1= [];
gdjs.GameOverCode.GDTitleObjects2= [];
gdjs.GameOverCode.GDWallFountainTopObjects1= [];
gdjs.GameOverCode.GDWallFountainTopObjects2= [];
gdjs.GameOverCode.GDWallFountainBasinBlueObjects1= [];
gdjs.GameOverCode.GDWallFountainBasinBlueObjects2= [];
gdjs.GameOverCode.GDNotificacionObjects1= [];
gdjs.GameOverCode.GDNotificacionObjects2= [];
gdjs.GameOverCode.GDChestObjects1= [];
gdjs.GameOverCode.GDChestObjects2= [];
gdjs.GameOverCode.GDVerTablaObjects1= [];
gdjs.GameOverCode.GDVerTablaObjects2= [];
gdjs.GameOverCode.GDEnviarPuntuacionObjects1= [];
gdjs.GameOverCode.GDEnviarPuntuacionObjects2= [];
gdjs.GameOverCode.GDUserNameObjects1= [];
gdjs.GameOverCode.GDUserNameObjects2= [];
gdjs.GameOverCode.GDTombStone2Objects1= [];
gdjs.GameOverCode.GDTombStone2Objects2= [];
gdjs.GameOverCode.GDSkull2Objects1= [];
gdjs.GameOverCode.GDSkull2Objects2= [];
gdjs.GameOverCode.GDStoneTabletObjects1= [];
gdjs.GameOverCode.GDStoneTabletObjects2= [];

gdjs.GameOverCode.conditionTrue_0 = {val:false};
gdjs.GameOverCode.condition0IsTrue_0 = {val:false};
gdjs.GameOverCode.condition1IsTrue_0 = {val:false};
gdjs.GameOverCode.condition2IsTrue_0 = {val:false};


gdjs.GameOverCode.mapOfGDgdjs_46GameOverCode_46GDVerTablaObjects1Objects = Hashtable.newFrom({"VerTabla": gdjs.GameOverCode.GDVerTablaObjects1});
gdjs.GameOverCode.mapOfGDgdjs_46GameOverCode_46GDEnviarPuntuacionObjects1Objects = Hashtable.newFrom({"EnviarPuntuacion": gdjs.GameOverCode.GDEnviarPuntuacionObjects1});
gdjs.GameOverCode.mapOfGDgdjs_46GameOverCode_46GDReiniciarJuegoObjects1Objects = Hashtable.newFrom({"ReiniciarJuego": gdjs.GameOverCode.GDReiniciarJuegoObjects1});
gdjs.GameOverCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.GameOverCode.GDGenericCharacter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.GameOverCode.GDScoreTextObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Feels - Patrick Patrikios.mp3", true, 90, 1);
}{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{for(var i = 0, len = gdjs.GameOverCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GameOverCode.GDGenericCharacter2Objects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.GameOverCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.GameOverCode.GDScoreTextObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) + " pts");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("VerTabla"), gdjs.GameOverCode.GDVerTablaObjects1);

gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameOverCode.mapOfGDgdjs_46GameOverCode_46GDVerTablaObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "8888be3b-5084-4c58-b0d5-5175930db135", true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnviarPuntuacion"), gdjs.GameOverCode.GDEnviarPuntuacionObjects1);
gdjs.copyArray(runtimeScene.getObjects("UserName"), gdjs.GameOverCode.GDUserNameObjects1);

gdjs.GameOverCode.condition0IsTrue_0.val = false;
gdjs.GameOverCode.condition1IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameOverCode.mapOfGDgdjs_46GameOverCode_46GDEnviarPuntuacionObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameOverCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameOverCode.GDUserNameObjects1.length;i<l;++i) {
    if ( gdjs.GameOverCode.GDUserNameObjects1[i].getString() != "" ) {
        gdjs.GameOverCode.condition1IsTrue_0.val = true;
        gdjs.GameOverCode.GDUserNameObjects1[k] = gdjs.GameOverCode.GDUserNameObjects1[i];
        ++k;
    }
}
gdjs.GameOverCode.GDUserNameObjects1.length = k;}}
if (gdjs.GameOverCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameOverCode.GDUserNameObjects1 */
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "8888be3b-5084-4c58-b0d5-5175930db135", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)), (( gdjs.GameOverCode.GDUserNameObjects1.length === 0 ) ? "" :gdjs.GameOverCode.GDUserNameObjects1[0].getString()));
}}

}


{


gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.leaderboards.isSaving("8888be3b-5084-4c58-b0d5-5175930db135");
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnviarPuntuacion"), gdjs.GameOverCode.GDEnviarPuntuacionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Notificacion"), gdjs.GameOverCode.GDNotificacionObjects1);
gdjs.copyArray(runtimeScene.getObjects("UserName"), gdjs.GameOverCode.GDUserNameObjects1);
{for(var i = 0, len = gdjs.GameOverCode.GDUserNameObjects1.length ;i < len;++i) {
    gdjs.GameOverCode.GDUserNameObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameOverCode.GDEnviarPuntuacionObjects1.length ;i < len;++i) {
    gdjs.GameOverCode.GDEnviarPuntuacionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameOverCode.GDNotificacionObjects1.length ;i < len;++i) {
    gdjs.GameOverCode.GDNotificacionObjects1[i].setString("Enviando tu Puntuación");
}
}}

}


{


gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.leaderboards.hasBeenSaved("8888be3b-5084-4c58-b0d5-5175930db135");
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Notificacion"), gdjs.GameOverCode.GDNotificacionObjects1);
{for(var i = 0, len = gdjs.GameOverCode.GDNotificacionObjects1.length ;i < len;++i) {
    gdjs.GameOverCode.GDNotificacionObjects1[i].setString("Puntiación Guardada");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ReiniciarJuego"), gdjs.GameOverCode.GDReiniciarJuegoObjects1);

gdjs.GameOverCode.condition0IsTrue_0.val = false;
{
gdjs.GameOverCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameOverCode.mapOfGDgdjs_46GameOverCode_46GDReiniciarJuegoObjects1Objects, runtimeScene, true, false);
}if (gdjs.GameOverCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Home", true);
}}

}


};

gdjs.GameOverCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameOverCode.GDFloorObjects1.length = 0;
gdjs.GameOverCode.GDFloorObjects2.length = 0;
gdjs.GameOverCode.GDDoorObjects1.length = 0;
gdjs.GameOverCode.GDDoorObjects2.length = 0;
gdjs.GameOverCode.GDUiHeart1Objects1.length = 0;
gdjs.GameOverCode.GDUiHeart1Objects2.length = 0;
gdjs.GameOverCode.GDUiHeart2Objects1.length = 0;
gdjs.GameOverCode.GDUiHeart2Objects2.length = 0;
gdjs.GameOverCode.GDUiHeart3Objects1.length = 0;
gdjs.GameOverCode.GDUiHeart3Objects2.length = 0;
gdjs.GameOverCode.GDGenericCharacter2Objects1.length = 0;
gdjs.GameOverCode.GDGenericCharacter2Objects2.length = 0;
gdjs.GameOverCode.GDLoadingTextObjects1.length = 0;
gdjs.GameOverCode.GDLoadingTextObjects2.length = 0;
gdjs.GameOverCode.GDScoreTextObjects1.length = 0;
gdjs.GameOverCode.GDScoreTextObjects2.length = 0;
gdjs.GameOverCode.GDDPadBottomObjects1.length = 0;
gdjs.GameOverCode.GDDPadBottomObjects2.length = 0;
gdjs.GameOverCode.GDDPadLeftObjects1.length = 0;
gdjs.GameOverCode.GDDPadLeftObjects2.length = 0;
gdjs.GameOverCode.GDDPadRightObjects1.length = 0;
gdjs.GameOverCode.GDDPadRightObjects2.length = 0;
gdjs.GameOverCode.GDDPadUpObjects1.length = 0;
gdjs.GameOverCode.GDDPadUpObjects2.length = 0;
gdjs.GameOverCode.GDFireRoundButtonObjects1.length = 0;
gdjs.GameOverCode.GDFireRoundButtonObjects2.length = 0;
gdjs.GameOverCode.GDPauseButtonObjects1.length = 0;
gdjs.GameOverCode.GDPauseButtonObjects2.length = 0;
gdjs.GameOverCode.GDBlankButtonObjects1.length = 0;
gdjs.GameOverCode.GDBlankButtonObjects2.length = 0;
gdjs.GameOverCode.GDTextoArmaObjects1.length = 0;
gdjs.GameOverCode.GDTextoArmaObjects2.length = 0;
gdjs.GameOverCode.GDReiniciarJuegoObjects1.length = 0;
gdjs.GameOverCode.GDReiniciarJuegoObjects2.length = 0;
gdjs.GameOverCode.GDCoinObjects1.length = 0;
gdjs.GameOverCode.GDCoinObjects2.length = 0;
gdjs.GameOverCode.GDWallFountainMidBlueObjects1.length = 0;
gdjs.GameOverCode.GDWallFountainMidBlueObjects2.length = 0;
gdjs.GameOverCode.GDTitleObjects1.length = 0;
gdjs.GameOverCode.GDTitleObjects2.length = 0;
gdjs.GameOverCode.GDWallFountainTopObjects1.length = 0;
gdjs.GameOverCode.GDWallFountainTopObjects2.length = 0;
gdjs.GameOverCode.GDWallFountainBasinBlueObjects1.length = 0;
gdjs.GameOverCode.GDWallFountainBasinBlueObjects2.length = 0;
gdjs.GameOverCode.GDNotificacionObjects1.length = 0;
gdjs.GameOverCode.GDNotificacionObjects2.length = 0;
gdjs.GameOverCode.GDChestObjects1.length = 0;
gdjs.GameOverCode.GDChestObjects2.length = 0;
gdjs.GameOverCode.GDVerTablaObjects1.length = 0;
gdjs.GameOverCode.GDVerTablaObjects2.length = 0;
gdjs.GameOverCode.GDEnviarPuntuacionObjects1.length = 0;
gdjs.GameOverCode.GDEnviarPuntuacionObjects2.length = 0;
gdjs.GameOverCode.GDUserNameObjects1.length = 0;
gdjs.GameOverCode.GDUserNameObjects2.length = 0;
gdjs.GameOverCode.GDTombStone2Objects1.length = 0;
gdjs.GameOverCode.GDTombStone2Objects2.length = 0;
gdjs.GameOverCode.GDSkull2Objects1.length = 0;
gdjs.GameOverCode.GDSkull2Objects2.length = 0;
gdjs.GameOverCode.GDStoneTabletObjects1.length = 0;
gdjs.GameOverCode.GDStoneTabletObjects2.length = 0;

gdjs.GameOverCode.eventsList0(runtimeScene);
return;

}

gdjs['GameOverCode'] = gdjs.GameOverCode;
