
if (typeof gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje !== "undefined") {
  gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje = {};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2_1final = [];

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1_1final = [];

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2_1final = [];

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2_1final = [];

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects3= [];

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition2IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition2IsTrue_1 = {val:false};


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadBottomObjects3Objects = Hashtable.newFrom({"DPadBottom": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects2Objects = Hashtable.newFrom({"Pisables": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2 */
gdjs.copyArray(eventsFunctionContext.getObjects("Pisables"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2);

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects2Objects, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects2Objects, true, runtimeScene, true);
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2 */
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setCenterYInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getCenterYInScene() - (16));
}
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadUpObjects3Objects = Hashtable.newFrom({"DPadUp": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects2Objects = Hashtable.newFrom({"Pisables": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2 */
gdjs.copyArray(eventsFunctionContext.getObjects("Pisables"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2);

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects2Objects, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects2Objects, true, runtimeScene, true);
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2 */
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setCenterYInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getCenterYInScene() + (16));
}
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadRightObjects3Objects = Hashtable.newFrom({"DPadRight": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects2Objects = Hashtable.newFrom({"Pisables": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2 */
gdjs.copyArray(eventsFunctionContext.getObjects("Pisables"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2);

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects2Objects, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects2Objects, true, runtimeScene, true);
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2 */
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setCenterXInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getCenterXInScene() - (16));
}
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadLeftObjects2Objects = Hashtable.newFrom({"DPadLeft": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects1Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects1Objects = Hashtable.newFrom({"Pisables": gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects1});
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{

/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1 */
gdjs.copyArray(eventsFunctionContext.getObjects("Pisables"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects1);

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDGenericCharacter2Objects1Objects, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDPisablesObjects1Objects, true, runtimeScene, true);
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1 */
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].setCenterXInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].getCenterXInScene() + (16));
}
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2.length = 0;


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2_1final.length = 0;gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("DPadBottom"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3);
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadBottomObjects3Objects, runtimeScene, true, false);
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3.length;j<jLen;++j) {
        if ( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2_1final.indexOf(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3[j]) === -1 )
            gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2_1final.push(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3[j]);
    }
}
}
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2_1final, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2);
}
}
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2);

{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setVariableBoolean(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getVariables().get("EnMovimiento"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setCenterYInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getCenterYInScene() + (16));
}
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2.length = 0;


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2_1final.length = 0;gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("DPadUp"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3);
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadUpObjects3Objects, runtimeScene, true, false);
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3.length;j<jLen;++j) {
        if ( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2_1final.indexOf(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3[j]) === -1 )
            gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2_1final.push(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3[j]);
    }
}
}
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2_1final, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2);
}
}
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2);

{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setVariableBoolean(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getVariables().get("EnMovimiento"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setCenterYInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getCenterYInScene() - (16));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), false);
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2.length = 0;


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2_1final.length = 0;gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("DPadRight"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3);
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadRightObjects3Objects, runtimeScene, true, false);
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3.length;j<jLen;++j) {
        if ( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2_1final.indexOf(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3[j]) === -1 )
            gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2_1final.push(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3[j]);
    }
}
}
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2_1final, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2);
}
}
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2);

{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setVariableBoolean(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getVariables().get("EnMovimiento"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].setCenterXInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].getCenterXInScene() + (16));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), false);
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1.length = 0;


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1_1final.length = 0;gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("DPadLeft"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2);
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95MoverPersonaje_46GDDPadLeftObjects2Objects, runtimeScene, true, false);
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2.length;j<jLen;++j) {
        if ( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1_1final.indexOf(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2[j]) === -1 )
            gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1_1final.push(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2[j]);
    }
}
}
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition1IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1_1final, gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1);
}
}
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1 */
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].setVariableBoolean(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].getVariables().get("EnMovimiento"), true);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].setCenterXInScene(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].getCenterXInScene() - (16));
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), false);
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.asyncCallback11148500 = function (runtimeScene, eventsFunctionContext, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("GenericCharacter2"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2);

{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2[i].pauseAnimation();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), true);
}}
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1) asyncObjectsList.addObject("GenericCharacter2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("VelocidadPersonaje"))), (runtimeScene) => (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.asyncCallback11148500(runtimeScene, eventsFunctionContext, asyncObjectsList)));
}
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "GrupoTouch");
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), true);
}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
gdjs.copyArray(eventsFunctionContext.getObjects("GenericCharacter2"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].pauseAnimation();
}
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("GenericCharacter2"), gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1);

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length;i<l;++i) {
    if ( gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].getVariableBoolean(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].getVariables().get("EnMovimiento"), true) ) {
        gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val = true;
        gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[k] = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i];
        ++k;
    }
}
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length = k;}if (gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.condition0IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1 */
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].setVariableBoolean(gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1[i].getVariables().get("EnMovimiento"), false);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), false);
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList5(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.func = function(runtimeScene, Pisables, DPadBottom, DPadLeft, DPadRight, DPadUp, GenericCharacter2, GrupoTouch, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Pisables": Pisables
, "DPadBottom": DPadBottom
, "DPadLeft": DPadLeft
, "DPadRight": DPadRight
, "DPadUp": DPadUp
, "GenericCharacter2": GenericCharacter2
},
  _objectArraysMap: {
"Pisables": gdjs.objectsListsToArray(Pisables)
, "DPadBottom": gdjs.objectsListsToArray(DPadBottom)
, "DPadLeft": gdjs.objectsListsToArray(DPadLeft)
, "DPadRight": gdjs.objectsListsToArray(DPadRight)
, "DPadUp": gdjs.objectsListsToArray(DPadUp)
, "GenericCharacter2": gdjs.objectsListsToArray(GenericCharacter2)
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "GrupoTouch") return GrupoTouch;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDPisablesObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadBottomObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadLeftObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadRightObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDDPadUpObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.GDGenericCharacter2Objects3.length = 0;

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.eventsList6(runtimeScene, eventsFunctionContext);
return;
}

gdjs.evtsExt__MovimientoCuadradoX16__MoverPersonaje.registeredGdjsCallbacks = [];