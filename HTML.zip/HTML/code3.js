gdjs.HomeCode = {};
gdjs.HomeCode.GDDPadBottomObjects3_1final = [];

gdjs.HomeCode.GDDPadLeftObjects2_1final = [];

gdjs.HomeCode.GDDPadRightObjects3_1final = [];

gdjs.HomeCode.GDDPadUpObjects3_1final = [];

gdjs.HomeCode.GDFloorObjects1= [];
gdjs.HomeCode.GDFloorObjects2= [];
gdjs.HomeCode.GDFloorObjects3= [];
gdjs.HomeCode.GDFloorObjects4= [];
gdjs.HomeCode.GDDoorObjects1= [];
gdjs.HomeCode.GDDoorObjects2= [];
gdjs.HomeCode.GDDoorObjects3= [];
gdjs.HomeCode.GDDoorObjects4= [];
gdjs.HomeCode.GDUiHeart1Objects1= [];
gdjs.HomeCode.GDUiHeart1Objects2= [];
gdjs.HomeCode.GDUiHeart1Objects3= [];
gdjs.HomeCode.GDUiHeart1Objects4= [];
gdjs.HomeCode.GDUiHeart2Objects1= [];
gdjs.HomeCode.GDUiHeart2Objects2= [];
gdjs.HomeCode.GDUiHeart2Objects3= [];
gdjs.HomeCode.GDUiHeart2Objects4= [];
gdjs.HomeCode.GDUiHeart3Objects1= [];
gdjs.HomeCode.GDUiHeart3Objects2= [];
gdjs.HomeCode.GDUiHeart3Objects3= [];
gdjs.HomeCode.GDUiHeart3Objects4= [];
gdjs.HomeCode.GDGenericCharacter2Objects1= [];
gdjs.HomeCode.GDGenericCharacter2Objects2= [];
gdjs.HomeCode.GDGenericCharacter2Objects3= [];
gdjs.HomeCode.GDGenericCharacter2Objects4= [];
gdjs.HomeCode.GDLoadingTextObjects1= [];
gdjs.HomeCode.GDLoadingTextObjects2= [];
gdjs.HomeCode.GDLoadingTextObjects3= [];
gdjs.HomeCode.GDLoadingTextObjects4= [];
gdjs.HomeCode.GDScoreTextObjects1= [];
gdjs.HomeCode.GDScoreTextObjects2= [];
gdjs.HomeCode.GDScoreTextObjects3= [];
gdjs.HomeCode.GDScoreTextObjects4= [];
gdjs.HomeCode.GDDPadBottomObjects1= [];
gdjs.HomeCode.GDDPadBottomObjects2= [];
gdjs.HomeCode.GDDPadBottomObjects3= [];
gdjs.HomeCode.GDDPadBottomObjects4= [];
gdjs.HomeCode.GDDPadLeftObjects1= [];
gdjs.HomeCode.GDDPadLeftObjects2= [];
gdjs.HomeCode.GDDPadLeftObjects3= [];
gdjs.HomeCode.GDDPadLeftObjects4= [];
gdjs.HomeCode.GDDPadRightObjects1= [];
gdjs.HomeCode.GDDPadRightObjects2= [];
gdjs.HomeCode.GDDPadRightObjects3= [];
gdjs.HomeCode.GDDPadRightObjects4= [];
gdjs.HomeCode.GDDPadUpObjects1= [];
gdjs.HomeCode.GDDPadUpObjects2= [];
gdjs.HomeCode.GDDPadUpObjects3= [];
gdjs.HomeCode.GDDPadUpObjects4= [];
gdjs.HomeCode.GDFireRoundButtonObjects1= [];
gdjs.HomeCode.GDFireRoundButtonObjects2= [];
gdjs.HomeCode.GDFireRoundButtonObjects3= [];
gdjs.HomeCode.GDFireRoundButtonObjects4= [];
gdjs.HomeCode.GDPauseButtonObjects1= [];
gdjs.HomeCode.GDPauseButtonObjects2= [];
gdjs.HomeCode.GDPauseButtonObjects3= [];
gdjs.HomeCode.GDPauseButtonObjects4= [];
gdjs.HomeCode.GDBlankButtonObjects1= [];
gdjs.HomeCode.GDBlankButtonObjects2= [];
gdjs.HomeCode.GDBlankButtonObjects3= [];
gdjs.HomeCode.GDBlankButtonObjects4= [];
gdjs.HomeCode.GDTextoArmaObjects1= [];
gdjs.HomeCode.GDTextoArmaObjects2= [];
gdjs.HomeCode.GDTextoArmaObjects3= [];
gdjs.HomeCode.GDTextoArmaObjects4= [];
gdjs.HomeCode.GDReiniciarJuegoObjects1= [];
gdjs.HomeCode.GDReiniciarJuegoObjects2= [];
gdjs.HomeCode.GDReiniciarJuegoObjects3= [];
gdjs.HomeCode.GDReiniciarJuegoObjects4= [];
gdjs.HomeCode.GDCoinObjects1= [];
gdjs.HomeCode.GDCoinObjects2= [];
gdjs.HomeCode.GDCoinObjects3= [];
gdjs.HomeCode.GDCoinObjects4= [];
gdjs.HomeCode.GDKnifeObjects1= [];
gdjs.HomeCode.GDKnifeObjects2= [];
gdjs.HomeCode.GDKnifeObjects3= [];
gdjs.HomeCode.GDKnifeObjects4= [];
gdjs.HomeCode.GDWallFountainMidBlueObjects1= [];
gdjs.HomeCode.GDWallFountainMidBlueObjects2= [];
gdjs.HomeCode.GDWallFountainMidBlueObjects3= [];
gdjs.HomeCode.GDWallFountainMidBlueObjects4= [];
gdjs.HomeCode.GDTitleObjects1= [];
gdjs.HomeCode.GDTitleObjects2= [];
gdjs.HomeCode.GDTitleObjects3= [];
gdjs.HomeCode.GDTitleObjects4= [];
gdjs.HomeCode.GDWallFountainBasinBlueObjects1= [];
gdjs.HomeCode.GDWallFountainBasinBlueObjects2= [];
gdjs.HomeCode.GDWallFountainBasinBlueObjects3= [];
gdjs.HomeCode.GDWallFountainBasinBlueObjects4= [];
gdjs.HomeCode.GDWallFountainTopObjects1= [];
gdjs.HomeCode.GDWallFountainTopObjects2= [];
gdjs.HomeCode.GDWallFountainTopObjects3= [];
gdjs.HomeCode.GDWallFountainTopObjects4= [];

gdjs.HomeCode.conditionTrue_0 = {val:false};
gdjs.HomeCode.condition0IsTrue_0 = {val:false};
gdjs.HomeCode.condition1IsTrue_0 = {val:false};
gdjs.HomeCode.condition2IsTrue_0 = {val:false};
gdjs.HomeCode.conditionTrue_1 = {val:false};
gdjs.HomeCode.condition0IsTrue_1 = {val:false};
gdjs.HomeCode.condition1IsTrue_1 = {val:false};
gdjs.HomeCode.condition2IsTrue_1 = {val:false};


gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadBottomObjects4Objects = Hashtable.newFrom({"DPadBottom": gdjs.HomeCode.GDDPadBottomObjects4});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.HomeCode.GDGenericCharacter2Objects3});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects3ObjectsGDgdjs_46HomeCode_46GDDoorObjects3ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects3Objects = Hashtable.newFrom({"Floor": gdjs.HomeCode.GDFloorObjects3, "Door": gdjs.HomeCode.GDDoorObjects3, "WallFountainBasinBlue": gdjs.HomeCode.GDWallFountainBasinBlueObjects3});
gdjs.HomeCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.HomeCode.GDDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.HomeCode.GDFloorObjects3);
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("WallFountainBasinBlue"), gdjs.HomeCode.GDWallFountainBasinBlueObjects3);

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects3Objects, gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects3ObjectsGDgdjs_46HomeCode_46GDDoorObjects3ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects3Objects, true, runtimeScene, true);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects3 */
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setCenterYInScene(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getCenterYInScene() - (16));
}
}}

}


};gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadUpObjects4Objects = Hashtable.newFrom({"DPadUp": gdjs.HomeCode.GDDPadUpObjects4});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.HomeCode.GDGenericCharacter2Objects3});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects3ObjectsGDgdjs_46HomeCode_46GDDoorObjects3ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects3Objects = Hashtable.newFrom({"Floor": gdjs.HomeCode.GDFloorObjects3, "Door": gdjs.HomeCode.GDDoorObjects3, "WallFountainBasinBlue": gdjs.HomeCode.GDWallFountainBasinBlueObjects3});
gdjs.HomeCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.HomeCode.GDDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.HomeCode.GDFloorObjects3);
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("WallFountainBasinBlue"), gdjs.HomeCode.GDWallFountainBasinBlueObjects3);

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects3Objects, gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects3ObjectsGDgdjs_46HomeCode_46GDDoorObjects3ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects3Objects, true, runtimeScene, true);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects3 */
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setCenterYInScene(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getCenterYInScene() + (16));
}
}}

}


};gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadRightObjects4Objects = Hashtable.newFrom({"DPadRight": gdjs.HomeCode.GDDPadRightObjects4});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects3Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.HomeCode.GDGenericCharacter2Objects3});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects3ObjectsGDgdjs_46HomeCode_46GDDoorObjects3ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects3Objects = Hashtable.newFrom({"Floor": gdjs.HomeCode.GDFloorObjects3, "Door": gdjs.HomeCode.GDDoorObjects3, "WallFountainBasinBlue": gdjs.HomeCode.GDWallFountainBasinBlueObjects3});
gdjs.HomeCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.HomeCode.GDDoorObjects3);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.HomeCode.GDFloorObjects3);
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects3 */
gdjs.copyArray(runtimeScene.getObjects("WallFountainBasinBlue"), gdjs.HomeCode.GDWallFountainBasinBlueObjects3);

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects3Objects, gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects3ObjectsGDgdjs_46HomeCode_46GDDoorObjects3ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects3Objects, true, runtimeScene, true);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects3 */
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setCenterXInScene(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getCenterXInScene() - (16));
}
}}

}


};gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadLeftObjects3Objects = Hashtable.newFrom({"DPadLeft": gdjs.HomeCode.GDDPadLeftObjects3});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects2Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.HomeCode.GDGenericCharacter2Objects2});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects2ObjectsGDgdjs_46HomeCode_46GDDoorObjects2ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects2Objects = Hashtable.newFrom({"Floor": gdjs.HomeCode.GDFloorObjects2, "Door": gdjs.HomeCode.GDDoorObjects2, "WallFountainBasinBlue": gdjs.HomeCode.GDWallFountainBasinBlueObjects2});
gdjs.HomeCode.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.HomeCode.GDDoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.HomeCode.GDFloorObjects2);
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects2 */
gdjs.copyArray(runtimeScene.getObjects("WallFountainBasinBlue"), gdjs.HomeCode.GDWallFountainBasinBlueObjects2);

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects2Objects, gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDFloorObjects2ObjectsGDgdjs_46HomeCode_46GDDoorObjects2ObjectsGDgdjs_46HomeCode_46GDWallFountainBasinBlueObjects2Objects, true, runtimeScene, true);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects2 */
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].setCenterXInScene(gdjs.HomeCode.GDGenericCharacter2Objects2[i].getCenterXInScene() + (16));
}
}}

}


};gdjs.HomeCode.eventsList4 = function(runtimeScene) {

{

gdjs.HomeCode.GDDPadBottomObjects3.length = 0;


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
{gdjs.HomeCode.conditionTrue_1 = gdjs.HomeCode.condition0IsTrue_0;
gdjs.HomeCode.GDDPadBottomObjects3_1final.length = 0;gdjs.HomeCode.condition0IsTrue_1.val = false;
gdjs.HomeCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadBottom"), gdjs.HomeCode.GDDPadBottomObjects4);
gdjs.HomeCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadBottomObjects4Objects, runtimeScene, true, false);
if( gdjs.HomeCode.condition0IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.HomeCode.GDDPadBottomObjects4.length;j<jLen;++j) {
        if ( gdjs.HomeCode.GDDPadBottomObjects3_1final.indexOf(gdjs.HomeCode.GDDPadBottomObjects4[j]) === -1 )
            gdjs.HomeCode.GDDPadBottomObjects3_1final.push(gdjs.HomeCode.GDDPadBottomObjects4[j]);
    }
}
}
{
gdjs.HomeCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.HomeCode.condition1IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.HomeCode.GDDPadBottomObjects3_1final, gdjs.HomeCode.GDDPadBottomObjects3);
}
}
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.HomeCode.GDGenericCharacter2Objects2, gdjs.HomeCode.GDGenericCharacter2Objects3);

{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setVariableBoolean(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].playAnimation();
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setAnimation(0);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setY(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getY() + (16));
}
}
{ //Subevents
gdjs.HomeCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.HomeCode.GDDPadUpObjects3.length = 0;


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
{gdjs.HomeCode.conditionTrue_1 = gdjs.HomeCode.condition0IsTrue_0;
gdjs.HomeCode.GDDPadUpObjects3_1final.length = 0;gdjs.HomeCode.condition0IsTrue_1.val = false;
gdjs.HomeCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadUp"), gdjs.HomeCode.GDDPadUpObjects4);
gdjs.HomeCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadUpObjects4Objects, runtimeScene, true, false);
if( gdjs.HomeCode.condition0IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.HomeCode.GDDPadUpObjects4.length;j<jLen;++j) {
        if ( gdjs.HomeCode.GDDPadUpObjects3_1final.indexOf(gdjs.HomeCode.GDDPadUpObjects4[j]) === -1 )
            gdjs.HomeCode.GDDPadUpObjects3_1final.push(gdjs.HomeCode.GDDPadUpObjects4[j]);
    }
}
}
{
gdjs.HomeCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.HomeCode.condition1IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.HomeCode.GDDPadUpObjects3_1final, gdjs.HomeCode.GDDPadUpObjects3);
}
}
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.HomeCode.GDGenericCharacter2Objects2, gdjs.HomeCode.GDGenericCharacter2Objects3);

{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setVariableBoolean(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].playAnimation();
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setAnimation(3);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setY(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getY() - (16));
}
}
{ //Subevents
gdjs.HomeCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.HomeCode.GDDPadRightObjects3.length = 0;


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
{gdjs.HomeCode.conditionTrue_1 = gdjs.HomeCode.condition0IsTrue_0;
gdjs.HomeCode.GDDPadRightObjects3_1final.length = 0;gdjs.HomeCode.condition0IsTrue_1.val = false;
gdjs.HomeCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadRight"), gdjs.HomeCode.GDDPadRightObjects4);
gdjs.HomeCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadRightObjects4Objects, runtimeScene, true, false);
if( gdjs.HomeCode.condition0IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.HomeCode.GDDPadRightObjects4.length;j<jLen;++j) {
        if ( gdjs.HomeCode.GDDPadRightObjects3_1final.indexOf(gdjs.HomeCode.GDDPadRightObjects4[j]) === -1 )
            gdjs.HomeCode.GDDPadRightObjects3_1final.push(gdjs.HomeCode.GDDPadRightObjects4[j]);
    }
}
}
{
gdjs.HomeCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.HomeCode.condition1IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.HomeCode.GDDPadRightObjects3_1final, gdjs.HomeCode.GDDPadRightObjects3);
}
}
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.HomeCode.GDGenericCharacter2Objects2, gdjs.HomeCode.GDGenericCharacter2Objects3);

{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setVariableBoolean(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].playAnimation();
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects3.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects3[i].setX(gdjs.HomeCode.GDGenericCharacter2Objects3[i].getX() + (16));
}
}
{ //Subevents
gdjs.HomeCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.HomeCode.GDDPadLeftObjects2.length = 0;


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
{gdjs.HomeCode.conditionTrue_1 = gdjs.HomeCode.condition0IsTrue_0;
gdjs.HomeCode.GDDPadLeftObjects2_1final.length = 0;gdjs.HomeCode.condition0IsTrue_1.val = false;
gdjs.HomeCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("DPadLeft"), gdjs.HomeCode.GDDPadLeftObjects3);
gdjs.HomeCode.condition0IsTrue_1.val = gdjs.evtTools.input.cursorOnObject(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDPadLeftObjects3Objects, runtimeScene, true, false);
if( gdjs.HomeCode.condition0IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.HomeCode.GDDPadLeftObjects3.length;j<jLen;++j) {
        if ( gdjs.HomeCode.GDDPadLeftObjects2_1final.indexOf(gdjs.HomeCode.GDDPadLeftObjects3[j]) === -1 )
            gdjs.HomeCode.GDDPadLeftObjects2_1final.push(gdjs.HomeCode.GDDPadLeftObjects3[j]);
    }
}
}
{
gdjs.HomeCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.HomeCode.condition1IsTrue_1.val ) {
    gdjs.HomeCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(gdjs.HomeCode.GDDPadLeftObjects2_1final, gdjs.HomeCode.GDDPadLeftObjects2);
}
}
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects2 */
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].setVariableBoolean(gdjs.HomeCode.GDGenericCharacter2Objects2[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].playAnimation();
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].setX(gdjs.HomeCode.GDGenericCharacter2Objects2[i].getX() - (16));
}
}
{ //Subevents
gdjs.HomeCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects1Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.HomeCode.GDGenericCharacter2Objects1});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.HomeCode.GDDoorObjects1});
gdjs.HomeCode.asyncCallback11728420 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("GenericCharacter2"), gdjs.HomeCode.GDGenericCharacter2Objects2);

{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].pauseAnimation();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}}
gdjs.HomeCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.HomeCode.GDGenericCharacter2Objects1) asyncObjectsList.addObject("GenericCharacter2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(8))), (runtimeScene) => (gdjs.HomeCode.asyncCallback11728420(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.HomeCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.HomeCode.GDDoorObjects1);
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects1 */

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects1Objects, gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDoorObjects1Objects, true, runtimeScene, false);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.HomeCode.eventsList5(runtimeScene);} //End of subevents
}

}


};gdjs.HomeCode.eventsList7 = function(runtimeScene) {

{


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "GrupoTouch");
}}

}


{


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.HomeCode.GDGenericCharacter2Objects2);
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects2.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects2[i].pauseAnimation();
}
}
{ //Subevents
gdjs.HomeCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.HomeCode.GDGenericCharacter2Objects1);

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.HomeCode.GDGenericCharacter2Objects1.length;i<l;++i) {
    if ( gdjs.HomeCode.GDGenericCharacter2Objects1[i].getVariableBoolean(gdjs.HomeCode.GDGenericCharacter2Objects1[i].getVariables().getFromIndex(0), true) ) {
        gdjs.HomeCode.condition0IsTrue_0.val = true;
        gdjs.HomeCode.GDGenericCharacter2Objects1[k] = gdjs.HomeCode.GDGenericCharacter2Objects1[i];
        ++k;
    }
}
gdjs.HomeCode.GDGenericCharacter2Objects1.length = k;}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDGenericCharacter2Objects1 */
{for(var i = 0, len = gdjs.HomeCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.HomeCode.GDGenericCharacter2Objects1[i].setVariableBoolean(gdjs.HomeCode.GDGenericCharacter2Objects1[i].getVariables().getFromIndex(0), false);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}
{ //Subevents
gdjs.HomeCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects1Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.HomeCode.GDGenericCharacter2Objects1});
gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.HomeCode.GDDoorObjects1});
gdjs.HomeCode.asyncCallback11731076 = function (runtimeScene, asyncObjectsList) {
{runtimeScene.getGame().getVariables().getFromIndex(5).add(1);
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", true);
}}
gdjs.HomeCode.eventsList8 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.HomeCode.asyncCallback11731076(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.HomeCode.eventsList9 = function(runtimeScene) {

{


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
{gdjs.HomeCode.conditionTrue_1 = gdjs.HomeCode.condition0IsTrue_0;
gdjs.HomeCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11729716);
}
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
/* Reuse gdjs.HomeCode.GDDoorObjects1 */
gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.HomeCode.GDLoadingTextObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/OpenDoor.wav", false, 100, 1);
}{for(var i = 0, len = gdjs.HomeCode.GDDoorObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDDoorObjects1[i].setAnimation(0);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{for(var i = 0, len = gdjs.HomeCode.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDLoadingTextObjects1[i].setString("Cargando Nivel");
}
}{for(var i = 0, len = gdjs.HomeCode.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDLoadingTextObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.HomeCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.HomeCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Door"), gdjs.HomeCode.GDDoorObjects1);
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.HomeCode.GDGenericCharacter2Objects1);

gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDGenericCharacter2Objects1Objects, gdjs.HomeCode.mapOfGDgdjs_46HomeCode_46GDDoorObjects1Objects, false, runtimeScene, false);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.HomeCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.HomeCode.eventsList11 = function(runtimeScene) {

{


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LoadingText"), gdjs.HomeCode.GDLoadingTextObjects1);
{gdjs.adMob.setTestMode(false);
}{gdjs.adMob.setupBanner("ca-app-pub-4671042942864334/5141703664", "", true);
}{gdjs.evtTools.sound.playSound(runtimeScene, "assets/The_Old_Tower_Inn.mp3", true, 90, 1);
}{gdjs.evtTools.window.centerWindow(runtimeScene);
}{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}{gdjs.evtTools.window.setAdaptGameResolutionAtRuntime(runtimeScene, true);
}{for(var i = 0, len = gdjs.HomeCode.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.HomeCode.GDLoadingTextObjects1[i].hide();
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), true);
}{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(6);
}}

}


{


gdjs.HomeCode.condition0IsTrue_0.val = false;
{
gdjs.HomeCode.condition0IsTrue_0.val = !(gdjs.adMob.isBannerLoading());
}if (gdjs.HomeCode.condition0IsTrue_0.val) {
{gdjs.adMob.showBanner();
}}

}


{


gdjs.HomeCode.eventsList7(runtimeScene);
}


{


gdjs.HomeCode.eventsList10(runtimeScene);
}


};

gdjs.HomeCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.HomeCode.GDFloorObjects1.length = 0;
gdjs.HomeCode.GDFloorObjects2.length = 0;
gdjs.HomeCode.GDFloorObjects3.length = 0;
gdjs.HomeCode.GDFloorObjects4.length = 0;
gdjs.HomeCode.GDDoorObjects1.length = 0;
gdjs.HomeCode.GDDoorObjects2.length = 0;
gdjs.HomeCode.GDDoorObjects3.length = 0;
gdjs.HomeCode.GDDoorObjects4.length = 0;
gdjs.HomeCode.GDUiHeart1Objects1.length = 0;
gdjs.HomeCode.GDUiHeart1Objects2.length = 0;
gdjs.HomeCode.GDUiHeart1Objects3.length = 0;
gdjs.HomeCode.GDUiHeart1Objects4.length = 0;
gdjs.HomeCode.GDUiHeart2Objects1.length = 0;
gdjs.HomeCode.GDUiHeart2Objects2.length = 0;
gdjs.HomeCode.GDUiHeart2Objects3.length = 0;
gdjs.HomeCode.GDUiHeart2Objects4.length = 0;
gdjs.HomeCode.GDUiHeart3Objects1.length = 0;
gdjs.HomeCode.GDUiHeart3Objects2.length = 0;
gdjs.HomeCode.GDUiHeart3Objects3.length = 0;
gdjs.HomeCode.GDUiHeart3Objects4.length = 0;
gdjs.HomeCode.GDGenericCharacter2Objects1.length = 0;
gdjs.HomeCode.GDGenericCharacter2Objects2.length = 0;
gdjs.HomeCode.GDGenericCharacter2Objects3.length = 0;
gdjs.HomeCode.GDGenericCharacter2Objects4.length = 0;
gdjs.HomeCode.GDLoadingTextObjects1.length = 0;
gdjs.HomeCode.GDLoadingTextObjects2.length = 0;
gdjs.HomeCode.GDLoadingTextObjects3.length = 0;
gdjs.HomeCode.GDLoadingTextObjects4.length = 0;
gdjs.HomeCode.GDScoreTextObjects1.length = 0;
gdjs.HomeCode.GDScoreTextObjects2.length = 0;
gdjs.HomeCode.GDScoreTextObjects3.length = 0;
gdjs.HomeCode.GDScoreTextObjects4.length = 0;
gdjs.HomeCode.GDDPadBottomObjects1.length = 0;
gdjs.HomeCode.GDDPadBottomObjects2.length = 0;
gdjs.HomeCode.GDDPadBottomObjects3.length = 0;
gdjs.HomeCode.GDDPadBottomObjects4.length = 0;
gdjs.HomeCode.GDDPadLeftObjects1.length = 0;
gdjs.HomeCode.GDDPadLeftObjects2.length = 0;
gdjs.HomeCode.GDDPadLeftObjects3.length = 0;
gdjs.HomeCode.GDDPadLeftObjects4.length = 0;
gdjs.HomeCode.GDDPadRightObjects1.length = 0;
gdjs.HomeCode.GDDPadRightObjects2.length = 0;
gdjs.HomeCode.GDDPadRightObjects3.length = 0;
gdjs.HomeCode.GDDPadRightObjects4.length = 0;
gdjs.HomeCode.GDDPadUpObjects1.length = 0;
gdjs.HomeCode.GDDPadUpObjects2.length = 0;
gdjs.HomeCode.GDDPadUpObjects3.length = 0;
gdjs.HomeCode.GDDPadUpObjects4.length = 0;
gdjs.HomeCode.GDFireRoundButtonObjects1.length = 0;
gdjs.HomeCode.GDFireRoundButtonObjects2.length = 0;
gdjs.HomeCode.GDFireRoundButtonObjects3.length = 0;
gdjs.HomeCode.GDFireRoundButtonObjects4.length = 0;
gdjs.HomeCode.GDPauseButtonObjects1.length = 0;
gdjs.HomeCode.GDPauseButtonObjects2.length = 0;
gdjs.HomeCode.GDPauseButtonObjects3.length = 0;
gdjs.HomeCode.GDPauseButtonObjects4.length = 0;
gdjs.HomeCode.GDBlankButtonObjects1.length = 0;
gdjs.HomeCode.GDBlankButtonObjects2.length = 0;
gdjs.HomeCode.GDBlankButtonObjects3.length = 0;
gdjs.HomeCode.GDBlankButtonObjects4.length = 0;
gdjs.HomeCode.GDTextoArmaObjects1.length = 0;
gdjs.HomeCode.GDTextoArmaObjects2.length = 0;
gdjs.HomeCode.GDTextoArmaObjects3.length = 0;
gdjs.HomeCode.GDTextoArmaObjects4.length = 0;
gdjs.HomeCode.GDReiniciarJuegoObjects1.length = 0;
gdjs.HomeCode.GDReiniciarJuegoObjects2.length = 0;
gdjs.HomeCode.GDReiniciarJuegoObjects3.length = 0;
gdjs.HomeCode.GDReiniciarJuegoObjects4.length = 0;
gdjs.HomeCode.GDCoinObjects1.length = 0;
gdjs.HomeCode.GDCoinObjects2.length = 0;
gdjs.HomeCode.GDCoinObjects3.length = 0;
gdjs.HomeCode.GDCoinObjects4.length = 0;
gdjs.HomeCode.GDKnifeObjects1.length = 0;
gdjs.HomeCode.GDKnifeObjects2.length = 0;
gdjs.HomeCode.GDKnifeObjects3.length = 0;
gdjs.HomeCode.GDKnifeObjects4.length = 0;
gdjs.HomeCode.GDWallFountainMidBlueObjects1.length = 0;
gdjs.HomeCode.GDWallFountainMidBlueObjects2.length = 0;
gdjs.HomeCode.GDWallFountainMidBlueObjects3.length = 0;
gdjs.HomeCode.GDWallFountainMidBlueObjects4.length = 0;
gdjs.HomeCode.GDTitleObjects1.length = 0;
gdjs.HomeCode.GDTitleObjects2.length = 0;
gdjs.HomeCode.GDTitleObjects3.length = 0;
gdjs.HomeCode.GDTitleObjects4.length = 0;
gdjs.HomeCode.GDWallFountainBasinBlueObjects1.length = 0;
gdjs.HomeCode.GDWallFountainBasinBlueObjects2.length = 0;
gdjs.HomeCode.GDWallFountainBasinBlueObjects3.length = 0;
gdjs.HomeCode.GDWallFountainBasinBlueObjects4.length = 0;
gdjs.HomeCode.GDWallFountainTopObjects1.length = 0;
gdjs.HomeCode.GDWallFountainTopObjects2.length = 0;
gdjs.HomeCode.GDWallFountainTopObjects3.length = 0;
gdjs.HomeCode.GDWallFountainTopObjects4.length = 0;

gdjs.HomeCode.eventsList11(runtimeScene);
return;

}

gdjs['HomeCode'] = gdjs.HomeCode;
