gdjs.GanadoCode = {};
gdjs.GanadoCode.GDFloorObjects1= [];
gdjs.GanadoCode.GDFloorObjects2= [];
gdjs.GanadoCode.GDDoorObjects1= [];
gdjs.GanadoCode.GDDoorObjects2= [];
gdjs.GanadoCode.GDUiHeart1Objects1= [];
gdjs.GanadoCode.GDUiHeart1Objects2= [];
gdjs.GanadoCode.GDUiHeart2Objects1= [];
gdjs.GanadoCode.GDUiHeart2Objects2= [];
gdjs.GanadoCode.GDUiHeart3Objects1= [];
gdjs.GanadoCode.GDUiHeart3Objects2= [];
gdjs.GanadoCode.GDGenericCharacter2Objects1= [];
gdjs.GanadoCode.GDGenericCharacter2Objects2= [];
gdjs.GanadoCode.GDLoadingTextObjects1= [];
gdjs.GanadoCode.GDLoadingTextObjects2= [];
gdjs.GanadoCode.GDScoreTextObjects1= [];
gdjs.GanadoCode.GDScoreTextObjects2= [];
gdjs.GanadoCode.GDDPadBottomObjects1= [];
gdjs.GanadoCode.GDDPadBottomObjects2= [];
gdjs.GanadoCode.GDDPadLeftObjects1= [];
gdjs.GanadoCode.GDDPadLeftObjects2= [];
gdjs.GanadoCode.GDDPadRightObjects1= [];
gdjs.GanadoCode.GDDPadRightObjects2= [];
gdjs.GanadoCode.GDDPadUpObjects1= [];
gdjs.GanadoCode.GDDPadUpObjects2= [];
gdjs.GanadoCode.GDFireRoundButtonObjects1= [];
gdjs.GanadoCode.GDFireRoundButtonObjects2= [];
gdjs.GanadoCode.GDPauseButtonObjects1= [];
gdjs.GanadoCode.GDPauseButtonObjects2= [];
gdjs.GanadoCode.GDBlankButtonObjects1= [];
gdjs.GanadoCode.GDBlankButtonObjects2= [];
gdjs.GanadoCode.GDTextoArmaObjects1= [];
gdjs.GanadoCode.GDTextoArmaObjects2= [];
gdjs.GanadoCode.GDReiniciarJuegoObjects1= [];
gdjs.GanadoCode.GDReiniciarJuegoObjects2= [];
gdjs.GanadoCode.GDCoinObjects1= [];
gdjs.GanadoCode.GDCoinObjects2= [];
gdjs.GanadoCode.GDWallFountainMidBlueObjects1= [];
gdjs.GanadoCode.GDWallFountainMidBlueObjects2= [];
gdjs.GanadoCode.GDTitleObjects1= [];
gdjs.GanadoCode.GDTitleObjects2= [];
gdjs.GanadoCode.GDWallFountainTopObjects1= [];
gdjs.GanadoCode.GDWallFountainTopObjects2= [];
gdjs.GanadoCode.GDWallFountainBasinBlueObjects1= [];
gdjs.GanadoCode.GDWallFountainBasinBlueObjects2= [];
gdjs.GanadoCode.GDNotificacionObjects1= [];
gdjs.GanadoCode.GDNotificacionObjects2= [];
gdjs.GanadoCode.GDChestObjects1= [];
gdjs.GanadoCode.GDChestObjects2= [];
gdjs.GanadoCode.GDVerTablaObjects1= [];
gdjs.GanadoCode.GDVerTablaObjects2= [];
gdjs.GanadoCode.GDEnviarPuntuacionObjects1= [];
gdjs.GanadoCode.GDEnviarPuntuacionObjects2= [];
gdjs.GanadoCode.GDUserNameObjects1= [];
gdjs.GanadoCode.GDUserNameObjects2= [];

gdjs.GanadoCode.conditionTrue_0 = {val:false};
gdjs.GanadoCode.condition0IsTrue_0 = {val:false};
gdjs.GanadoCode.condition1IsTrue_0 = {val:false};
gdjs.GanadoCode.condition2IsTrue_0 = {val:false};


gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDCoinObjects1Objects = Hashtable.newFrom({"Coin": gdjs.GanadoCode.GDCoinObjects1});
gdjs.GanadoCode.asyncCallback11707540 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(1), false);
}}
gdjs.GanadoCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GanadoCode.asyncCallback11707540(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDVerTablaObjects1Objects = Hashtable.newFrom({"VerTabla": gdjs.GanadoCode.GDVerTablaObjects1});
gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDEnviarPuntuacionObjects1Objects = Hashtable.newFrom({"EnviarPuntuacion": gdjs.GanadoCode.GDEnviarPuntuacionObjects1});
gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDReiniciarJuegoObjects1Objects = Hashtable.newFrom({"ReiniciarJuego": gdjs.GanadoCode.GDReiniciarJuegoObjects1});
gdjs.GanadoCode.eventsList1 = function(runtimeScene) {

{


gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.GanadoCode.GDGenericCharacter2Objects1);
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.GanadoCode.GDScoreTextObjects1);
{gdjs.evtTools.sound.playSound(runtimeScene, "assets/Feels - Patrick Patrikios.mp3", true, 90, 1);
}{gdjs.evtTools.input.touchSimulateMouse(runtimeScene, false);
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().getFromIndex(2), false);
}{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].playAnimation();
}
}{for(var i = 0, len = gdjs.GanadoCode.GDScoreTextObjects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDScoreTextObjects1[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7))) + " pts");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.GanadoCode.GDGenericCharacter2Objects1);

gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GanadoCode.GDGenericCharacter2Objects1.length;i<l;++i) {
    if ( gdjs.GanadoCode.GDGenericCharacter2Objects1[i].getX() >= 96 ) {
        gdjs.GanadoCode.condition0IsTrue_0.val = true;
        gdjs.GanadoCode.GDGenericCharacter2Objects1[k] = gdjs.GanadoCode.GDGenericCharacter2Objects1[i];
        ++k;
    }
}
gdjs.GanadoCode.GDGenericCharacter2Objects1.length = k;}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.GanadoCode.GDGenericCharacter2Objects1);

gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GanadoCode.GDGenericCharacter2Objects1.length;i<l;++i) {
    if ( gdjs.GanadoCode.GDGenericCharacter2Objects1[i].getX() <= 48 ) {
        gdjs.GanadoCode.condition0IsTrue_0.val = true;
        gdjs.GanadoCode.GDGenericCharacter2Objects1[k] = gdjs.GanadoCode.GDGenericCharacter2Objects1[i];
        ++k;
    }
}
gdjs.GanadoCode.GDGenericCharacter2Objects1.length = k;}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}}

}


{


gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), true);
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.GanadoCode.GDGenericCharacter2Objects1);
{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].addPolarForce(0, 16, 0);
}
}}

}


{


gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(0), false);
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("GenericCharacter2"), gdjs.GanadoCode.GDGenericCharacter2Objects1);
{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].clearForces();
}
}{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.GanadoCode.GDGenericCharacter2Objects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDGenericCharacter2Objects1[i].addPolarForce(180, 16, 0);
}
}}

}


{


gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getVariables().getFromIndex(1), false);
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
gdjs.GanadoCode.GDCoinObjects1.length = 0;

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getVariables().getFromIndex(1), true);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDCoinObjects1Objects, gdjs.randomInRange(32, 128), gdjs.randomInRange(96, 144), "Objects");
}
{ //Subevents
gdjs.GanadoCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("VerTabla"), gdjs.GanadoCode.GDVerTablaObjects1);

gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDVerTablaObjects1Objects, runtimeScene, true, false);
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "8888be3b-5084-4c58-b0d5-5175930db135", true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EnviarPuntuacion"), gdjs.GanadoCode.GDEnviarPuntuacionObjects1);
gdjs.copyArray(runtimeScene.getObjects("UserName"), gdjs.GanadoCode.GDUserNameObjects1);

gdjs.GanadoCode.condition0IsTrue_0.val = false;
gdjs.GanadoCode.condition1IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDEnviarPuntuacionObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GanadoCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GanadoCode.GDUserNameObjects1.length;i<l;++i) {
    if ( gdjs.GanadoCode.GDUserNameObjects1[i].getString() != "" ) {
        gdjs.GanadoCode.condition1IsTrue_0.val = true;
        gdjs.GanadoCode.GDUserNameObjects1[k] = gdjs.GanadoCode.GDUserNameObjects1[i];
        ++k;
    }
}
gdjs.GanadoCode.GDUserNameObjects1.length = k;}}
if (gdjs.GanadoCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GanadoCode.GDUserNameObjects1 */
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "8888be3b-5084-4c58-b0d5-5175930db135", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(7)), (( gdjs.GanadoCode.GDUserNameObjects1.length === 0 ) ? "" :gdjs.GanadoCode.GDUserNameObjects1[0].getString()));
}}

}


{


gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.leaderboards.isSaving("8888be3b-5084-4c58-b0d5-5175930db135");
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("EnviarPuntuacion"), gdjs.GanadoCode.GDEnviarPuntuacionObjects1);
gdjs.copyArray(runtimeScene.getObjects("Notificacion"), gdjs.GanadoCode.GDNotificacionObjects1);
gdjs.copyArray(runtimeScene.getObjects("UserName"), gdjs.GanadoCode.GDUserNameObjects1);
{for(var i = 0, len = gdjs.GanadoCode.GDNotificacionObjects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDNotificacionObjects1[i].setString("Enviando tu Puntuación");
}
}{for(var i = 0, len = gdjs.GanadoCode.GDUserNameObjects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDUserNameObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GanadoCode.GDEnviarPuntuacionObjects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDEnviarPuntuacionObjects1[i].hide();
}
}}

}


{


gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.leaderboards.hasBeenSaved("8888be3b-5084-4c58-b0d5-5175930db135");
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Notificacion"), gdjs.GanadoCode.GDNotificacionObjects1);
{for(var i = 0, len = gdjs.GanadoCode.GDNotificacionObjects1.length ;i < len;++i) {
    gdjs.GanadoCode.GDNotificacionObjects1[i].setString("Puntuación Guardada");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("ReiniciarJuego"), gdjs.GanadoCode.GDReiniciarJuegoObjects1);

gdjs.GanadoCode.condition0IsTrue_0.val = false;
{
gdjs.GanadoCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GanadoCode.mapOfGDgdjs_46GanadoCode_46GDReiniciarJuegoObjects1Objects, runtimeScene, true, false);
}if (gdjs.GanadoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Home", true);
}}

}


};

gdjs.GanadoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GanadoCode.GDFloorObjects1.length = 0;
gdjs.GanadoCode.GDFloorObjects2.length = 0;
gdjs.GanadoCode.GDDoorObjects1.length = 0;
gdjs.GanadoCode.GDDoorObjects2.length = 0;
gdjs.GanadoCode.GDUiHeart1Objects1.length = 0;
gdjs.GanadoCode.GDUiHeart1Objects2.length = 0;
gdjs.GanadoCode.GDUiHeart2Objects1.length = 0;
gdjs.GanadoCode.GDUiHeart2Objects2.length = 0;
gdjs.GanadoCode.GDUiHeart3Objects1.length = 0;
gdjs.GanadoCode.GDUiHeart3Objects2.length = 0;
gdjs.GanadoCode.GDGenericCharacter2Objects1.length = 0;
gdjs.GanadoCode.GDGenericCharacter2Objects2.length = 0;
gdjs.GanadoCode.GDLoadingTextObjects1.length = 0;
gdjs.GanadoCode.GDLoadingTextObjects2.length = 0;
gdjs.GanadoCode.GDScoreTextObjects1.length = 0;
gdjs.GanadoCode.GDScoreTextObjects2.length = 0;
gdjs.GanadoCode.GDDPadBottomObjects1.length = 0;
gdjs.GanadoCode.GDDPadBottomObjects2.length = 0;
gdjs.GanadoCode.GDDPadLeftObjects1.length = 0;
gdjs.GanadoCode.GDDPadLeftObjects2.length = 0;
gdjs.GanadoCode.GDDPadRightObjects1.length = 0;
gdjs.GanadoCode.GDDPadRightObjects2.length = 0;
gdjs.GanadoCode.GDDPadUpObjects1.length = 0;
gdjs.GanadoCode.GDDPadUpObjects2.length = 0;
gdjs.GanadoCode.GDFireRoundButtonObjects1.length = 0;
gdjs.GanadoCode.GDFireRoundButtonObjects2.length = 0;
gdjs.GanadoCode.GDPauseButtonObjects1.length = 0;
gdjs.GanadoCode.GDPauseButtonObjects2.length = 0;
gdjs.GanadoCode.GDBlankButtonObjects1.length = 0;
gdjs.GanadoCode.GDBlankButtonObjects2.length = 0;
gdjs.GanadoCode.GDTextoArmaObjects1.length = 0;
gdjs.GanadoCode.GDTextoArmaObjects2.length = 0;
gdjs.GanadoCode.GDReiniciarJuegoObjects1.length = 0;
gdjs.GanadoCode.GDReiniciarJuegoObjects2.length = 0;
gdjs.GanadoCode.GDCoinObjects1.length = 0;
gdjs.GanadoCode.GDCoinObjects2.length = 0;
gdjs.GanadoCode.GDWallFountainMidBlueObjects1.length = 0;
gdjs.GanadoCode.GDWallFountainMidBlueObjects2.length = 0;
gdjs.GanadoCode.GDTitleObjects1.length = 0;
gdjs.GanadoCode.GDTitleObjects2.length = 0;
gdjs.GanadoCode.GDWallFountainTopObjects1.length = 0;
gdjs.GanadoCode.GDWallFountainTopObjects2.length = 0;
gdjs.GanadoCode.GDWallFountainBasinBlueObjects1.length = 0;
gdjs.GanadoCode.GDWallFountainBasinBlueObjects2.length = 0;
gdjs.GanadoCode.GDNotificacionObjects1.length = 0;
gdjs.GanadoCode.GDNotificacionObjects2.length = 0;
gdjs.GanadoCode.GDChestObjects1.length = 0;
gdjs.GanadoCode.GDChestObjects2.length = 0;
gdjs.GanadoCode.GDVerTablaObjects1.length = 0;
gdjs.GanadoCode.GDVerTablaObjects2.length = 0;
gdjs.GanadoCode.GDEnviarPuntuacionObjects1.length = 0;
gdjs.GanadoCode.GDEnviarPuntuacionObjects2.length = 0;
gdjs.GanadoCode.GDUserNameObjects1.length = 0;
gdjs.GanadoCode.GDUserNameObjects2.length = 0;

gdjs.GanadoCode.eventsList1(runtimeScene);
return;

}

gdjs['GanadoCode'] = gdjs.GanadoCode;
