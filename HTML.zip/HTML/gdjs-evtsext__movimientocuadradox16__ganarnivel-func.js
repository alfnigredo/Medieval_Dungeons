
if (typeof gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel !== "undefined") {
  gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel = {};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects4= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects5= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects4= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects5= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects2= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects3= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects4= [];
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects5= [];

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition2IsTrue_0 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1 = {val:false};
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition2IsTrue_1 = {val:false};


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95GanarNivel_46GDGenericCharacter2Objects1Objects = Hashtable.newFrom({"GenericCharacter2": gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects1});
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95GanarNivel_46GDDoorObjects1Objects = Hashtable.newFrom({"Door": gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1});
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList0 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Nivel")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("NivelesMaximos"));
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ganado", false);
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Nivel")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("NivelesMaximos")));
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", true);
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList1 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Nivel")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("NivelesMaximos"));
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ganado", false);
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Nivel")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("NivelesMaximos")));
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", false);
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList2 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = !(gdjs.adMob.isInterstitialShowing());
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList1(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList3 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Nivel")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("NivelesMaximos"));
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ganado", false);
}}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = !(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("Nivel")) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().get("NivelesMaximos")));
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "AutoLevel", false);
}}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList4 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.adMob.isInterstitialReady();
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.adMob.showInterstitial();
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList2(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.adMob.isInterstitialErrored();
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList3(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList5 = function(runtimeScene, eventsFunctionContext, asyncObjectsList) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1.val = gdjs.evtTools.systemInfo.isPreview(runtimeScene);
if( gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1.val = true;
}
}
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1.val = !(gdjs.evtTools.systemInfo.isMobile());
if( gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList0(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
{gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1.val = !(gdjs.evtTools.systemInfo.isPreview(runtimeScene));
if( gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1.val = true;
}
}
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1.val = gdjs.evtTools.systemInfo.isMobile();
if( gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_1.val ) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {

{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList4(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.asyncCallback11127796 = function (runtimeScene, eventsFunctionContext, asyncObjectsList) {
{runtimeScene.getGame().getVariables().get("Nivel").add(1);
}{runtimeScene.getGame().getVariables().get("Score").add(20);
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList5(runtimeScene, eventsFunctionContext, asyncObjectsList);} //End of subevents
}
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.asyncCallback11127796(runtimeScene, eventsFunctionContext, asyncObjectsList)));
}
}

}


};gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val) {
{gdjs.adMob.loadInterstitial("ca-app-pub-4671042942864334/6831724704", "", false);
}}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Door"), gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("GenericCharacter2"), gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects1);

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = false;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_0.val = false;
{
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95GanarNivel_46GDGenericCharacter2Objects1Objects, gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.mapOfGDgdjs_46evtsExt_95_95MovimientoCuadradoX16_95_95GanarNivel_46GDDoorObjects1Objects, false, runtimeScene, false);
}if ( gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition0IsTrue_0.val ) {
{
{gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1 = gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.conditionTrue_1.val = eventsFunctionContext.getOnceTriggers().triggerOnce(11127124);
}
}}
if (gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.condition1IsTrue_0.val) {
/* Reuse gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1 */
gdjs.copyArray(eventsFunctionContext.getObjects("LoadingText"), gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1);
{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1[i].setAnimation(0);
}
}{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getGame().getVariables().get("Movible"), false);
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1[i].setString("Cargando Nivel");
}
}{for(var i = 0, len = gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1.length ;i < len;++i) {
    gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.func = function(runtimeScene, Door, GenericCharacter2, LoadingText, parentEventsFunctionContext) {
var eventsFunctionContext = {
  _objectsMap: {
"Door": Door
, "GenericCharacter2": GenericCharacter2
, "LoadingText": LoadingText
},
  _objectArraysMap: {
"Door": gdjs.objectsListsToArray(Door)
, "GenericCharacter2": gdjs.objectsListsToArray(GenericCharacter2)
, "LoadingText": gdjs.objectsListsToArray(LoadingText)
},
  _behaviorNamesMap: {
},
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName];
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        eventsFunctionContext._objectArraysMap[objectName].push(object);
      }
      return object;    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects4.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDDoorObjects5.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects4.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDGenericCharacter2Objects5.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects1.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects2.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects3.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects4.length = 0;
gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.GDLoadingTextObjects5.length = 0;

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.eventsList7(runtimeScene, eventsFunctionContext);
return;
}

gdjs.evtsExt__MovimientoCuadradoX16__GanarNivel.registeredGdjsCallbacks = [];